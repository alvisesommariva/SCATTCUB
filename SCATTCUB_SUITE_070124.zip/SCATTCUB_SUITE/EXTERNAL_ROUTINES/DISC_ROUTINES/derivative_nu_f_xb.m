
function [dnu,e]=derivative_nu_f_xb(X,fX,Xb,d0,dmax,delta,hmax,nu)

%% Computing the approximation of the derivative of order "nu" by 
%% using scattered data at the point "Xb" as much accurate as possible.

% INPUT:
% X: scattered sample points (matrix N x 2)
% fX: function values at X
% Xb: evaluation point
% d0: initial degree
% dmax: maximum degree
% delta: degree step
% hmax: maximum allowed radius <1
% nu: differentiation bi-index


% OUTPUT: 
% dnu: approximation of the derivative of "f" of order "nu" at "Xb"
% e: error estimate

% ................. Setting defaults, if needed  .......................... 

if nargin < 4, d0=5; end
if isempty(d0), d0=5; end

if nargin < 5, dmax=floor((-3+sqrt(1+8*length(fX)))/2); end
if isempty(dmax), dmax=floor((-3+sqrt(1+8*length(fX)))/2); end

if nargin < 6, delta=2; end
if isempty(delta), delta=2; end

if nargin < 7, hmax=0.8; end
if isempty(hmax), hmax=0.8; end

if nargin < 8, nu=1; end
if isempty(nu), nu=1; end


% .......................... Main code below .............................. 

errmin=realmax;

d=d0;
%%%% Ordered distances of the nodes in X from Xb
dist2x=X(:,1)-Xb(1);
dist2y=X(:,2)-Xb(2);

dist2=dist2x.^2+dist2y.^2;

OD=sort(dist2);

e=[];
deg=[];
dnu=[];


h=0;

powV=pow(d);
factorial_nu=prod(factorial(powV),2);

while  d<=dmax && h<=hmax
    m_d=(d+1)*(d+2)/2;
    h_d=sqrt(OD(min(m_d+1,end),1)); %% min{h: card(X_h)>=m_d}
    h=max(h,h_d);
    
    %% find the minimum radius h_d such that ball $B_h(xb)$ contains at
    %% least m_d points
    if h<=hmax  
        r=0;
        while r<m_d && h<=hmax
            in_B=dist2<=h^2; 
            
            dist2hx=dist2x(in_B==1);
            dist2hy=dist2y(in_B==1);

            V=BivVand([dist2hx./h,dist2hy./h],d,powV);
            r=rank(V);

            if r<m_d
                h=(1+h)/2;
            end
        end
    end
    
    if h<=hmax   

        fh=fX(in_B==1);
        %% extract m_d approximate Leja pts in X_h        
        Ih=fekete(V);
        fh_Leja=fh(Ih);

        %% compute the Vandermonde matrix of degree d
        Vh=V(Ih,:); 

        %% compute the approximate coefficients for degree d       
        scaling=[1;h.^sum(powV(2:m_d,:),2)];
        der_approx=factorial_nu(1:m_d).*(Vh\fh_Leja)./scaling;
        deriv_d=der_approx(nu);      
       
        %% compute the approximate coefficients for degree d-delta
        m_d_minus_delta=(d-delta+1)*(d-delta+2)/2;
        scaling_delta=[1;h.^sum(powV(2:m_d_minus_delta,:),2)];
        der_approx=factorial_nu(1:m_d_minus_delta).*(Vh(1:m_d_minus_delta,1:m_d_minus_delta)\fh_Leja(1:m_d_minus_delta))./scaling_delta;
        deriv_d_delta=der_approx(nu);      
        
        %% compute the error estimate
        err=abs(deriv_d-deriv_d_delta);

        if err<errmin
            errmin=err;
            e=[e;errmin];
            deg=[deg;d];
            dnu=[dnu; deriv_d_delta];
            hmin=h_d;
            dmin=d;
        end
        
        d_old=d;
        d=d+delta;        
        
        powVa=pow(d_old,d);
        powV=[powV;powVa];
        factorial_nu=[factorial_nu; prod(factorial(powVa),2)];  

    end
end