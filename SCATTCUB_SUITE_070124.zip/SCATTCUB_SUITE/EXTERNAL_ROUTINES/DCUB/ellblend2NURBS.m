

function domain_structure_NURBS=ellblend2NURBS(domain_structure)

domain_str=domain_structure.domain;
domain_structure_NURBS=[];


switch domain_str

    case 'circular-segment'

        % ....................... define parameters .......................
        C=domain_structure.center;
        r=domain_structure.radius;
        anglesV=domain_structure.angles; alpha=anglesV(1); beta=anglesV(2);



        % ................... define domain as NURBS ......................

        % arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',C,'angles',[alpha beta],'radius',r);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % "close" the boundary with a segment
        geometry_NURBS(2)=makeNURBSarc('segment','extrema',...
            [Pend; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

        domain_structure_NURBS=geometry_NURBS;



    case 'sector'

        % ....................... define parameters .......................

        C=domain_structure.center;
        r=domain_structure.radius;
        anglesV=domain_structure.angles; alpha=anglesV(1); beta=anglesV(2);



        % ................... define domain as NURBS ......................

        if beta < alpha, beta=beta+2*pi; end

        % arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',C,'angles',[alpha beta],'radius',r);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % Join "Pend" with the center "C" by a segment
        geometry_NURBS(2)=makeNURBSarc('segment','extrema',...
            [Pend; C]);

        % Join the center "C" with "Pinit" by a segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',...
            [C; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

        domain_structure_NURBS=geometry_NURBS;



    case  'circular-annular-sector'

        % ....................... define parameters ......................

        C=domain_structure.center;
        rV=domain_structure.radii; r1=rV(1); r2=rV(2);
        anglesV=domain_structure.angles; alpha=anglesV(1); beta=anglesV(2);



        % ................... define domain as NURBS ......................

        if beta < alpha, beta=beta+2*pi; end

        % arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',C,'angles',[alpha beta],'radius',r2);

        % compute first point of the piecewise NURBS domain
        Pinit1=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend1=lastpointNURBSPL(geometry_NURBS(1));

        geometry_3=makeNURBSarc('disk_arc',...
            'center',C,'angles',[beta,alpha],'radius',r1);

        % compute first point of the piecewise NURBS domain
        Pinit3=firstpointNURBSPL(geometry_3);

        % compute last point of the so made NURBS
        Pend3=lastpointNURBSPL(geometry_3);

        % Join "Pend" with the center "C" by a segment
        geometry_NURBS(2)=makeNURBSarc('segment','extrema',...
            [Pend1; Pinit3]);

        geometry_NURBS(3)=geometry_3;

        % Join the center "C" with "Pinit" by a segment
        geometry_NURBS(4)=makeNURBSarc('segment','extrema',...
            [Pend3; Pinit1]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

        domain_structure_NURBS=geometry_NURBS;



    case 'asymmetric-circular-sector'

        % ....................... define parameters .......................

        CV=domain_structure.centers; C=CV(1,:); V=CV(2,:);
        r=domain_structure.radius;
        anglesV=domain_structure.angles; alpha=anglesV(1); beta=anglesV(2);



        % ................... define domain as NURBS ......................

        if beta < alpha, beta=beta+2*pi; end

        % arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',C,'angles',[alpha beta],'radius',r);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));


        % Join "Pend" with the vertex "V" by a segment
        geometry_NURBS(2)=makeNURBSarc('segment','extrema',...
            [Pend;V]);

        % Join the vertex "V" with "Pinit" by a segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',...
            [V; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

        domain_structure_NURBS=geometry_NURBS;




    case 'vertical-circular-zone'

        % ....................... define parameters .......................

        C=domain_structure.center;
        r=domain_structure.radius;
        anglesV=domain_structure.angles; alpha=anglesV(1); beta=anglesV(2);



        % ................... define domain as NURBS ......................

        % arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',C,'angles',[alpha beta],'radius',r);

        % compute first point of the piecewise NURBS domain
        Pinit1=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend1=lastpointNURBSPL(geometry_NURBS(1));

        geometry_NURBS_3=makeNURBSarc('disk_arc',...
            'center',C,'angles',[-beta -alpha],'radius',r);

        % compute first point of the piecewise NURBS domain
        Pinit3=firstpointNURBSPL(geometry_NURBS_3);

        % compute last point of the so made NURBS
        Pend3=lastpointNURBSPL(geometry_NURBS_3);

        % Join the vertex "V" with "Pinit" by a segment
        geometry_NURBS(2)=makeNURBSarc('segment','extrema',...
            [Pend1; Pinit3]);

        geometry_NURBS(3)=geometry_NURBS_3;

        % Join the vertex "V" with "Pinit" by a segment
        geometry_NURBS(2)=makeNURBSarc('segment','extrema',...
            [Pend3; Pinit1]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

        domain_structure_NURBS=geometry_NURBS;



    case 'horizontal-circular-zone'

        % ....................... define parameters .......................

        C=domain_structure.center;
        r=domain_structure.radius;
        anglesV=domain_structure.angles; alpha=anglesV(1); beta=anglesV(2);



        % ................... define domain as NURBS ......................

        % arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',C,'angles',[alpha beta],'radius',r);

        % compute first point of the piecewise NURBS domain
        Pinit1=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend1=lastpointNURBSPL(geometry_NURBS(1));

        thm=pi-beta; thM=pi-alpha;


        geometry_NURBS_3=makeNURBSarc('disk_arc',...
            'center',C,'angles',[thm thM],'radius',r);

        % compute first point of the piecewise NURBS domain
        Pinit3=firstpointNURBSPL(geometry_NURBS_3);

        % compute last point of the so made NURBS
        Pend3=lastpointNURBSPL(geometry_NURBS_3);

        % Join the vertex "V" with "Pinit" by a segment
        geometry_NURBS(2)=makeNURBSarc('segment','extrema',...
            [Pend1; Pinit3]);

        geometry_NURBS(3)=geometry_NURBS_3;

        % Join the vertex "V" with "Pinit" by a segment
        geometry_NURBS(4)=makeNURBSarc('segment','extrema',...
            [Pend3; Pinit1]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

        domain_structure_NURBS=geometry_NURBS;



    case 'lune'

        % ....................... define parameters .......................

        cents0=domain_structure.centers;
        rs0=domain_structure.radii;

        % ................... define domain as NURBS ......................

        [cents,rs,angles,disk_sequence,arcs_subdomains]=...
            determine_uniondisks_boundary(cents0,rs0);



        % ..... first arc .....

        C1=cents0(1,:); r1=rs(1);

        [LIA,LOCB] = ismember(C1,cents,'rows');

        if LIA == 0
            fprintf(1,'\n \t The domain is a degenerate lune');
            domain_structure_NURBS=[];
            return;
        end

        iarc=find(disk_sequence == LOCB);
        arc1=angles(iarc,:);


        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',C1,'angles',arc1,'radius',r1);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % second arc

        C2=cents0(2,:); r2=rs(2);

        Vinit=Pinit-C2; [TH1,R1] = cart2pol(Vinit(:,1),Vinit(:,2));
        Vend=Pend-C2; [TH2,R2] = cart2pol(Vend(:,1),Vend(:,2));

        if TH2 < TH1, TH2=TH2+2*pi; end

        % "close" the boundary with a segment
        geometry_NURBS(2)=makeNURBSarc('disk_arc','center',C2,...
            'angles',[TH2 TH1],'radius',r2);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

        domain_structure_NURBS=geometry_NURBS;


    case 'butterfly'

        % ....................... define parameters .......................

        C=domain_structure.center;
        r=domain_structure.radius;
        anglesV=domain_structure.angles; alpha=anglesV(1); beta=anglesV(2);



        % ................... define domain as NURBS ......................

        % arc of a disk
        geometry_NURBS2=makeNURBSarc('disk_arc',...
            'center',C,'angles',[alpha beta],'radius',r);

        % compute first point of the piecewise NURBS domain
        Pinit1=firstpointNURBSPL(geometry_NURBS2);

        % compute last point of the so made NURBS
        Pend1=lastpointNURBSPL(geometry_NURBS2);

        % Join "Pend" with the center "C" by a segment
        geometry_NURBS(1)=makeNURBSarc('segment','extrema',...
            [C; Pinit1]);

        geometry_NURBS(2)=geometry_NURBS2;

        % Join "Pend" with the center "C" by a segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',...
            [Pend1; C]);


        % arc of a disk
        geometry_NURBS5=makeNURBSarc('disk_arc',...
            'center',C,'angles',[beta+pi alpha+pi],'radius',r);

        % compute first point of the piecewise NURBS domain
        Pinit2=firstpointNURBSPL(geometry_NURBS5);

        % compute last point of the so made NURBS
        Pend2=lastpointNURBSPL(geometry_NURBS5);

        % Join "Pend" with the center "C" by a segment
        geometry_NURBS(4)=makeNURBSarc('segment','extrema',...
            [C; Pinit2]);

        geometry_NURBS(5)=geometry_NURBS5;

        % Join "Pend" with the center "C" by a segment
        geometry_NURBS(6)=makeNURBSarc('segment','extrema',...
            [Pend2; C]);


        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

        domain_structure_NURBS=geometry_NURBS;

end
