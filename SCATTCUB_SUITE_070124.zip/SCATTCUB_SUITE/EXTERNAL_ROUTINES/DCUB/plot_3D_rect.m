
function plot_3D_rect(dbox,pts1,pts2)

%--------------------------------------------------------------------------
% Object:
% Plot the "frames" of a cone with base determined by points stored in "P"
% vertex in "V" and elevation "elev". Furthermore it plots the points
% stored in "pts".
%--------------------------------------------------------------------------
% Input:
% P: column array of 2D mesh points (cone basis),
% V: vertex (cone vertex),
% elev: elevation of the cut in percentage,
% pts1: points belonging to the cone (first set).
% pts2: points belonging to the cone (second set).
%--------------------------------------------------------------------------

if nargin < 2, pts1=[]; end
if nargin < 3, pts2=[]; end

dboxX=dbox(:,1); dboxY=dbox(:,2); dboxZ=dbox(:,3);

xm=dbox(1,1); xM=dbox(2,1);
ym=dbox(1,2); yM=dbox(2,2);
zm=dbox(1,3); zM=dbox(2,3);

Xv=[xm xM xM xm xm]';
Yv=[ym ym yM yM ym]';
rect1=[Xv Yv zm*ones(5,1)];
rect2=[Xv Yv zM*ones(5,1)];

% plot 3D rectangle
plot3(rect1(:,1),rect1(:,2),rect1(:,3)); 
hold on;
plot3(rect2(:,1),rect2(:,2),rect2(:,3));
plot3([xm xm],[ym ym],[zm zM]);
plot3([xM xM],[ym ym],[zm zM]);
plot3([xM xM],[yM yM],[zm zM]);
plot3([xm xm],[yM yM],[zm zM]);

if isempty(pts1) == 0
    plot3(pts1(:,1),pts1(:,2),pts1(:,3),'r*');
end

if isempty(pts2) == 0
    plot3(pts2(:,1),pts2(:,2),pts2(:,3),'ko');
end


hold off;