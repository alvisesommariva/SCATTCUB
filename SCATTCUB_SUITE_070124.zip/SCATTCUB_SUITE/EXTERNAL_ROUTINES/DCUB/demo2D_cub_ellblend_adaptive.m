
function demo_cub_ellblend_adaptive

% choose 
% domain_str='disk';
% domain_str='sector'; 
% domain_str='circular-annular-sector';
% domain_str='asymmetric-circular-sector';
% domain_str='asymmetric-annulus';
% domain_str='circular-annular-sector';
% domain_str='vertical-circular-zone';
% domain_str='symmetric-lens';
% domain_str='horizontal-circular-zone';
% domain_str='circular-segment';
% domain_str='butterfly';
% domain_str='candy'; % something looks wrong.

tol=10^(-14);
degR=50;

%--------------------------------------------------------------------------
% gallery_type: string that chooses the function and can be
%
%         'easy' some rather well behaved functions
%                (set as "example" a value in 1,...,23);
%
%         'renka-brown' that are taken from the paper 1., mentioned below;
%                (set as "example" a value in 1,...,10);
%
%         'polynomials' polynomials of degree "deg";
%                (set as "example" a value in 1,...,2);
%            f_type=1: fixed polynomial of degree "deg";
%            f_type=2: random polynomial of degree "deg";
%
% some examples:
%
%          1. Franke function has the setting:
%            gallery_type='easy'; f_type=18;
%
%          2. 'exp(-((x-x0).^2+(y-y0).^2))' has the setting:
%            gallery_type='easy'; f_type=16;
%
%          3 '(pi/16+exp(-3.2)*x+sin(pi/9)*y).^deg' has the setting:
%             gallery_type='polynomials'; f_type=1;
%
% For details, see the file gallery_2D.m in "../EXTERNAL_ROUTINES/DCUB".
%--------------------------------------------------------------------------

gallery_type='easy'; function_example=2;

% Define domain
domain_structure=define_domain(domain_str);

% Integrand from a gallery
[f,fstr]=gallery_2D(function_example,gallery_type);

% Adaptive cubature
[I,aerr]=cub_ellblend_adaptive(f,domain_structure,tol);

% Comparison rule
[XWR,dbox]=define_cub_rule(domain_structure,degR);
IR=(XWR(:,3))'*feval(f,XWR(:,1),XWR(:,2));

% Statistics
fprintf('\n \t I  : %1.15e',I);
fprintf('\n \t IR : %1.15e',IR);
fprintf('\n \t RE : %1.3e',abs(IR-I)/(abs(I)+(I==0)));
fprintf('\n \n')

% Plot
plot_2D(domain_structure)
