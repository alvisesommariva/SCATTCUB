
function [x1,w1]=quad_trig_cc(n,alpha,beta,method)

%--------------------------------------------------------------------------
% PURPOSE:
%-----------
% FEJER TYPE TRIGONOMETRIC RULES.
%--------------------------------------------------------------------------
% INPUT:
%-----------
% n: DEGREE OF PRECISION.
% alpha, beta: TRIGONOMETRIC INTERVAL.
% method: 1: FEJER I, 2: FEJER II, 3: CLENSHAW-CURTIS.
%--------------------------------------------------------------------------
% OUTPUT:
%-----------
% x1: NODES OF THE QUADRATURE RULE.
% w1: WEIGHTS OF THE QUADRATURE RULE.
%--------------------------------------------------------------------------
% EXAMPLE 1:
%-----------
%
% >>[x1,w1]=quad_trig_cc(5,0,pi,1)
% 
% x1 =
% 
%     3.0460
%     2.4281
%     1.5708
%     0.7135
%     0.0956
% 
% 
% w1 =
% 
%     0.3144
%     0.8289
%     0.8549
%     0.8289
%     0.3144
% >>
%--------------------------------------------------------------------------
% EXAMPLE 2:
%-----------
%
% >> [x1,w1]=quad_trig_cc(5,0,pi,2)
% 
% x1 =
% 
%     2.8889
%     2.2935
%     1.5708
%     0.8481
%     0.2527
% 
% 
% w1 =
% 
%     0.5693
%     0.5752
%     0.8525
%     0.5752
%     0.5693
% 
% >> 
%--------------------------------------------------------------------------
% EXAMPLE 3:
%-----------
% >> [x1,w1]=quad_trig_cc(5,0,pi,3)
% 
% x1 =
% 
%     3.1416
%     2.6180
%     1.5708
%     0.5236
%     0.0000
% 
% 
% w1 =
% 
%     0.1416
%     0.8584
%     1.1416
%     0.8584
%     0.1416
% >>
%--------------------------------------------------------------------------
%%
%% Copyright (C) 2013. Mariano Gentile, Alvise Sommariva, Marco Vianello.
%%
%% This program is free software; you can redistribute it and/or modify
%% it under the terms of the GNU General Public License as published by
%% the Free Software Foundation; either version 2 of the License, or
%% (at your option) any later version.
%%
%% This program is distributed in the hope that it will be useful,
%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%% GNU General Public License for more details.
%%
%% You should have received a copy of the GNU General Public License
%% along with this program; if not, write to the Free Software
%% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%%
%% Authors:
%%          Mariano Gentile  <gentimar@hotmail.com>
%%          Alvise Sommariva <alvise@euler.math.unipd.it>
%%          Marco Vianello   <marcov@euler.math.unipd.it>
%%
%% Date: May 18, 2013
%%
%--------------------------------------------------------------------------

if nargin < 1
    n=10;
end

if nargin < 2
    alpha=0;
end

if nargin < 3
    beta=pi;
end

if nargin < 4
    method=1;
end

omega=(beta-alpha)/2;
[x1,w1]=quad_trig_cc_symm(n,omega,method);
x1=((alpha+beta)/2)+x1;




%--------------------------------------------------------------------------
% ATTACHED ROUTINES.
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% quad_trig_cc_symm
%--------------------------------------------------------------------------

function [x1,w1]=quad_trig_cc_symm(n,omega,method)

if nargin < 3
    method=3;
end

switch method

    case 1
        moms=moms_cheb1type_trig(n-1,omega);
        [x1,w1]=fejerI(n,moms);
        x1=2*asin(sin(omega/2)*x1);
        
    case 2
        moms=moms_cheb1type_trig(n-1,omega);
        [x1,w1]=fejerII(n,moms);
        x1=2*asin(sin(omega/2)*x1);
        
    case 3
        moms=moms_cheb1type_trig(n-1,omega);
        [x1,w1]=clenshaw_curtis(n,moms);
        x1=2*asin(sin(omega/2)*x1);
        
end




%--------------------------------------------------------------------------
% fejerI
%--------------------------------------------------------------------------

function [x,w]=fejerI(n,moms)

% OBJECT: FEJER RULE. TYPE I.

% INPUTS:
% n: NUMBER OF POINTS. TESTED WITH n <= 14 MILLION NODES.
% moms: WEIGHT FUNCTION MODIFIED MOMENTS (w.r.t. CHEB. POLY. TYPE I).

% OUTPUTS:
% x: QUADRATURE NODES IN THE INTERVAL (-1,1). COLUMN VECTOR.
% w: QUADRATURE WEIGHTS. COLUMN VECTOR.

% REFERENCE:
% ALVISE SOMMARIVA
% "Fast Construction of Fej?er and Clenshaw-Curtis rules for general weight
% functions".

% AUTHOR:
% ALVISE SOMMARIVA, JULY 23, 2012.

if nargin < 2
    moms=moms_cheb1type_legendre(n-1);
end

moms(1)=sqrt(1/2)*moms(1);
x=cos((2*(1:n)'-1)*pi/(2*n));
w=sqrt(2/n)*idct(moms);


function moms=moms_cheb1type_legendre(n)

moms=zeros(n+1,0);
m=0:2:n; m=m';
moms_even_degree=2./(1-m.^2);
moms(m+1,1)=moms_even_degree;




%--------------------------------------------------------------------------
% fejerII
%--------------------------------------------------------------------------


function [x,w]=fejerII(n,moms)

% OBJECT: FEJER RULE. TYPE II.

% INPUTS:
% n: NUMBER OF POINTS. TESTED WITH n <= 14 MILLION NODES.
% moms: WEIGHT FUNCTION MODIFIED MOMENTS (w.r.t. CHEB. POLY. TYPE I).

% OUTPUTS:
% x: QUADRATURE NODES IN THE INTERVAL (-1,1). COLUMN VECTOR.
% w: QUADRATURE WEIGHTS. COLUMN VECTOR.

% REFERENCE:
% ALVISE SOMMARIVA
% "Fast Construction of Fej?er and Clenshaw-Curtis rules for general weight
% functions".

% AUTHOR:
% ALVISE SOMMARIVA, JULY 23, 2012.

if nargin < 2
    moms=moms_cheb1type_legendre(n-1);
end

momsII=compute_moments_IIw(n-1,moms);
theta=(1:n)*pi/(n+1); theta=theta'; x=cos(theta);
w=(2*sin(theta)/(n+1)).*dst(momsII);




%--------------------------------------------------------------------------
% compute_moments_IIw
%--------------------------------------------------------------------------

function momsII=compute_moments_IIw(n,momsI)

% COMPUTATION OF MOMENTS W.R.T. CHEBYSHEV SECOND TYPE FROM CHEBYSHEV FIRST
% TYPE.

momsI=momsI(1:n+1);

momsIe=momsI(1:2:end); momsIo=momsI(2:2:end);
momsII=zeros(size(momsI));
momsII(1:2:end)=2*cumsum(momsIe)-momsI(1);
momsII(2:2:end)=2*cumsum(momsIo);


% function moms=moms_cheb1type_legendre(n)
% 
% moms=zeros(n+1,0);
% m=0:2:n; m=m';
% moms_even_degree=2./(1-m.^2);
% moms(m+1,1)=moms_even_degree;





%--------------------------------------------------------------------------
% clenshaw_curtis
%--------------------------------------------------------------------------

function [x,w]=clenshaw_curtis(n,moms)

% OBJECT: CLENSHAW-CURTIS RULE.

% INPUTS:
% n: NUMBER OF POINTS. TESTED WITH n <= 14 MILLION NODES.
% moms: WEIGHT FUNCTION MODIFIED MOMENTS (w.r.t. CHEB. POLY. TYPE I).

% OUTPUTS:
% x: QUADRATURE NODES IN THE INTERVAL [-1,1]. COLUMN VECTOR.
% w: QUADRATURE WEIGHTS. COLUMN VECTOR.

% REFERENCE:
% ALVISE SOMMARIVA
% "Fast Construction of Fej?er and Clenshaw-Curtis rules for general weight
% functions".

% AUTHOR:
% ALVISE SOMMARIVA, JULY 23, 2012.

if nargin < 2
    moms=moms_cheb1type_legendre(n-1);
end

momsIIcc=compute_moments_IIwcc(n-3,moms);
theta=(1:n-2)'*pi/(n-1); xx=cos(theta);
w=((2*sin(theta)/(n-1)).*dst(momsIIcc))./(1-xx.^2);
w1=(2*sum(moms)-moms(1)-moms(end))/(2*(n-1));
wn=moms(1)-w1-sum(w);
x=[1;xx;-1]; w=[w1;w;wn];





%--------------------------------------------------------------------------
% compute_moments_IIwcc
%--------------------------------------------------------------------------

function [momsII,momsI]=compute_moments_IIwcc(n,momsI)

% COMPUTATION OF MOMENTS W.R.T. CHEBYSHEV SECOND TYPE FROM CHEBYSHEV FIRST
% TYPE.

momsI=momsI(1:n+3);
momsII=0.5*(momsI(1:end-2)-momsI(3:end));





% function moms=moms_cheb1type_legendre(n)
% 
% moms=zeros(n+1,0);
% m=0:2:n; m=m';
% moms_even_degree=2./(1-m.^2);
% moms(m+1,1)=moms_even_degree;





%--------------------------------------------------------------------------
% moms_cheb1type_trig
%--------------------------------------------------------------------------


function moms=moms_cheb1type_trig(n,omega)

% fprintf('\n \t SUBRANGE');

moms=zeros(1,n+1);
moms(1)=2*omega; % FIRST MOMENT.

if(n>=2)

    if(omega<=1/4*pi)
        l=10;
    elseif(omega<=1/2*pi)
        l=20;
    elseif(omega<=3/4*pi)
        l=40;
    else
        if omega == pi
            l=2*ceil(10*pi);
        else
            l=2*ceil(10*pi/(pi-omega));
        end
    end


    temp=(2:2:n+2*l-2); % AUXILIAR VECTORS.
    temp2=temp.^2-1;

    dl=1/4 -1./(4*(temp-1)); % DIAGONALS.
    dc=1/2 -1/sin(omega/2)^2 -1./(2*temp2);
    du=1/4 +1./(4*(temp+1));

    d=4*cos(omega/2)/sin(omega/2)./temp2'; % COMPUTING KNOWN TERM.
    d(end)=d(end);                         % PUT LAST MOMENT NULL.

    z=tridisolve(dl(2:end),dc,du(1:end-1),d); % SOLVE SYSTEM.
    moms(3:2:n+1)=z(1:floor(n/2)); % SET ODD MOMENTS.

end

moms=moms';

normalized = 1;

if normalized == 0
    M=length(moms);
    kk=2.^(-((1:2:M)-2))'; kk(1)=1;
    v=ones(M,1);
    v(1:2:M)=kk;
    moms=v.*moms;
end





%--------------------------------------------------------------------------
% tridisolve
%--------------------------------------------------------------------------

function x = tridisolve(a,b,c,d)
%   TRIDISOLVE  Solve tridiagonal system of equations.
% From Cleve Moler's Matlab suite
% http://www.mathworks.it/moler/ncmfilelist.html

%     x = TRIDISOLVE(a,b,c,d) solves the system of linear equations
%     b(1)*x(1) + c(1)*x(2) = d(1),
%     a(j-1)*x(j-1) + b(j)*x(j) + c(j)*x(j+1) = d(j), j = 2:n-1,
%     a(n-1)*x(n-1) + b(n)*x(n) = d(n).
%
%   The algorithm does not use pivoting, so the results might
%   be inaccurate if abs(b) is much smaller than abs(a)+abs(c).
%   More robust, but slower, alternatives with pivoting are:
%     x = T\d where T = diag(a,-1) + diag(b,0) + diag(c,1)
%     x = S\d where S = spdiags([[a; 0] b [0; c]],[-1 0 1],n,n)

% optimized version
x = d;
n = length(x);
bi = zeros(n,1);

for j = 1:n-1
    bi(j) = 1 / b(j);
    mu = a(j) * bi(j);
    b(j+1) = b(j+1) - mu * c(j);
    x(j+1) = x(j+1) - mu * x(j);
end

x(n) = x(n) / b(n);
for j = n-1:-1:1
    x(j) = (x(j) - c(j) * x(j+1)) * bi(j);
end
