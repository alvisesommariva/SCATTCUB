The main Matlab code used in our numerical tests, can be found in the folder "General" 
and is named "demo_scattcub_driver_01.m".

There You can change the domain, the algebraic degrees of exactness of the rule, cardinali-
ty and type of the scattered data.

The directory "EXTERNAL_ROUTINES" contains methods and cubature rules used in the paper.