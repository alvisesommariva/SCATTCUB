

function [f,fs]=gallery_2D(example)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Battery of bivariate test functions.
%--------------------------------------------------------------------------
% INPUT
%--------------------------------------------------------------------------
% example: parameter that chooses the function
%--------------------------------------------------------------------------
% OUTPUT
%--------------------------------------------------------------------------
% f : function to be tested
%--------------------------------------------------------------------------
% PAPERS
%--------------------------------------------------------------------------
% 1. Algorithm 792: Accuracy Tests of ACM Algorithms for Interpolation of
%    Scattered Data in the Plane
%    ROBERT J. RENKA and RON BROWN
%    ACM Transactions on Mathematical Software, Volume 25, Issue 1,pp.78–94
%    https://doi.org/10.1145/305658.305745
%--------------------------------------------------------------------------

switch example
    case -2
        f=@(x,y) 1./(1+25*(x+2*y).^2);
        fs='1./(1+25*(x+2*y).^2)';
    case -1
        f=@(x,y) exp(x+2*y).*cos(10*(x+2*y)).*tanh(4*(x+2*y));
        fs='exp(x+2*y).*cos(10*(x+2*y)).*tanh(4*(x+2*y))';
    case 1 % Renka, Brown, F1
        f=@(x,y) franke(x,y);
    case 2 % Renka, Brown, F2
        f=@(x,y) (tanh(9*y-9*x)+1)/9;
    case 3 % Renka, Brown, F3
        f=@(x,y) (1.25+cos(5.4*y))./(6+6*(3*x-1).^2);
    case 4 % Renka, Brown, F4
        f=@(x,y) (1/3)*exp(-5.0625*((x-0.5).^2+(y-0.5).^2));
    case 5 % Renka, Brown, F5
        f=@(x,y) (1/3)*exp(-20.25*((x-0.5).^2+(y-0.5).^2));
    case 6 % Renka, Brown, F6
        f=@(x,y) (1/9)*sqrt(64-81*((x-0.5).^2+(y-0.5).^2))-0.5;
    case 7 % Renka, Brown, F7
        f=@(x,y) 2*cos(10*x).*sin(10*y)+sin(10*x.*y);
    case 8 % Renka, Brown, F8
        f=@(x,y) exp(-(5-10*x).^2/2)+0.75*exp(-(5-10*y).^2/2)+...
            0.75*(exp(-(5-10*x).^2/2).*exp(-(5-10*y).^2/2);
    case 9 % Renka, Brown, F9
        g=@(x) exp((10-20*x)/3);
        f=@(x,y) ((20/3)^3*g(x).*g(y)).^2.*...
            ((1./(1+g(x))).*(1./(1+g(y)))).^5.*...
            (g(x)-2./(1+g(x))).*(g(x)-2./(1+g(y)));
    case 10 % Renka, Brown, F10
        g=@(x,y) sqrt((80*x-40).^2+(90*y-45).^2);
        f=@(x,y) exp(-0.04*g(x,y)).*cos(0.15*g(x,y));

end


