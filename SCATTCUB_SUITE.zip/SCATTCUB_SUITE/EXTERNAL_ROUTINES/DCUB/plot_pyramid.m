
function plot_pyramid(basis_structure,V,elev,pts1,pts2)

%--------------------------------------------------------------------------
% Object:
% Plot the "frames" of a cone with base determined by points stored in "P"
% vertex in "V" and elevation "elev". Furthermore it plots the points
% stored in "pts".
%--------------------------------------------------------------------------
% Input:
% P: column array of 2D mesh points (cone basis),
% V: vertex (cone vertex),
% elev: elevation of the cut in percentage,
% pts1: points belonging to the cone (first set).
% pts2: points belonging to the cone (second set).
%--------------------------------------------------------------------------

if nargin < 4, pts1=[]; end
if nargin < 5, pts2=[]; end

domain_basis=basis_structure.domain;

switch domain_basis
    case 'disk'
        basis_disk=basis_structure.parms;
        C(1)=basis_disk(1); C(2)=basis_disk(2); r=basis_disk(3);
        theta=linspace(0,2*pi,30); theta=[theta(1:end-1)'; 0];
        P=[C(1)+r*cos(theta) C(2)+r*sin(theta)];
    otherwise
        P=basis_structure.parms;
end

if isempty(P) == 0
    XP=P(:,1); YP=P(:,2); ZP=zeros(size(YP));
    
    for k=1:size(P,1)-1
        XL=[V(1); XP(k:k+1); V(1)];
        YL=[V(2); YP(k:k+1); V(2)];
        ZL=[V(3); ZP(k:k+1); V(3)];
        plot3(XL,YL,ZL);
        hold on;
    end
end

if isempty(pts1) == 0
    plot3(pts1(:,1),pts1(:,2),pts1(:,3),'*','color','red','MarkerSize',1);
end

if isempty(pts2) == 0
    plot3(pts2(:,1),pts2(:,2),pts2(:,3),'o','color','blue','MarkerSize',6);
end


hold off;