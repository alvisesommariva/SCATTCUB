

function domain_structure=gallery_domains_2D(domain_str,domain_example)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Gallery of multivariate domains.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% domain_str: string representing the domain; possible options are 
%     'NURBS','union-disks','polygcirc','polygon'.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% domain_structure: structure defining a domain of "domain_str" kind, taken 
%     from a gallery of domains.
%--------------------------------------------------------------------------
% DATE:
%--------------------------------------------------------------------------
% June 15, 2023.
%--------------------------------------------------------------------------

domain_structure.domain=domain_str;

switch domain_str

    case 'NURBS'
        [geometry_NURBS,domain_str]=gallery_NURBS(domain_example);
        domain_structure.NURBS=geometry_NURBS;

    case 'union-disks'

        [cents,rs]=gallery_uniondisks(domain_example);
        domain_structure.centers=cents;
        domain_structure.radii=rs;

    case 'polygcirc'

        [cc,r,a,b,v,conv]=gallery_polygcirc(domain_example);
        domain_structure.center=(cc(:))';
        domain_structure.radius=r;
        domain_structure.extrema=[(a(:))'; (b(:))'];
        domain_structure.vertices=v;
        domain_structure.convex=conv;

    case 'polygon'
        [P,domain_str]=gallery_polygons(domain_example);
        domain_structure.polyshape=P;
        domain_structure.vertices=P.Vertices;

    otherwise

        fprintf(1,'Gallery not available for domain'); disp(domain_str);

end

domain_structure.dbox=domain_boundingbox(domain_structure);








function [geometry_NURBS,domain_str]=gallery_NURBS(example)

if nargin < 1, example=13; end

switch example

    case 1 % M-shaped domain

        domain_str='S(3): M shaped domain';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 -1; 1 -1; 1 0; 1 1; 0.6 1; 0 0.4; -0.6 1; -1 1];
        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 2

        domain_str='S(4): domain defined by a disk, an ellipse, a segment';
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',[0 0],'angles',[pi/2 3*pi/2],'ell_axis',[0.5 1],...
            'tilt_angle',0);

        % add a final segment
        Pend=lastpointNURBSPL(geometry_NURBS(2));
        Pinit=firstpointNURBSPL(geometry_NURBS(1));
        geometry_NURBS(3)=makeNURBSarc('segment','vertices',[Pend; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

    case 3 % lune-like
        domain_str='S(5): lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        knots=[0 0 0 .15 .25 .25 .5 .5 .75 .75 1 1 1];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1];
        order=3;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 4 % square/disk difference
        domain_str='domain 4';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));


        % add arc of an ellipse
        v=[0.5 0;0.5 0.5;0 0.5];
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 5 % polygon/disk union
        domain_str='domain 5';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0.25 0.25],'angles',[pi pi+pi/2],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 6 % polygon/disk union
        domain_str='domain 6';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.25 0.2; 0.2 0.25];  % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 7 % polygon/disk union
        domain_str='domain 7';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 8 % polygon/disk union
        domain_str='domain 8: square';

        v=[0 0; 1 0; 1 1; 0 1; 0 0];
        geometry_NURBS(1)=makeNURBSarc('polygonal_arc',...
            'vertices',v);


    case 9 % polygon/disk union
        domain_str='domain 9: union of rectangles';

        % add arc of an ellipse
        v=[0 0; 1 0; 1 1; 2 1; 2 2; 1 2; 1 1.5; 0 1.5; 0 1.25; -0.5 1.25; ...
            -0.5 0; 0 0];
        geometry_NURBS(1)=makeNURBSarc('polygonal_arc',...
            'vertices',v);


    case 10
        domain_str='domain 10: square';
        P=[0 0; 1 0; 1 1; 0 1; 0 0];
        geometry_NURBS=makeNURBSarc('polygonal_arc','vertices',P);

    case 11 % circle
        domain_str='domain 11: circle';
        geometry_NURBS=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 2*pi],'radius',1);

    case 12 % lune-like
        domain_str='domain 12: lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free',...
            'P',P,'knots',knots,'weights',w,'order',order);


    case 13 % tau-like-symbol
        domain_str='domain 13: tau-like-symbol';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5;  ...
            0.2 -0.45; -0.4 -0.4; 0 -1; 1 -1;  1 0];
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 14 % cubic-domain
        domain_str='domain 14: cubic-domain: leaf';
        P=[1 0; 1 1; 0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);



    case 15 % cubic-domain: nut
        domain_str='domain 15: cubic-domain: slanted nut';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 16 % cubic-domain: slanted boomerang
        domain_str='domain 16: cubic-domain: golf club';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c/2 1 c/4 1 c/4 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 17 % cubic-domain: nut
        domain_str='domain 17: cubic-domain: dino head';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c/2 1 c/4 1 c/4 1 1 c 1];


        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 18 % cubic-domain: slanted boomerang
        domain_str='domain 18: cubic-domain: tadpole';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 -0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 1 1 1 1 1 1 1 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 19 % cubic-domain: nut
        domain_str='domain 19: cubic-domain: nose';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 5 5 5 5 5 5 5 1];


        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 20 % rough-ball
        domain_str='domain 20: rough ball';
        order=3;
        sidesL=20;
        t=linspace(0,2*pi,sidesL); t=t';
        P=[cos(t) sin(t)]; P=[P(1:end-1,:); P(1,:)];
        knots_mid=linspace(0.1,0.9,sidesL-order);
        knots=[zeros(1,order) knots_mid ones(1,order)];
        M=size(P,1);
        % w=rand(1,M);
        w=[ 8.258169774895474e-01
            5.383424352600571e-01
            9.961347166268855e-01
            7.817552875318368e-02
            4.426782697754463e-01
            1.066527701805844e-01
            9.618980808550537e-01
            4.634224134067444e-03
            7.749104647115024e-01
            8.173032206534330e-01
            8.686947053635097e-01
            8.443584551091032e-02
            3.997826490988965e-01
            2.598704028506542e-01
            8.000684802243075e-01
            4.314138274635446e-01
            9.106475944295229e-01
            1.818470283028525e-01
            2.638029165219901e-01
            1.455389803847170e-01]';

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 21 % L-shaped domain

        domain_str='domain 21: L shaped domain';
        P=[-1 1; -1 -1; 1 -1; 1 -0.6; -0.6 -0.6; -0.6 1; -1 1]; % 7 points
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        w=[0.2 5 10 10 100 5 0.2];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 22 % variable order
        domain_str='domain 22, defined by a disk, an ellipse and a segment';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],...
            'ell_axis',[1 2],'tilt_angle',0);

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(2));

        % "close" the boundary with a segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',...
            [Pend; Pinit]);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 23 % variable order

        domain_str1='domain 23, defined by a disk, an ellipse, a segment';
        domain_str2=' and a free NURBS (variable order)';
        domain_str=strcat(domain_str1,domain_str2);

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',[Pend; 0 Pend(2)]);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS);

        % "close" the boundary with a "free" NURBS.
        geometry_NURBS(4)=makeNURBSarc('free',...
            'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],...
            'knots',[0 0 0 0 1 1 1 1],'weights',[1 1 2 1],'order',4);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

    case 24 % variable order

        domain_str='domain 24, defined by a disk, an ellipse, a segment';
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',[0 0],'angles',[pi/2 3*pi/2],'ell_axis',[0.5 1],...
            'tilt_angle',0);

        % add a final segment
        Pend=lastpointNURBSPL(geometry_NURBS(2));
        Pinit=firstpointNURBSPL(geometry_NURBS(1));
        geometry_NURBS(3)=makeNURBSarc('segment','vertices',[Pend; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 25 % cubic-domain: nut (PROBLEMS IN INTEGRATION)!
        domain_str='domain 25: 15-inverse cubic-domain: slanted nut';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        P=P(:,[2 1]);
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 26 % lune-like
        domain_str='S(26): lune-like';
        P=[1 0; 0.45 0.37; 1.5 1.5; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        knots=[0 0 0 .15 .25 .25 .5 .5 .75 .75 1 1 1];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1];
        order=3;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 27 % M-shaped domain (YX)

        domain_str='S(27): sigma domain (reverse)';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 -1; 1 -1; 1 0; 1 1; 0.6 1; 0 0.4; -0.6 1; -1 1];
        P=[-P(:,2) P(:,1)];
        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);




    case 28 % M-shaped domain (YX)

        domain_str='S(28):';
        order=3;


        P=[-1.000000000000000e+00 0.000000000000000e+00
            -2.000000000000000e+00 -1.000000000000000e+00
            -1.500000000000000e+00 -2.000000000000000e+00
            0.000000000000000e+00 -1.600000000000000e+00
            0.000000000000000e+00 -1.000000000000000e+00
            -0.2 -0.5
            -0.38 -0.75
            -0.20 -0.94
            -0.57 -1.28
            -1.000000000000000e+00 0.000000000000000e+00];

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 29

        domain_str='S(29):';
        order=3;


        P=[   0.49804687500000   0.23832417582418
            0.52148437500000   0.29601648351648
            0.55507812500000   0.35233516483516
            0.58398437500000   0.40315934065934
            0.58242187500000   0.42513736263736
            0.56757812500000   0.43475274725275
            0.54414062500000   0.41826923076923
            0.52226562500000   0.38942307692308
            0.49570312500000   0.38392857142857
            0.48710937500000   0.41552197802198
            0.48945312500000   0.47184065934066
            0.49882812500000   0.54601648351648
            0.50195312500000   0.62019230769231
            0.49257812500000   0.64766483516484
            0.47773437500000   0.63667582417582
            0.46601562500000   0.55975274725275
            0.45039062500000   0.47733516483516
            0.45273437500000   0.57760989010989
            0.45117187500000   0.65728021978022
            0.43085937500000   0.67788461538462
            0.41757812500000   0.65178571428571
            0.41679687500000   0.57074175824176
            0.41445312500000   0.48008241758242
            0.40195312500000   0.55700549450549
            0.38632812500000   0.63667582417582
            0.37304687500000   0.64766483516484
            0.36210937500000   0.62568681318681
            0.36992187500000   0.53640109890110
            0.37695312500000   0.44848901098901
            0.34492187500000   0.50068681318681
            0.32070312500000   0.54876373626374
            0.30195312500000   0.55151098901099
            0.29882812500000   0.53090659340659
            0.32460937500000   0.45398351648352
            0.34570312500000   0.40041208791209
            0.34960937500000   0.32074175824176
            0.35976562500000   0.23832417582418
            0.49804687500000   0.23832417582418];

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 30

        domain_str='S(30):';
        order=3;


        P=[  -1.000000000000000e+00 0.000000000000000e+00
            -2.000000000000000e+00 -1.000000000000000e+00
            -1.500000000000000e+00 -2.000000000000000e+00
            0.000000000000000e+00 -1.600000000000000e+00
            0.000000000000000e+00 -1.000000000000000e+00
            -1.836970198721030e-16 -1.000000000000000e+00
            -1.570731731182077e-02 -9.998766324816606e-01
            -3.141075907812830e-02 -9.995065603657316e-01
            -4.710645070964257e-02 -9.988898749619700e-01
            -6.279051952931321e-02 -9.980267284282716e-01
            -7.845909572784557e-02 -9.969173337331280e-01
            -9.410831331851485e-02 -9.955619646030800e-01
            -1.097343110910457e-01 -9.939609554551796e-01
            -1.253332335643046e-01 -9.921147013144778e-01
            -1.409012319375829e-01 -9.900236577165575e-01
            -1.564344650402310e-01 -9.876883405951377e-01
            -1.719291002794096e-01 -9.851093261547739e-01
            -1.873813145857246e-01 -9.822872507286887e-01
            -2.027872953565124e-01 -9.792228106217657e-01
            -2.181432413965424e-01 -9.759167619387474e-01
            -2.334453638559051e-01 -9.723699203976767e-01
            -2.486898871648553e-01 -9.685831611286310e-01
            -2.638730499653733e-01 -9.645574184577980e-01
            -2.789911060392296e-01 -9.602936856769430e-01
            -2.940403252323042e-01 -9.557930147983300e-01
            -3.090169943749476e-01 -9.510565162951535e-01
            -3.239174181981495e-01 -9.460853588275453e-01
            -3.387379202452914e-01 -9.408807689542255e-01
            -3.534748437792570e-01 -9.354440308298674e-01
            -3.681245526846778e-01 -9.297764858882515e-01
            -3.826834323650903e-01 -9.238795325112865e-01
            -3.971478906347811e-01 -9.177546256839809e-01
            -4.115143586051092e-01 -9.114032766354451e-01
            -4.257792915650729e-01 -9.048270524660194e-01
            -4.399391698559154e-01 -8.980275757606155e-01
            -4.539904997395469e-01 -8.910065241883678e-01
            -4.679298142605735e-01 -8.837656300886934e-01
            -4.817536741017153e-01 -8.763066800438636e-01
            -4.954586684324074e-01 -8.686315144381913e-01
            -5.090414157503719e-01 -8.607420270039433e-01
            -5.224985647159486e-01 -8.526401643540924e-01
            -5.358267949789971e-01 -8.443279255020149e-01
            -5.490228179981321e-01 -8.358073613682701e-01
            -5.620833778521309e-01 -8.270805742745616e-01
            -5.750052520432788e-01 -8.181497174250233e-01
            -5.877852522924732e-01 -8.090169943749473e-01
            -6.004202253258841e-01 -7.996846584870905e-01
            -6.129070536529765e-01 -7.901550123756904e-01
            -6.252426563357051e-01 -7.804304073383298e-01
            -6.374239897486895e-01 -7.705132427757894e-01
            -6.494480483301841e-01 -7.604059656000306e-01
            -6.613118653236519e-01 -7.501110696304595e-01
            -6.730125135097736e-01 -7.396310949786095e-01
            -6.845471059286889e-01 -7.289686274214113e-01
            -6.959127965923145e-01 -7.181262977631887e-01
            -7.071067811865477e-01 -7.071067811865475e-01
            -7.181262977631889e-01 -6.959127965923143e-01
            -7.289686274214116e-01 -6.845471059286887e-01
            -7.396310949786099e-01 -6.730125135097731e-01
            -7.501110696304597e-01 -6.613118653236517e-01
            -7.604059656000310e-01 -6.494480483301835e-01
            -7.705132427757893e-01 -6.374239897486896e-01
            -7.804304073383297e-01 -6.252426563357052e-01
            -7.901550123756906e-01 -6.129070536529763e-01
            -7.996846584870907e-01 -6.004202253258839e-01
            -8.090169943749475e-01 -5.877852522924730e-01
            -8.181497174250235e-01 -5.750052520432785e-01
            -8.270805742745618e-01 -5.620833778521306e-01
            -8.358073613682704e-01 -5.490228179981315e-01
            -8.443279255020152e-01 -5.358267949789964e-01
            -8.526401643540923e-01 -5.224985647159487e-01
            -8.607420270039439e-01 -5.090414157503709e-01
            -8.686315144381914e-01 -4.954586684324072e-01
            -8.763066800438637e-01 -4.817536741017150e-01
            -8.837656300886936e-01 -4.679298142605732e-01
            -8.910065241883679e-01 -4.539904997395467e-01
            -8.980275757606156e-01 -4.399391698559151e-01
            -9.048270524660195e-01 -4.257792915650727e-01
            -9.114032766354452e-01 -4.115143586051089e-01
            -9.177546256839813e-01 -3.971478906347804e-01
            -9.238795325112868e-01 -3.826834323650897e-01
            -9.297764858882515e-01 -3.681245526846779e-01
            -9.354440308298675e-01 -3.534748437792568e-01
            -9.408807689542256e-01 -3.387379202452911e-01
            -9.460853588275454e-01 -3.239174181981492e-01
            -9.510565162951536e-01 -3.090169943749473e-01
            -9.557930147983301e-01 -2.940403252323039e-01
            -9.602936856769431e-01 -2.789911060392293e-01
            -9.645574184577982e-01 -2.638730499653726e-01
            -9.685831611286312e-01 -2.486898871648546e-01
            -9.723699203976767e-01 -2.334453638559053e-01
            -9.759167619387474e-01 -2.181432413965425e-01
            -9.792228106217657e-01 -2.027872953565125e-01
            -9.822872507286887e-01 -1.873813145857243e-01
            -9.851093261547740e-01 -1.719291002794093e-01
            -9.876883405951378e-01 -1.564344650402307e-01
            -9.900236577165575e-01 -1.409012319375826e-01
            -9.921147013144779e-01 -1.253332335643043e-01
            -9.939609554551797e-01 -1.097343110910454e-01
            -9.955619646030800e-01 -9.410831331851410e-02
            -9.969173337331280e-01 -7.845909572784482e-02
            -9.980267284282716e-01 -6.279051952931335e-02
            -9.988898749619700e-01 -4.710645070964227e-02
            -9.995065603657316e-01 -3.141075907812799e-02
            -9.998766324816606e-01 -1.570731731182046e-02
            -1.000000000000000e+00 0.000000000000000e+00];


        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 31

        domain_str='S(31):';
        order=3;


        P=[  -1.000000000000000e+00 0.000000000000000e+00
            -2.000000000000000e+00 -1.000000000000000e+00
            -1.500000000000000e+00 -2.000000000000000e+00
            0.000000000000000e+00 -1.600000000000000e+00
            0.000000000000000e+00 -1.000000000000000e+00
            0.000000000000000e+00 -1.000000000000000e+00
            -1.233675183394123e-04 -9.842926826881794e-01
            -4.934396342684000e-04 -9.685892409218717e-01
            -1.110125038029985e-03 -9.528935492903573e-01
            -1.973271571728441e-03 -9.372094804706866e-01
            -3.082666266872036e-03 -9.215409042721551e-01
            -4.438035396920004e-03 -9.058916866814857e-01
            -6.039044544820293e-03 -8.902656889089547e-01
            -7.885298685522124e-03 -8.746667664356957e-01
            -9.976342283442463e-03 -8.590987680624174e-01
            -1.231165940486223e-02 -8.435655349597692e-01
            -1.489067384522613e-02 -8.280708997205904e-01
            -1.771274927131128e-02 -8.126186854142754e-01
            -2.077718937823425e-02 -7.972127046434875e-01
            -2.408323806125257e-02 -7.818567586034575e-01
            -2.763007960232344e-02 -7.665546361440947e-01
            -3.141683887136892e-02 -7.513101128351451e-01
            -3.544258154220192e-02 -7.361269500346270e-01
            -3.970631432305693e-02 -7.210088939607707e-01
            -4.420698520166988e-02 -7.059596747676961e-01
            -4.894348370484647e-02 -6.909830056250525e-01
            -5.391464117245470e-02 -6.760825818018505e-01
            -5.911923104577455e-02 -6.612620797547086e-01
            -6.455596917013262e-02 -6.465251562207429e-01
            -7.022351411174854e-02 -6.318754473153221e-01
            -7.612046748871326e-02 -6.173165676349102e-01
            -8.224537431601886e-02 -6.028521093652194e-01
            -8.859672336455471e-02 -5.884856413948912e-01
            -9.517294753398042e-02 -5.742207084349273e-01
            -1.019724242393844e-01 -5.600608301440848e-01
            -1.089934758116321e-01 -5.460095002604533e-01
            -1.162343699113065e-01 -5.320701857394267e-01
            -1.236933199561364e-01 -5.182463258982847e-01
            -1.313684855618088e-01 -5.045413315675924e-01
            -1.392579729960564e-01 -4.909585842496287e-01
            -1.473598356459077e-01 -4.775014352840512e-01
            -1.556720744979849e-01 -4.641732050210033e-01
            -1.641926386317297e-01 -4.509771820018682e-01
            -1.729194257254382e-01 -4.379166221478694e-01
            -1.818502825749766e-01 -4.249947479567214e-01
            -1.909830056250525e-01 -4.122147477075269e-01
            -2.003153415129094e-01 -3.995797746741161e-01
            -2.098449876243096e-01 -3.870929463470235e-01
            -2.195695926616702e-01 -3.747573436642949e-01
            -2.294867572242107e-01 -3.625760102513104e-01
            -2.395940343999691e-01 -3.505519516698163e-01
            -2.498889303695404e-01 -3.386881346763482e-01
            -2.603689050213903e-01 -3.269874864902267e-01
            -2.710313725785884e-01 -3.154528940713114e-01
            -2.818737022368111e-01 -3.040872034076857e-01
            -2.928932188134524e-01 -2.928932188134525e-01
            -3.040872034076857e-01 -2.818737022368112e-01
            -3.154528940713113e-01 -2.710313725785884e-01
            -3.269874864902267e-01 -2.603689050213903e-01
            -3.386881346763481e-01 -2.498889303695405e-01
            -3.505519516698163e-01 -2.395940343999691e-01
            -3.625760102513103e-01 -2.294867572242107e-01
            -3.747573436642947e-01 -2.195695926616703e-01
            -3.870929463470235e-01 -2.098449876243096e-01
            -3.995797746741159e-01 -2.003153415129095e-01
            -4.122147477075268e-01 -1.909830056250527e-01
            -4.249947479567214e-01 -1.818502825749766e-01
            -4.379166221478693e-01 -1.729194257254382e-01
            -4.509771820018683e-01 -1.641926386317297e-01
            -4.641732050210035e-01 -1.556720744979849e-01
            -4.775014352840511e-01 -1.473598356459078e-01
            -4.909585842496288e-01 -1.392579729960564e-01
            -5.045413315675924e-01 -1.313684855618087e-01
            -5.182463258982848e-01 -1.236933199561363e-01
            -5.320701857394267e-01 -1.162343699113065e-01
            -5.460095002604531e-01 -1.089934758116322e-01
            -5.600608301440849e-01 -1.019724242393844e-01
            -5.742207084349273e-01 -9.517294753398042e-02
            -5.884856413948911e-01 -8.859672336455482e-02
            -6.028521093652195e-01 -8.224537431601886e-02
            -6.173165676349102e-01 -7.612046748871326e-02
            -6.318754473153219e-01 -7.022351411174865e-02
            -6.465251562207428e-01 -6.455596917013273e-02
            -6.612620797547085e-01 -5.911923104577455e-02
            -6.760825818018505e-01 -5.391464117245470e-02
            -6.909830056250525e-01 -4.894348370484647e-02
            -7.059596747676959e-01 -4.420698520166988e-02
            -7.210088939607705e-01 -3.970631432305705e-02
            -7.361269500346272e-01 -3.544258154220192e-02
            -7.513101128351453e-01 -3.141683887136892e-02
            -7.665546361440945e-01 -2.763007960232344e-02
            -7.818567586034573e-01 -2.408323806125268e-02
            -7.972127046434873e-01 -2.077718937823425e-02
            -8.126186854142753e-01 -1.771274927131139e-02
            -8.280708997205904e-01 -1.489067384522613e-02
            -8.435655349597690e-01 -1.231165940486223e-02
            -8.590987680624171e-01 -9.976342283442463e-03
            -8.746667664356955e-01 -7.885298685522235e-03
            -8.902656889089546e-01 -6.039044544820293e-03
            -9.058916866814857e-01 -4.438035396920004e-03
            -9.215409042721550e-01 -3.082666266872036e-03
            -9.372094804706865e-01 -1.973271571728441e-03
            -9.528935492903573e-01 -1.110125038029985e-03
            -9.685892409218716e-01 -4.934396342684000e-04
            -9.842926826881794e-01 -1.233675183394123e-04
            -1.000000000000000e+00 0.000000000000000e+00];


        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);



    case 32

        domain_str='S(32):';
        order=3;


        P=[   0.49804687500000   0.23832417582418
            0.52148437500000   0.29601648351648
            0.55507812500000   0.35233516483516
            0.58398437500000   0.40315934065934
            0.58242187500000   0.42513736263736
            0.56757812500000   0.43475274725275
            0.54414062500000   0.41826923076923
            0.52226562500000   0.38942307692308
            0.49570312500000   0.38392857142857
            0.48710937500000   0.41552197802198
            0.48945312500000   0.47184065934066
            0.49882812500000   0.54601648351648
            0.50195312500000   0.62019230769231
            0.49257812500000   0.64766483516484
            0.47773437500000   0.63667582417582
            0.46601562500000   0.55975274725275
            0.45039062500000   0.47733516483516
            0.45273437500000   0.57760989010989
            0.45117187500000   0.65728021978022
            0.43085937500000   0.67788461538462
            0.41757812500000   0.65178571428571
            0.41679687500000   0.57074175824176
            0.41445312500000   0.48008241758242
            0.40195312500000   0.55700549450549
            0.38632812500000   0.63667582417582
            0.37304687500000   0.64766483516484
            0.36210937500000   0.62568681318681
            0.36992187500000   0.53640109890110
            0.37695312500000   0.44848901098901
            0.34492187500000   0.50068681318681
            0.32070312500000   0.54876373626374
            0.30195312500000   0.55151098901099
            0.29882812500000   0.53090659340659
            0.32460937500000   0.45398351648352
            0.34570312500000   0.40041208791209
            0.34960937500000   0.32074175824176
            0.35976562500000   0.23832417582418
            0.49804687500000   0.23832417582418];

        P=[-P(:,2) P(:,1)];

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 33


        domain_str='S(33):';
        order=3;

        P=[     1.330645161290322e-01     2.518231115830866e-01
            1.008064516129032e-01     1.934289509991451e-01
            1.146313364055299e-01     1.145968342108239e-01
            1.814516129032258e-01     7.956033786045881e-02
            2.759216589861751e-01     8.539975391885314e-02
            3.081797235023041e-01     1.642318707071742e-01
            2.851382488479262e-01     2.167866152327217e-01
            2.759216589861751e-01     2.459836955246925e-01
            3.012672811059907e-01     2.459836955246925e-01
            3.496543778801842e-01     2.459836955246925e-01
            4.187788018433179e-01     2.489034035538896e-01
            4.832949308755759e-01     2.489034035538896e-01
            4.556451612903225e-01     2.021880750867362e-01
            4.625576036866358e-01     9.123916997724725e-02
            5.616359447004607e-01     8.539975391885314e-02
            6.031105990783410e-01     1.554727466195830e-01
            5.754608294930875e-01     2.138669072035246e-01
            5.754608294930875e-01     2.664216517290720e-01
            5.869815668202764e-01     3.656917247217727e-01
            6.123271889400921e-01     4.678815057436705e-01
            6.330645161290321e-01     5.145968342108239e-01
            6.584101382488479e-01     5.729909947947655e-01
            6.745391705069124e-01     5.963486590283421e-01
            6.998847926267280e-01     6.343048634079042e-01
            7.206221198156680e-01     6.781004838458603e-01
            7.367511520737327e-01     7.218961042838166e-01
            6.975806451612903e-01     7.510931845757873e-01
            7.344470046082948e-01     7.978085130429405e-01
            8.081797235023040e-01     7.364946444298019e-01
            7.966589861751151e-01     6.547428196122836e-01
            7.459677419354838e-01     5.729909947947655e-01
            7.459677419354838e-01     4.824800458896559e-01
            8.012672811059907e-01     4.591223816560793e-01
            8.542626728110598e-01     4.649617977144735e-01
            8.542626728110598e-01     5.525530385903860e-01
            8.450460829493087e-01     5.934289509991451e-01
            8.703917050691243e-01     6.372245714371012e-01
            9.164746543778801e-01     6.985384400502399e-01
            9.141705069124422e-01     7.978085130429405e-01
            8.888248847926266e-01     8.708012137728676e-01
            8.058755760368662e-01     8.824800458896559e-01
            7.644009216589861e-01     8.824800458896559e-01
            7.206221198156680e-01     8.416041334808968e-01
            6.975806451612903e-01     8.124070531889260e-01
            6.699308755760368e-01     7.832099728969552e-01
            6.399769585253455e-01     7.160566882254223e-01
            6.399769585253455e-01     6.868596079334516e-01
            6.630184331797234e-01     6.868596079334516e-01
            6.745391705069124e-01     6.751807758166632e-01
            6.284562211981566e-01     6.138669072035247e-01
            6.077188940092165e-01     5.846698269115538e-01
            5.731566820276497e-01     5.642318707071743e-01
            5.547235023041474e-01     5.642318707071743e-01
            4.994239631336404e-01     5.817501188823567e-01
            4.510368663594469e-01     5.992683670575392e-01
            4.095622119815667e-01     6.138669072035247e-01
            3.634792626728110e-01     6.138669072035247e-01
            3.081797235023041e-01     6.021880750867362e-01
            2.690092165898617e-01     5.992683670575392e-01
            2.252304147465437e-01     5.788304108531597e-01
            2.137096774193548e-01     5.700712867655684e-01
            1.699308755760368e-01     5.321150823860064e-01
            1.261520737327189e-01     4.591223816560793e-01
            1.077188940092165e-01     4.036479291013348e-01
            9.158986175115201e-02     3.598523086633786e-01
            7.546082949308751e-02     2.664216517290720e-01
            5.933179723502297e-02     2.109471991743275e-01
            5.933179723502297e-02     1.613121626779771e-01
            5.933179723502297e-02     9.415887800644430e-02
            7.776497695852529e-02     1.233559582984151e-01
            7.776497695852529e-02     1.875895349407508e-01
            9.850230414746534e-02     2.459836955246925e-01
            1.169354838709677e-01     2.926990239918457e-01
            1.468894009216589e-01     3.335749364006049e-01
            1.860599078341013e-01     3.540128926049844e-01
            2.137096774193548e-01     3.510931845757874e-01
            2.137096774193548e-01     3.218961042838166e-01
            1.814516129032258e-01     2.985384400502399e-01
            1.699308755760368e-01     2.839398999042546e-01
            1.330645161290322e-01     2.518231115830866e-01];

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 34


        domain_str='S(34):';
        order=3;

        X=[ -7.019009216589862e-01    -7.135036496350367e-01
            -6.807603686635946e-01    -7.350364963503648e-01
            -6.369815668202765e-01    -7.496350364963502e-01
            -6.001152073732720e-01    -7.437956204379561e-01
            -5.770737327188941e-01    -7.116788321167882e-01
            -5.932027649769586e-01    -6.620437956204379e-01
            -6.093317972350231e-01    -6.240875912408759e-01
            -6.116359447004609e-01    -5.773722627737226e-01
            -6.116359447004609e-01    -5.452554744525546e-01
            -6.093317972350231e-01    -4.985401459854014e-01
            -6.093317972350231e-01    -4.401459854014598e-01
            -6.116359447004609e-01    -3.467153284671532e-01
            -6.162442396313365e-01    -2.941605839416057e-01
            -6.162442396313365e-01    -2.386861313868612e-01
            -6.024193548387098e-01    -2.299270072992700e-01
            -5.839861751152075e-01    -2.445255474452553e-01
            -5.839861751152075e-01    -2.795620437956203e-01
            -5.839861751152075e-01    -3.233576642335765e-01
            -5.839861751152075e-01    -3.525547445255474e-01
            -5.793778801843319e-01    -4.109489051094889e-01
            -5.793778801843319e-01    -4.605839416058393e-01
            -5.793778801843319e-01    -5.160583941605839e-01
            -5.793778801843319e-01    -5.627737226277372e-01
            -5.770737327188941e-01    -6.036496350364963e-01
            -5.747695852534562e-01    -6.357664233576642e-01
            -5.655529953917051e-01    -6.678832116788320e-01
            -5.355990783410138e-01    -6.970802919708028e-01
            -5.148617511520737e-01    -7.175182481751825e-01
            -5.171658986175116e-01    -7.408759124087589e-01
            -4.872119815668203e-01    -7.759124087591240e-01
            -4.733870967741936e-01    -7.467153284671533e-01
            -4.779953917050692e-01    -6.620437956204379e-01
            -5.033410138248848e-01    -6.562043795620437e-01
            -5.194700460829493e-01    -5.919708029197079e-01
            -5.194700460829493e-01    -5.277372262773721e-01
            -5.379032258064516e-01    -4.197080291970802e-01
            -5.379032258064516e-01    -3.525547445255474e-01
            -5.355990783410138e-01    -2.883211678832116e-01
            -5.355990783410138e-01    -2.211678832116788e-01
            -5.355990783410138e-01    -2.153284671532846e-01
            -5.217741935483871e-01    -1.744525547445255e-01
            -4.733870967741936e-01    -1.861313868613138e-01
            -4.687788018433180e-01    -2.328467153284670e-01
            -4.618663594470047e-01    -3.262773722627737e-01
            -4.618663594470047e-01    -3.788321167883211e-01
            -4.618663594470047e-01    -4.489051094890510e-01
            -4.480414746543780e-01    -5.306569343065692e-01
            -4.480414746543780e-01    -5.832116788321168e-01
            -4.226958525345623e-01    -6.357664233576642e-01
            -4.065668202764978e-01    -6.737226277372262e-01
            -3.743087557603688e-01    -7.058394160583941e-01
            -3.420506912442398e-01    -7.175182481751825e-01
            -3.144009216589863e-01    -7.204379562043794e-01
            -2.637096774193549e-01    -7.291970802919707e-01
            -2.130184331797236e-01    -7.291970802919707e-01
            -1.577188940092167e-01    -7.321167883211679e-01
            -1.024193548387098e-01    -7.408759124087589e-01
            -4.251152073732734e-02    -7.437956204379561e-01
            1.048387096774184e-02    -7.437956204379561e-01
            7.269585253456201e-02    -7.437956204379561e-01
            1.118663594470044e-01    -7.437956204379561e-01
            1.487327188940091e-01    -7.437956204379561e-01
            1.648617511520736e-01    -7.116788321167882e-01
            1.279953917050689e-01    -6.766423357664233e-01
            8.882488479262651e-02    -6.766423357664233e-01
            4.274193548387095e-02    -6.708029197080291e-01
            -1.025345622119822e-02    -6.708029197080291e-01
            -9.320276497695856e-02    -6.708029197080291e-01
            -1.738479262672812e-01    -6.620437956204379e-01
            -2.406682027649770e-01    -6.562043795620437e-01
            -2.867511520737328e-01    -6.474452554744525e-01
            -3.144009216589863e-01    -6.474452554744525e-01
            -3.489631336405531e-01    -6.182481751824817e-01
            -3.835253456221199e-01    -5.832116788321168e-01
            -3.835253456221199e-01    -5.452554744525546e-01
            -3.950460829493088e-01    -4.956204379562043e-01
            -3.950460829493088e-01    -4.284671532846715e-01
            -4.019585253456222e-01    -3.788321167883211e-01
            -4.019585253456222e-01    -3.437956204379561e-01
            -3.996543778801844e-01    -3.321167883211678e-01
            -3.973502304147467e-01    -2.766423357664233e-01
            -3.627880184331798e-01    -2.532846715328466e-01
            -3.282258064516130e-01    -3.029197080291970e-01
            -3.259216589861753e-01    -3.437956204379561e-01
            -3.190092165898619e-01    -4.489051094890510e-01
            -3.005760368663595e-01    -5.131386861313867e-01
            -2.867511520737328e-01    -5.510948905109488e-01
            -2.567972350230415e-01    -5.744525547445255e-01
            -2.314516129032259e-01    -5.861313868613138e-01
            -1.738479262672812e-01    -5.919708029197079e-01
            -1.392857142857143e-01    -5.978102189781022e-01
            -1.047235023041475e-01    -5.978102189781022e-01
            -4.942396313364061e-02    -6.007299270072992e-01
            8.179723502304004e-03    -6.007299270072992e-01
            7.269585253456201e-02    -6.007299270072992e-01
            1.210829493087557e-01    -5.656934306569342e-01
            1.072580645161290e-01    -5.043795620437956e-01
            7.960829493087540e-02    -5.043795620437956e-01
            3.352534562211962e-02    -5.189781021897810e-01
            -5.172811059907845e-02    -5.131386861313867e-01
            -1.231566820276498e-01    -4.985401459854014e-01
            -1.784562211981567e-01    -4.810218978102189e-01
            -2.038018433179725e-01    -4.635036496350364e-01
            -2.314516129032259e-01    -4.051094890510948e-01
            -2.383640552995392e-01    -3.437956204379561e-01
            -2.498847926267281e-01    -2.970802919708028e-01
            -2.498847926267281e-01    -2.766423357664233e-01
            -2.383640552995392e-01    -2.503649635036496e-01
            -1.807603686635946e-01    -2.678832116788320e-01
            -1.807603686635946e-01    -3.291970802919708e-01
            -1.531105990783411e-01    -4.226277372262773e-01
            -7.937788018433189e-02    -4.635036496350364e-01
            3.571428571428448e-03    -4.693430656934306e-01
            6.347926267281090e-02    -4.605839416058393e-01
            1.095622119815667e-01    -3.437956204379561e-01
            7.499999999999996e-02    -3.087591240875912e-01
            1.048387096774184e-02    -2.824817518248174e-01
            -6.555299539170512e-02    -2.562043795620437e-01
            -7.707373271889406e-02    -2.036496350364962e-01
            -7.476958525345634e-02    -1.540145985401459e-01
            -4.020737327188950e-02    -1.598540145985401e-01
            3.571428571428448e-03    -2.211678832116788e-01
            8.421658986175107e-02    -2.445255474452553e-01
            1.349078341013823e-01    -2.299270072992700e-01
            1.349078341013823e-01    -1.540145985401459e-01
            1.141705069124423e-01    -9.562043795620434e-02
            5.195852534562206e-02    -7.226277372262768e-02
            1.267281105990725e-03    -6.934306569343063e-02
            -7.016129032258078e-02    -6.642335766423357e-02
            -1.047235023041475e-01    -7.226277372262768e-02
            -1.346774193548388e-01    -9.854014598540140e-02
            -1.531105990783411e-01    -1.189781021897810e-01
            -2.014976958525346e-01    -1.277372262773723e-01
            -2.429723502304149e-01    -1.364963503649634e-01
            -2.821428571428573e-01    -1.423357664233577e-01
            -3.282258064516130e-01    -1.423357664233577e-01
            -3.697004608294932e-01    -1.189781021897810e-01
            -4.088709677419356e-01    -8.978102189781023e-02
            -4.618663594470047e-01    -8.102189781021896e-02
            -5.332949308755761e-01    -8.978102189781023e-02
            -5.701612903225808e-01    -1.043795620437956e-01
            -6.277649769585254e-01    -1.452554744525546e-01
            -6.508064516129033e-01    -2.036496350364962e-01
            -6.669354838709678e-01    -2.737226277372262e-01
            -6.715437788018433e-01    -3.642335766423357e-01
            -6.830645161290323e-01    -4.226277372262773e-01
            -6.830645161290323e-01    -4.868613138686130e-01
            -6.830645161290323e-01    -5.656934306569342e-01
            -6.991935483870968e-01    -6.211678832116788e-01
            -7.038018433179725e-01    -6.854014598540146e-01];

        P=[X; X(1,:)];

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 35

        domain_str='S(35):';
        order=3;

        X=[ -8.516705069124424e-01    -6.843065693430659e-01
            -8.406682027649770e-01    -5.078832116788323e-01
            -8.406682027649770e-01    -3.700729927007301e-01
            -8.406682027649770e-01    -2.743065693430659e-01
            -8.337557603686636e-01    -1.808759124087592e-01
            -8.406682027649770e-01    -7.109489051094908e-02
            -8.291474654377881e-01     1.532846715328451e-02
            -7.830645161290323e-01     1.532846715328451e-02
            -7.830645161290323e-01    -2.437956204379577e-02
            -7.853686635944701e-01    -8.277372262773730e-02
            -7.853686635944701e-01    -1.271532846715330e-01
            -7.853686635944701e-01    -2.205839416058396e-01
            -7.784562211981567e-01    -3.327007299270075e-01
            -7.784562211981567e-01    -3.840875912408761e-01
            -7.761520737327189e-01    -4.424817518248176e-01
            -7.715437788018433e-01    -5.032116788321169e-01
            -7.508064516129033e-01    -5.405839416058396e-01
            -7.070276497695853e-01    -5.522627737226279e-01
            -6.586405529953917e-01    -5.522627737226279e-01
            -5.964285714285714e-01    -5.522627737226279e-01
            -5.365207373271890e-01    -5.499270072992702e-01
            -4.766129032258065e-01    -5.499270072992702e-01
            -4.743087557603687e-01    -5.756204379562045e-01
            -5.296082949308756e-01    -5.756204379562045e-01
            -5.641705069124424e-01    -5.779562043795622e-01
            -5.987327188940093e-01    -5.779562043795622e-01
            -6.632488479262674e-01    -5.779562043795622e-01
            -7.392857142857143e-01    -5.872992700729929e-01
            -7.600230414746544e-01    -6.036496350364965e-01
            -7.369815668202765e-01    -6.433576642335769e-01
            -7.070276497695853e-01    -6.433576642335769e-01
            -6.194700460829493e-01    -6.433576642335769e-01
            -5.457373271889401e-01    -6.433576642335769e-01
            -4.766129032258065e-01    -6.456934306569345e-01
            -3.521889400921659e-01    -6.480291970802922e-01
            -2.669354838709678e-01    -6.503649635036498e-01
            -1.955069124423964e-01    -6.503649635036498e-01
            -1.148617511520738e-01    -6.503649635036498e-01
            -3.421658986175125e-02    -6.456934306569345e-01
            -4.262672811059964e-03    -5.919708029197082e-01
            -1.347926267281108e-02    -5.429197080291973e-01
            -6.186635944700458e-02    -5.616058394160586e-01
            -6.186635944700458e-02    -5.779562043795622e-01
            -1.309907834101383e-01    -5.849635036496352e-01
            -1.724654377880185e-01    -5.872992700729929e-01
            -2.346774193548388e-01    -5.872992700729929e-01
            -3.153225806451613e-01    -5.989781021897812e-01
            -4.051843317972350e-01    -5.896350364963505e-01
            -4.236175115207373e-01    -5.756204379562045e-01
            -4.236175115207373e-01    -5.545985401459855e-01
            -4.120967741935484e-01    -5.545985401459855e-01
            -3.498847926267281e-01    -5.545985401459855e-01
            -2.577188940092167e-01    -5.545985401459855e-01
            -2.070276497695853e-01    -5.452554744525550e-01
            -1.655529953917051e-01    -5.335766423357666e-01
            -9.873271889400925e-02    -5.055474452554747e-01
            -5.034562211981575e-02    -4.938686131386864e-01
            1.647465437788020e-02    -4.448175182481754e-01
            1.417050691244248e-02    -3.864233576642337e-01
            -4.573732718894008e-02    -3.864233576642337e-01
            -9.182027649769586e-02    -4.097810218978104e-01
            -2.277649769585254e-01    -4.191240875912411e-01
            -2.899769585253457e-01    -4.308029197080294e-01
            -4.305299539170507e-01    -4.448175182481754e-01
            -5.157834101382489e-01    -4.167883211678833e-01
            -5.964285714285714e-01    -4.284671532846717e-01
            -6.655529953917051e-01    -4.284671532846717e-01
            -6.678571428571429e-01    -3.560583941605842e-01
            -6.839861751152074e-01    -2.439416058394163e-01
            -6.010368663594471e-01    -2.322627737226278e-01
            -5.941244239631337e-01    -2.813138686131388e-01
            -5.687788018433180e-01    -3.163503649635038e-01
            -4.881336405529955e-01    -3.186861313868615e-01
            -4.097926267281106e-01    -3.186861313868615e-01
            -3.314516129032258e-01    -3.186861313868615e-01
            -2.024193548387097e-01    -3.233576642335768e-01
            -1.402073732718894e-01    -3.233576642335768e-01
            -7.799539170506919e-02    -3.140145985401461e-01
            -1.117511520737335e-02    -2.906569343065696e-01
            5.334101382488488e-02    -2.439416058394163e-01
            3.951612903225810e-02    -2.018978102189782e-01
            -6.566820276497687e-03    -2.112408759124090e-01
            -9.412442396313370e-02    -2.229197080291972e-01
            -2.623271889400922e-01    -2.416058394160586e-01
            -4.144009216589862e-01    -2.626277372262776e-01
            -5.111751152073732e-01    -2.462773722627739e-01
            -5.664746543778802e-01    -1.715328467153286e-01
            -6.448156682027650e-01    -1.691970802919710e-01
            -6.862903225806452e-01    -1.458394160583943e-01
            -6.379032258064516e-01    -8.510948905109506e-02
            -5.503456221198156e-01    -9.678832116788338e-02
            -5.088709677419355e-01    -1.271532846715330e-01
            -4.328341013824885e-01    -1.645255474452556e-01
            -3.521889400921659e-01    -1.645255474452556e-01
            -2.784562211981567e-01    -1.645255474452556e-01
            -1.816820276497696e-01    -1.668613138686134e-01
            -1.263824884792627e-01    -1.645255474452556e-01
            -2.499999999999991e-02    -1.458394160583943e-01
            2.569124423963132e-02    -8.744525547445270e-02
            -4.343317972350236e-02    -7.810218978102201e-02
            -8.260368663594475e-02    -7.810218978102201e-02
            -1.678571428571429e-01    -8.043795620437966e-02
            -3.038018433179723e-01    -8.043795620437966e-02
            -4.558755760368663e-01    -6.875912408759144e-02
            -5.779953917050692e-01    -3.605839416058410e-02
            -6.816820276497696e-01    -3.138686131386870e-02
            -6.609447004608295e-01    -3.357664233576751e-03
            -5.526497695852535e-01    -1.021897810219108e-03
            -4.789170506912442e-01    -3.357664233576751e-03
            -3.383640552995392e-01    -8.029197080292039e-03
            -2.392857142857143e-01    -1.503649635036508e-02
            -1.471198156682028e-01    -1.503649635036508e-02
            -7.799539170506919e-02    -1.503649635036508e-02
            -6.186635944700458e-02     2.467153284671519e-02
            -1.102534562211982e-01     2.467153284671519e-02
            -2.070276497695853e-01     2.934306569343048e-02
            -3.014976958525346e-01     2.934306569343048e-02
            -4.236175115207373e-01     4.335766423357656e-02
            -5.342165898617511e-01     5.036496350364950e-02
            -7.231566820276498e-01     4.335766423357656e-02
            -8.199308755760369e-01     5.503649635036478e-02
            -8.752304147465438e-01     3.401459854014588e-02
            -8.775345622119817e-01    -3.372262773722645e-02
            -8.729262672811060e-01    -1.621897810218980e-01
            -8.752304147465438e-01    -2.602919708029199e-01
            -8.729262672811060e-01    -3.420437956204381e-01
            -8.729262672811060e-01    -4.658394160583943e-01
            -8.798387096774194e-01    -5.756204379562045e-01
            -8.775345622119817e-01    -6.737226277372265e-01];

        P=[X; X(1,:)];

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);





    case 36

        domain_str='S(36): comb';
        order=3;

        xL=linspace(0,1,10);
        t=10^(-2);
        xR=xL+10^(-3);

        s=0.5;

        P=[0 0; 2 0; 2 t; 2-t t; 1-0.5*t t; 1-0.75*t t; ...
            1-0.9*t t; 1-t t; 1-t 1; 1-2*t 1;  ...
            s-t 1; s-t t; s-2*t t; s-2*t 1; s-3*t 1; s-3*t t; ...
            s-4*t t; s-4*t 1; s-5*t 1; s-5*t t; ...
            s-6*t t; s-6*t 1; s-7*t 1; s-7*t t; ...
            0.1 t; 0.05 t; 0.025 t; 0.022 t; 0.020 t; 0 0];


        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=10^6*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 37 % PROBLEMS IN INTEGRATION (negative area)

        domain_str='minion';
        order=3;
        X=[ 1.519500000000000e+03     1.967500000000000e+03
            1.487500000000000e+03     1.803500000000000e+03
            1.487500000000000e+03     1.663500000000000e+03
            1.459500000000000e+03     1.471500000000000e+03
            1.455500000000000e+03     1.319500000000000e+03
            1.451500000000000e+03     1.147500000000000e+03
            1.439500000000000e+03     9.795000000000000e+02
            1.447500000000000e+03     8.715000000000000e+02
            1.475500000000000e+03     8.515000000000000e+02
            1.467500000000000e+03     7.514999999999999e+02
            1.435500000000000e+03     6.594999999999999e+02
            1.391500000000000e+03     5.355000000000000e+02
            1.319500000000000e+03     4.074999999999999e+02
            1.231500000000000e+03     3.315000000000000e+02
            1.139500000000000e+03     2.795000000000000e+02
            1.047500000000000e+03     2.395000000000000e+02
            9.435000000000000e+02     1.875000000000000e+02
            9.754999999999999e+02     1.355000000000000e+02
            1.071500000000000e+03     1.355000000000000e+02
            1.155500000000000e+03     1.355000000000000e+02
            1.215500000000000e+03     1.355000000000000e+02
            1.143500000000000e+03     8.350000000000000e+01
            1.003500000000000e+03     9.150000000000000e+01
            9.395000000000000e+02     1.155000000000000e+02
            9.115000000000000e+02     1.315000000000000e+02
            8.595000000000000e+02     1.755000000000000e+02
            8.395000000000001e+02     1.635000000000000e+02
            8.635000000000000e+02     1.075000000000000e+02
            8.915000000000000e+02     4.750000000000000e+01
            8.635000000000000e+02     3.550000000000000e+01
            8.275000000000001e+02     9.150000000000000e+01
            7.875000000000000e+02     1.715000000000000e+02
            7.595000000000000e+02     7.950000000000000e+01
            7.115000000000000e+02     3.950000000000000e+01
            6.955000000000000e+02     7.950000000000000e+01
            7.195000000000000e+02     1.315000000000000e+02
            7.195000000000000e+02     1.555000000000000e+02
            6.555000000000000e+02     1.075000000000000e+02
            5.875000000000000e+02     1.550000000000000e+01
            4.955000000000000e+02     3.550000000000000e+01
            5.675000000000000e+02     5.550000000000000e+01
            6.155000000000000e+02     1.235000000000000e+02
            5.755000000000000e+02     1.235000000000000e+02
            4.755000000000000e+02     1.275000000000000e+02
            3.435000000000000e+02     1.675000000000000e+02
            2.915000000000000e+02     2.155000000000000e+02
            4.274999999999999e+02     2.075000000000000e+02
            5.315000000000000e+02     2.075000000000000e+02
            4.515000000000000e+02     2.675000000000000e+02
            3.035000000000000e+02     3.434999999999999e+02
            2.235000000000000e+02     4.835000000000000e+02
            1.435000000000000e+02     6.035000000000000e+02
            1.195000000000000e+02     7.235000000000000e+02
            9.150000000000000e+01     7.235000000000000e+02
            9.950000000000000e+01     8.675000000000000e+02
            1.195000000000000e+02     1.035500000000000e+03
            1.235000000000000e+02     1.187500000000000e+03
            1.115000000000000e+02     1.307500000000000e+03
            1.155000000000000e+02     1.415500000000000e+03
            7.950000000000000e+01     1.483500000000000e+03
            8.750000000000000e+01     1.571500000000000e+03
            7.950000000000000e+01     1.731500000000000e+03
            6.350000000000000e+01     1.879500000000000e+03
            4.750000000000000e+01     1.995500000000000e+03
            4.350000000000000e+01     2.111500000000000e+03
            3.150000000000000e+01     2.211500000000000e+03
            7.150000000000000e+01     2.363500000000000e+03
            1.515000000000000e+02     2.451500000000000e+03
            2.595000000000000e+02     2.459500000000000e+03
            3.155000000000000e+02     2.415500000000000e+03
            3.675000000000000e+02     2.335500000000000e+03
            4.155000000000001e+02     2.323500000000000e+03
            4.755000000000000e+02     2.335500000000000e+03
            4.875000000000000e+02     2.375500000000000e+03
            4.795000000000000e+02     2.439500000000000e+03
            4.915000000000001e+02     2.503500000000000e+03
            6.035000000000000e+02     2.519500000000000e+03
            7.075000000000000e+02     2.527500000000000e+03
            7.395000000000000e+02     2.487500000000000e+03
            7.395000000000000e+02     2.423500000000000e+03
            7.515000000000000e+02     2.359500000000000e+03
            7.715000000000000e+02     2.331500000000000e+03
            7.995000000000001e+02     2.383500000000000e+03
            7.995000000000001e+02     2.443500000000000e+03
            8.155000000000000e+02     2.499500000000000e+03
            9.555000000000000e+02     2.519500000000000e+03
            1.051500000000000e+03     2.519500000000000e+03
            1.075500000000000e+03     2.399500000000000e+03
            1.067500000000000e+03     2.323500000000000e+03
            1.159500000000000e+03     2.319500000000000e+03
            1.267500000000000e+03     2.279500000000000e+03
            1.331500000000000e+03     2.223500000000000e+03
            1.367500000000000e+03     2.187500000000000e+03
            1.391500000000000e+03     2.239500000000000e+03
            1.327500000000000e+03     2.275500000000000e+03
            1.279500000000000e+03     2.327500000000000e+03
            1.267500000000000e+03     2.435500000000000e+03
            1.359500000000000e+03     2.495500000000000e+03
            1.471500000000000e+03     2.463500000000000e+03
            1.543500000000000e+03     2.347500000000000e+03
            1.535500000000000e+03     2.263500000000000e+03
            1.547500000000000e+03     2.139500000000000e+03];

        P=-[X; X(1,:)]/max(abs(X(:,1)));

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);





    case 38 % PROBLEMS IN INTEGRATION (negative area)

        domain_str='minion';
        order=3;
        X=  [2.382466960352423e+01     1.121096916299559e+02
            2.428634361233480e+01     1.190348017621145e+02
            2.659471365638768e+01     1.259599118942731e+02
            2.751806167400883e+01     1.305766519823788e+02
            2.890308370044056e+01     1.351933920704845e+02
            2.936475770925113e+01     1.398101321585902e+02
            2.890308370044056e+01     1.462735682819383e+02
            2.705638766519826e+01     1.508903083700440e+02
            2.613303964757710e+01     1.555070484581497e+02
            2.059295154185023e+01     1.582770925110132e+02
            1.366784140969165e+01     1.610471365638766e+02
            8.589427312775342e+00     1.628938325991189e+02
            3.049339207048462e+00     1.661255506607929e+02
            2.125991189427310e+00     1.730506607929515e+02
            3.972687224669613e+00     1.818224669603524e+02
            9.512775330396494e+00     1.827458149779735e+02
            1.320616740088107e+01     1.841308370044052e+02
            1.505286343612334e+01     1.859775330396475e+02
            1.366784140969165e+01     1.901325991189427e+02
            1.643788546255507e+01     1.915176211453744e+02
            1.551453744493392e+01     1.975193832599118e+02
            1.597621145374450e+01     2.021361233480176e+02
            1.782290748898680e+01     2.049061674008810e+02
            2.151629955947135e+01     2.053678414096916e+02
            2.613303964757710e+01     2.049061674008810e+02
            3.213480176211453e+01     2.049061674008810e+02
            3.675154185022029e+01     2.072145374449339e+02
            3.905991189427311e+01     2.150629955947136e+02
            3.998325991189427e+01     2.229114537444934e+02
            4.182995594713657e+01     2.270665198237885e+02
            4.737004405286342e+01     2.330682819383260e+02
            5.106343612334803e+01     2.358383259911894e+02
            5.660352422907488e+01     2.376850220264317e+02
            5.891189427312776e+01     2.386083700440528e+02
            6.352863436123351e+01     2.399933920704846e+02
            6.445198237885461e+01     2.436867841409691e+02
            6.491365638766518e+01     2.455334801762114e+02
            6.075859030837006e+01     2.483035242290749e+02
            5.845022026431718e+01     2.524585903083700e+02
            5.845022026431718e+01     2.575370044052863e+02
            6.399030837004410e+01     2.598453744493392e+02
            7.322378854625549e+01     2.593837004405286e+02
            7.968722466960355e+01     2.575370044052863e+02
            8.615066079295156e+01     2.575370044052863e+02
            8.984405286343616e+01     2.566136563876652e+02
            8.799735682819386e+01     2.473801762114537e+02
            9.169074889867841e+01     2.450718061674008e+02
            9.169074889867841e+01     2.372233480176211e+02
            9.723083700440533e+01     2.386083700440528e+02
            9.723083700440533e+01     2.404550660792951e+02
            1.000008810572687e+02     2.441484581497797e+02
            1.004625550660793e+02     2.515352422907488e+02
            1.046176211453745e+02     2.566136563876652e+02
            1.120044052863436e+02     2.593837004405286e+02
            1.170828193832599e+02     2.598453744493392e+02
            1.221612334801762e+02     2.598453744493392e+02
            1.304713656387665e+02     2.561519823788546e+02
            1.277013215859031e+02     2.501502202643172e+02
            1.235462555066080e+02     2.464568281938326e+02
            1.244696035242291e+02     2.404550660792951e+02
            1.309330396475771e+02     2.395317180616740e+02
            1.383198237885463e+02     2.376850220264317e+02
            1.452449339207049e+02     2.339916299559471e+02
            1.512466960352423e+02     2.293748898678414e+02
            1.567867841409692e+02     2.229114537444934e+02
            1.590951541850220e+02     2.155246696035242e+02
            1.600185022026432e+02     2.090612334801762e+02
            1.600185022026432e+02     2.021361233480176e+02
            1.600185022026432e+02     1.942876651982378e+02
            1.590951541850220e+02     1.855158590308370e+02
            1.577101321585903e+02     1.758207048458149e+02
            1.577101321585903e+02     1.661255506607929e+02
            1.586334801762115e+02     1.573537444933920e+02
            1.618651982378855e+02     1.439651982378854e+02
            1.650969162995595e+02     1.324233480176211e+02
            1.660202643171806e+02     1.254982378854625e+02
            1.683286343612335e+02     1.176497797356828e+02
            1.701753303964758e+02     1.116480176211453e+02
            1.761770925110132e+02     1.107246696035242e+02
            1.761770925110132e+02     1.010295154185021e+02
            1.812555066079295e+02     9.641277533039641e+01
            1.854105726872247e+02     8.671762114537438e+01
            1.891039647577093e+02     7.840748898678407e+01
            1.881806167400881e+02     7.148237885462549e+01
            1.849488986784141e+02     6.917400881057262e+01
            1.798704845814978e+02     7.148237885462549e+01
            1.784854625550661e+02     6.455726872246692e+01
            1.734070484581498e+02     6.271057268722461e+01
            1.683286343612335e+02     6.501894273127749e+01
            1.660202643171806e+02     7.332907488986780e+01
            1.650969162995595e+02     7.840748898678407e+01
            1.609418502202643e+02     7.102070484581492e+01
            1.554017621145375e+02     7.148237885462549e+01
            1.521700440528634e+02     7.471409691629952e+01
            1.540167400881057e+02     8.163920704845810e+01
            1.558634361233480e+02     8.764096916299553e+01
            1.595568281938326e+02     9.271938325991184e+01
            1.609418502202643e+02     9.825947136563872e+01
            1.572484581497798e+02     1.033378854625550e+02
            1.595568281938326e+02     1.065696035242290e+02
            1.581718061674009e+02     1.139563876651982e+02
            1.563251101321586e+02     1.190348017621145e+02
            1.544784140969163e+02     1.250365638766519e+02
            1.507850220264317e+02     1.125713656387665e+02
            1.484766519823789e+02     1.070312775330396e+02
            1.470916299559472e+02     1.001061674008810e+02
            1.457066079295154e+02     9.133436123348014e+01
            1.438599118942731e+02     8.440925110132153e+01
            1.429365638766520e+02     7.886916299559465e+01
            1.424748898678414e+02     7.286740088105724e+01
            1.447832599118943e+02     7.148237885462549e+01
            1.424748898678414e+02     6.455726872246692e+01
            1.420132158590308e+02     5.947885462555061e+01
            1.401665198237886e+02     5.624713656387661e+01
            1.369348017621145e+02     5.070704845814973e+01
            1.332414096916299e+02     4.285859030836997e+01
            1.309330396475771e+02     4.055022026431711e+01
            1.277013215859031e+02     3.824185022026427e+01
            1.249312775330396e+02     3.454845814977966e+01
            1.263162995594714e+02     3.316343612334796e+01
            1.290863436123348e+02     3.224008810572681e+01
            1.341647577092511e+02     2.947004405286339e+01
            1.360114537444934e+02     2.854669603524223e+01
            1.300096916299560e+02     2.854669603524223e+01
            1.244696035242291e+02     3.131674008810566e+01
            1.216995594713656e+02     3.131674008810566e+01
            1.226229074889868e+02     2.808502202643166e+01
            1.267779735682819e+02     2.531497797356820e+01
            1.309330396475771e+02     2.392995594713651e+01
            1.235462555066080e+02     2.531497797356820e+01
            1.166211453744493e+02     2.762334801762108e+01
            1.152361233480177e+02     2.669999999999993e+01
            1.193911894273128e+02     2.300660792951535e+01
            1.235462555066080e+02     1.931321585903078e+01
            1.300096916299560e+02     1.792819383259905e+01
            1.364731277533040e+02     1.746651982378847e+01
            1.309330396475771e+02     1.654317180616732e+01
            1.226229074889868e+02     1.746651982378847e+01
            1.133894273127754e+02     2.023656387665193e+01
            1.092343612334802e+02     2.115991189427308e+01
            1.032325991189427e+02     2.023656387665193e+01
            1.060026431718062e+02     1.377312775330390e+01
            1.138511013215859e+02     8.233039647577016e+00
            1.166211453744493e+02     4.539647577092467e+00
            1.078493392070484e+02     8.694713656387592e+00
            1.018475770925110e+02     1.469647577092505e+01
            1.013859030837004e+02     1.885154185022020e+01
            9.492246696035244e+01     1.977488986784135e+01
            9.353744493392071e+01     1.331145374449332e+01
            9.584581497797359e+01     4.077973568281891e+00
            9.492246696035244e+01    -1.462114537445018e+00
            9.030572687224668e+01     6.848017621145318e+00
            8.892070484581501e+01     1.238810572687220e+01
            8.845903083700443e+01     1.654317180616732e+01
            8.245726872246695e+01     1.838986784140963e+01
            7.922555066079298e+01     1.654317180616732e+01
            7.968722466960355e+01     9.618061674008743e+00
            8.061057268722470e+01     1.307929515418436e+00
            7.691718061674010e+01     3.616299559471315e+00
            7.691718061674010e+01     9.618061674008743e+00
            7.507048458149779e+01     1.654317180616732e+01
            7.368546255506607e+01     1.746651982378847e+01
            6.768370044052864e+01     1.885154185022020e+01
            6.168193832599122e+01     2.069823788546250e+01
            5.660352422907488e+01     1.700484581497790e+01
            5.106343612334803e+01     1.331145374449332e+01
            4.367665198237887e+01     1.100308370044047e+01
            3.952158590308369e+01     1.192643171806162e+01
            4.460000000000002e+01     1.469647577092505e+01
            5.014008810572687e+01     1.746651982378847e+01
            5.291013215859033e+01     2.254493392070478e+01
            4.783171806167400e+01     2.808502202643166e+01
            4.136828193832599e+01     3.131674008810566e+01
            3.490484581497799e+01     3.177841409691624e+01
            2.797973568281941e+01     2.623832599118936e+01
            1.782290748898680e+01     2.947004405286339e+01
            2.336299559471365e+01     3.131674008810566e+01
            3.167312775330396e+01     3.362511013215852e+01
            3.351982378854626e+01     3.731850220264312e+01
            2.705638766519826e+01     4.101189427312769e+01
            1.689955947136565e+01     3.685682819383254e+01
            9.512775330396494e+00     3.962687224669600e+01
            9.512775330396494e+00     4.378193832599112e+01
            2.013127753303965e+01     4.147356828193827e+01
            2.428634361233480e+01     4.470528634361227e+01
            2.474801762114538e+01     4.562863436123342e+01
            2.151629955947135e+01     5.163039647577085e+01
            2.059295154185023e+01     5.809383259911888e+01
            1.966960352422907e+01     6.409559471365634e+01
            1.736123348017622e+01     7.194405286343607e+01
            1.736123348017622e+01     7.886916299559465e+01
            1.459118942731280e+01     8.302422907488983e+01
            1.597621145374450e+01     8.902599118942726e+01
            1.597621145374450e+01     9.364273127753299e+01
            1.689955947136565e+01     9.733612334801757e+01
            2.013127753303965e+01     9.733612334801757e+01
            2.151629955947135e+01     1.024145374449339e+02
            2.151629955947135e+01     1.056462555066079e+02];

        P=-[X; X(1,:)]/max(abs(X(:,1)));

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 39 % PROBLEMS IN INTEGRATION (negative area)

        domain_str='S(39):';
        order=3;

        P=[     1.840000000000000e+02     1.900000000000000e+02
            1.620000000000000e+02     1.940000000000000e+02
            1.580000000000000e+02     2.100000000000000e+02
            1.280000000000000e+02     2.160000000000000e+02
            9.999999999999997e+01     2.140000000000000e+02
            7.799999999999996e+01     2.140000000000000e+02
            6.399999999999996e+01     2.180000000000000e+02
            3.799999999999996e+01     2.240000000000000e+02
            2.999999999999996e+01     2.320000000000000e+02
            2.599999999999996e+01     2.440000000000000e+02
            3.599999999999996e+01     2.620000000000000e+02
            6.399999999999996e+01     2.740000000000000e+02
            9.599999999999999e+01     2.840000000000000e+02
            1.200000000000000e+02     2.960000000000000e+02
            1.340000000000000e+02     2.940000000000000e+02
            1.500000000000000e+02     3.040000000000000e+02
            1.700000000000000e+02     3.260000000000000e+02
            1.940000000000000e+02     3.540000000000000e+02
            2.120000000000000e+02     3.760000000000000e+02
            2.300000000000000e+02     4.040000000000000e+02
            2.120000000000000e+02     4.280000000000000e+02
            1.840000000000000e+02     4.480000000000000e+02
            1.640000000000000e+02     4.780000000000000e+02
            1.520000000000000e+02     5.100000000000000e+02
            1.440000000000000e+02     5.460000000000000e+02
            1.420000000000000e+02     5.760000000000000e+02
            1.640000000000000e+02     5.880000000000000e+02
            1.800000000000000e+02     6.180000000000000e+02
            1.920000000000000e+02     6.460000000000000e+02
            1.740000000000000e+02     6.640000000000000e+02
            1.440000000000000e+02     6.680000000000000e+02
            1.160000000000000e+02     6.680000000000000e+02
            8.399999999999996e+01     6.900000000000000e+02
            8.799999999999999e+01     7.340000000000001e+02
            1.260000000000000e+02     7.560000000000001e+02
            1.660000000000000e+02     7.640000000000001e+02
            2.080000000000000e+02     7.520000000000001e+02
            2.440000000000000e+02     7.380000000000001e+02
            2.600000000000000e+02     7.160000000000000e+02
            2.680000000000000e+02     6.820000000000000e+02
            2.580000000000000e+02     6.540000000000000e+02
            2.280000000000000e+02     6.340000000000000e+02
            2.220000000000000e+02     6.120000000000000e+02
            2.300000000000000e+02     6.020000000000000e+02
            2.600000000000000e+02     6.220000000000000e+02
            2.780000000000001e+02     6.220000000000000e+02
            2.880000000000001e+02     6.520000000000000e+02
            2.820000000000001e+02     6.660000000000000e+02
            2.780000000000001e+02     6.860000000000000e+02
            2.800000000000001e+02     7.100000000000000e+02
            3.060000000000001e+02     7.420000000000001e+02
            3.500000000000001e+02     7.620000000000001e+02
            3.940000000000001e+02     7.720000000000001e+02
            4.340000000000001e+02     7.620000000000001e+02
            4.620000000000001e+02     7.420000000000001e+02
            4.660000000000001e+02     7.040000000000000e+02
            4.460000000000001e+02     6.760000000000000e+02
            4.120000000000001e+02     6.680000000000000e+02
            3.780000000000001e+02     6.600000000000000e+02
            3.500000000000001e+02     6.520000000000000e+02
            3.360000000000001e+02     6.440000000000000e+02
            3.200000000000001e+02     6.420000000000000e+02
            3.140000000000001e+02     6.100000000000000e+02
            3.040000000000001e+02     5.840000000000000e+02
            3.220000000000001e+02     5.840000000000000e+02
            3.520000000000001e+02     5.840000000000000e+02
            3.760000000000001e+02     5.780000000000000e+02
            3.960000000000001e+02     5.640000000000000e+02
            4.040000000000001e+02     5.600000000000000e+02
            4.300000000000001e+02     5.460000000000000e+02
            4.560000000000001e+02     5.320000000000000e+02
            4.840000000000001e+02     5.100000000000000e+02
            5.120000000000000e+02     5.060000000000000e+02
            5.400000000000000e+02     5.100000000000000e+02
            5.740000000000000e+02     5.200000000000000e+02
            6.020000000000000e+02     5.180000000000000e+02
            5.840000000000000e+02     5.039999999999999e+02
            5.500000000000000e+02     4.940000000000000e+02
            5.220000000000000e+02     4.940000000000000e+02
            4.900000000000001e+02     4.940000000000000e+02
            4.560000000000001e+02     5.120000000000000e+02
            4.320000000000001e+02     5.240000000000000e+02
            4.180000000000001e+02     5.300000000000000e+02
            4.020000000000001e+02     5.420000000000000e+02
            3.840000000000001e+02     5.520000000000000e+02
            3.600000000000001e+02     5.620000000000000e+02
            3.340000000000001e+02     5.620000000000000e+02
            3.060000000000001e+02     5.640000000000000e+02
            2.960000000000001e+02     5.340000000000000e+02
            3.000000000000001e+02     5.060000000000000e+02
            3.020000000000001e+02     4.940000000000000e+02
            3.060000000000001e+02     4.719999999999999e+02
            3.140000000000001e+02     4.520000000000001e+02
            3.280000000000001e+02     4.380000000000000e+02
            3.600000000000001e+02     4.240000000000000e+02
            3.960000000000001e+02     4.160000000000000e+02
            4.240000000000001e+02     4.020000000000000e+02
            4.460000000000001e+02     3.940000000000000e+02
            4.580000000000001e+02     3.900000000000000e+02
            4.740000000000001e+02     3.960000000000000e+02
            4.980000000000001e+02     4.040000000000000e+02
            5.220000000000000e+02     4.120000000000000e+02
            5.420000000000000e+02     4.180000000000000e+02
            5.680000000000000e+02     4.260000000000000e+02
            5.940000000000000e+02     4.220000000000000e+02
            6.080000000000000e+02     4.200000000000000e+02
            6.160000000000000e+02     4.160000000000000e+02
            6.100000000000000e+02     3.960000000000000e+02
            6.080000000000000e+02     3.860000000000000e+02
            5.980000000000000e+02     3.720000000000000e+02
            5.780000000000000e+02     3.520000000000000e+02
            5.620000000000000e+02     3.340000000000000e+02
            5.500000000000000e+02     3.200000000000000e+02
            5.400000000000000e+02     2.980000000000000e+02
            5.500000000000000e+02     2.800000000000000e+02
            5.460000000000000e+02     2.560000000000000e+02
            5.280000000000000e+02     2.540000000000000e+02
            5.160000000000000e+02     2.700000000000000e+02
            5.040000000000001e+02     2.940000000000000e+02
            4.860000000000001e+02     3.120000000000000e+02
            4.720000000000001e+02     3.360000000000000e+02
            4.580000000000001e+02     3.460000000000000e+02
            4.420000000000001e+02     3.620000000000000e+02
            4.180000000000001e+02     3.660000000000000e+02
            3.960000000000001e+02     3.740000000000000e+02
            4.040000000000001e+02     3.500000000000000e+02
            4.080000000000001e+02     3.360000000000000e+02
            4.080000000000001e+02     3.120000000000000e+02
            4.340000000000001e+02     3.120000000000000e+02
            4.620000000000001e+02     3.040000000000000e+02
            4.800000000000001e+02     2.920000000000000e+02
            4.940000000000001e+02     2.740000000000000e+02
            4.960000000000001e+02     2.520000000000000e+02
            4.860000000000001e+02     2.240000000000000e+02
            4.720000000000001e+02     2.120000000000000e+02
            4.540000000000001e+02     2.020000000000000e+02
            4.200000000000001e+02     2.000000000000000e+02
            3.980000000000001e+02     2.160000000000000e+02
            3.940000000000001e+02     2.320000000000000e+02
            3.820000000000001e+02     2.460000000000000e+02
            3.640000000000001e+02     2.440000000000000e+02
            3.420000000000001e+02     2.380000000000000e+02
            3.180000000000001e+02     2.260000000000000e+02
            3.300000000000001e+02     2.000000000000000e+02
            3.200000000000001e+02     1.660000000000000e+02
            3.000000000000001e+02     1.379999999999999e+02
            2.760000000000000e+02     1.339999999999999e+02
            2.460000000000000e+02     1.419999999999999e+02
            2.200000000000000e+02     1.700000000000000e+02
            2.180000000000000e+02     1.960000000000000e+02
            2.300000000000000e+02     2.220000000000000e+02
            2.440000000000000e+02     2.400000000000000e+02
            2.420000000000000e+02     2.580000000000000e+02
            2.340000000000000e+02     2.800000000000000e+02
            2.300000000000000e+02     3.060000000000000e+02
            2.220000000000000e+02     3.180000000000000e+02
            2.100000000000000e+02     3.220000000000000e+02
            1.980000000000000e+02     3.100000000000000e+02
            1.840000000000000e+02     2.960000000000000e+02
            1.800000000000000e+02     2.840000000000000e+02
            1.820000000000000e+02     2.740000000000000e+02
            1.880000000000000e+02     2.520000000000000e+02
            1.920000000000000e+02     2.320000000000000e+02
            1.960000000000000e+02     2.100000000000000e+02
            2.000000000000000e+02     2.040000000000000e+02];

        P=-[P; P(1,:)]/max(abs(P(:,1)));

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 40 % PROBLEMS IN INTEGRATION (negative area)

        domain_str='S(40): snoopy';
        order=3;

        X=[     5.600000000000000e+02     6.480000000000001e+02
            5.480000000000000e+02     6.120000000000001e+02
            5.460000000000000e+02     5.900000000000001e+02
            5.460000000000000e+02     5.440000000000001e+02
            5.480000000000000e+02     5.060000000000001e+02
            5.660000000000000e+02     4.920000000000001e+02
            5.900000000000000e+02     4.600000000000001e+02
            6.120000000000000e+02     4.500000000000001e+02
            6.340000000000000e+02     4.500000000000001e+02
            6.580000000000000e+02     4.780000000000001e+02
            7.039999999999999e+02     4.780000000000001e+02
            7.479999999999999e+02     4.600000000000001e+02
            7.899999999999999e+02     4.100000000000001e+02
            8.039999999999999e+02     3.440000000000002e+02
            8.179999999999999e+02     2.580000000000002e+02
            8.039999999999999e+02     1.840000000000002e+02
            7.779999999999999e+02     1.160000000000002e+02
            7.359999999999999e+02     7.800000000000023e+01
            6.879999999999999e+02     4.200000000000023e+01
            6.440000000000000e+02     1.600000000000023e+01
            5.920000000000000e+02     1.600000000000023e+01
            5.440000000000000e+02     2.200000000000023e+01
            5.220000000000000e+02     3.200000000000023e+01
            5.180000000000000e+02     8.000000000000227e+00
            4.840000000000001e+02     6.000000000000227e+00
            4.800000000000000e+02     2.200000000000023e+01
            4.980000000000001e+02     2.600000000000023e+01
            5.060000000000000e+02     5.400000000000023e+01
            4.879999999999999e+02     7.200000000000023e+01
            4.480000000000000e+02     1.060000000000002e+02
            4.020000000000000e+02     1.100000000000002e+02
            3.540000000000000e+02     1.160000000000002e+02
            2.860000000000000e+02     1.300000000000002e+02
            2.320000000000001e+02     1.660000000000002e+02
            1.880000000000001e+02     2.080000000000002e+02
            1.640000000000001e+02     2.520000000000002e+02
            1.540000000000001e+02     2.940000000000002e+02
            1.220000000000001e+02     3.080000000000002e+02
            1.020000000000001e+02     3.280000000000002e+02
            8.000000000000011e+01     3.700000000000001e+02
            9.200000000000009e+01     4.040000000000001e+02
            1.440000000000001e+02     3.920000000000001e+02
            1.800000000000001e+02     4.000000000000001e+02
            2.100000000000001e+02     4.320000000000001e+02
            2.520000000000001e+02     4.440000000000001e+02
            3.000000000000000e+02     4.580000000000001e+02
            3.420000000000000e+02     4.720000000000001e+02
            3.840000000000000e+02     4.800000000000001e+02
            4.320000000000000e+02     4.900000000000001e+02
            4.660000000000000e+02     5.100000000000001e+02
            4.719999999999999e+02     5.460000000000001e+02
            4.540000000000001e+02     5.620000000000001e+02
            4.680000000000001e+02     5.840000000000001e+02
            4.580000000000000e+02     6.160000000000001e+02
            4.340000000000000e+02     6.460000000000001e+02
            4.140000000000000e+02     6.760000000000001e+02
            4.040000000000000e+02     7.140000000000001e+02
            3.980000000000000e+02     7.660000000000000e+02
            4.080000000000000e+02     8.220000000000000e+02
            4.340000000000000e+02     8.540000000000000e+02
            4.660000000000000e+02     8.740000000000000e+02
            4.640000000000000e+02     9.000000000000000e+02
            4.240000000000000e+02     9.160000000000000e+02
            3.700000000000000e+02     9.140000000000000e+02
            3.340000000000000e+02     9.260000000000000e+02
            3.060000000000000e+02     9.260000000000000e+02
            2.860000000000000e+02     9.460000000000000e+02
            2.700000000000001e+02     9.860000000000000e+02
            3.100000000000000e+02     1.008000000000000e+03
            3.540000000000000e+02     1.012000000000000e+03
            3.940000000000000e+02     1.016000000000000e+03
            4.380000000000000e+02     1.020000000000000e+03
            4.859999999999999e+02     1.022000000000000e+03
            5.280000000000000e+02     1.018000000000000e+03
            5.680000000000000e+02     1.018000000000000e+03
            6.120000000000000e+02     1.006000000000000e+03
            6.540000000000000e+02     9.980000000000000e+02
            6.819999999999999e+02     9.920000000000000e+02
            6.619999999999999e+02     9.540000000000000e+02
            6.180000000000000e+02     9.380000000000000e+02
            5.800000000000000e+02     9.300000000000000e+02
            5.800000000000000e+02     9.000000000000000e+02
            5.740000000000000e+02     8.740000000000000e+02
            5.980000000000000e+02     8.640000000000000e+02
            6.460000000000000e+02     8.840000000000000e+02
            6.799999999999999e+02     8.900000000000000e+02
            7.239999999999999e+02     8.860000000000000e+02
            7.599999999999999e+02     8.740000000000000e+02
            7.799999999999999e+02     8.740000000000000e+02
            7.339999999999999e+02     8.560000000000000e+02
            7.039999999999999e+02     8.520000000000000e+02
            6.779999999999999e+02     8.480000000000000e+02
            6.400000000000000e+02     8.400000000000000e+02
            6.280000000000000e+02     8.340000000000000e+02
            6.140000000000000e+02     8.220000000000000e+02
            6.140000000000000e+02     7.860000000000000e+02
            6.140000000000000e+02     7.560000000000000e+02
            6.000000000000000e+02     7.240000000000001e+02
            5.900000000000000e+02     7.020000000000001e+02
            5.740000000000000e+02     6.800000000000001e+02];

        P=-[X; X(1,:)]/max(abs(X(:,1)));

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);





    case 41 % PROBLEMS IN INTEGRATION (negative area)

        domain_str='S(41): Felix the cat';
        order=3;

        X=[     8.157500000000000e+02     1.607500000000000e+03
            8.637500000000000e+02     1.628500000000000e+03
            9.237500000000000e+02     1.640500000000000e+03
            9.807500000000000e+02     1.655500000000000e+03
            1.046750000000000e+03     1.655500000000000e+03
            1.127750000000000e+03     1.649500000000000e+03
            1.193750000000000e+03     1.613500000000000e+03
            1.238750000000000e+03     1.571500000000000e+03
            1.229750000000000e+03     1.505500000000000e+03
            1.187750000000000e+03     1.448500000000000e+03
            1.130750000000000e+03     1.418500000000000e+03
            1.061750000000000e+03     1.436500000000000e+03
            9.807500000000000e+02     1.457500000000000e+03
            1.094750000000000e+03     1.007500000000000e+03
            1.103750000000000e+03     8.965000000000000e+02
            1.079750000000000e+03     8.275000000000000e+02
            1.043750000000000e+03     7.915000000000000e+02
            9.747500000000000e+02     7.645000000000000e+02
            9.657500000000000e+02     7.495000000000000e+02
            1.019750000000000e+03     7.285000000000000e+02
            1.076750000000000e+03     6.985000000000000e+02
            1.124750000000000e+03     6.625000000000000e+02
            1.160750000000000e+03     6.295000000000000e+02
            1.199750000000000e+03     5.905000000000000e+02
            1.259750000000000e+03     6.295000000000000e+02
            1.310750000000000e+03     6.565000000000000e+02
            1.373750000000000e+03     6.775000000000000e+02
            1.430750000000000e+03     6.535000000000000e+02
            1.484750000000000e+03     6.325000000000000e+02
            1.484750000000000e+03     5.875000000000000e+02
            1.493750000000000e+03     5.695000000000000e+02
            1.451750000000000e+03     5.335000000000000e+02
            1.409750000000000e+03     5.125000000000000e+02
            1.355750000000000e+03     4.765000000000001e+02
            1.295750000000000e+03     4.315000000000001e+02
            1.334750000000000e+03     3.835000000000000e+02
            1.328750000000000e+03     3.235000000000000e+02
            1.304750000000000e+03     2.935000000000000e+02
            1.256750000000000e+03     2.995000000000000e+02
            1.244750000000000e+03     3.415000000000000e+02
            1.232750000000000e+03     3.925000000000000e+02
            1.220750000000000e+03     4.045000000000000e+02
            1.178750000000000e+03     4.105000000000000e+02
            1.154750000000000e+03     4.495000000000001e+02
            1.100750000000000e+03     5.275000000000000e+02
            1.031750000000000e+03     5.875000000000000e+02
            9.507500000000000e+02     6.415000000000000e+02
            9.867500000000001e+02     5.785000000000000e+02
            1.013750000000000e+03     5.155000000000000e+02
            1.013750000000000e+03     4.615000000000001e+02
            1.013750000000000e+03     4.195000000000001e+02
            1.025750000000000e+03     3.895000000000000e+02
            1.025750000000000e+03     3.535000000000000e+02
            1.007750000000000e+03     3.205000000000000e+02
            9.867500000000001e+02     3.175000000000000e+02
            9.597500000000000e+02     2.455000000000000e+02
            9.117499999999999e+02     1.915000000000000e+02
            8.577500000000001e+02     1.435000000000000e+02
            7.887500000000000e+02     1.135000000000000e+02
            7.347500000000000e+02     8.950000000000000e+01
            6.957500000000000e+02     5.650000000000000e+01
            6.447500000000000e+02     8.500000000000000e+00
            6.057500000000000e+02     9.550000000000000e+01
            5.487500000000000e+02     1.015000000000000e+02
            5.007500000000000e+02     1.255000000000000e+02
            4.407499999999999e+02     9.850000000000000e+01
            3.447500000000000e+02     5.350000000000000e+01
            3.507500000000000e+02     1.375000000000000e+02
            3.417500000000000e+02     2.005000000000000e+02
            3.447500000000000e+02     2.875000000000000e+02
            3.357500000000000e+02     3.775000000000000e+02
            3.147500000000000e+02     4.735000000000001e+02
            2.787500000000000e+02     5.455000000000000e+02
            3.147500000000000e+02     5.815000000000000e+02
            3.717500000000000e+02     6.055000000000000e+02
            3.267500000000000e+02     6.235000000000000e+02
            4.107500000000000e+02     6.565000000000000e+02
            3.627500000000000e+02     6.475000000000000e+02
            3.027500000000000e+02     6.385000000000000e+02
            2.877500000000000e+02     6.025000000000000e+02
            2.517500000000000e+02     5.965000000000000e+02
            2.127500000000000e+02     5.905000000000000e+02
            1.857500000000000e+02     5.605000000000000e+02
            1.587500000000000e+02     5.185000000000000e+02
            1.167500000000000e+02     5.035000000000001e+02
            9.274999999999997e+01     5.365000000000000e+02
            9.274999999999997e+01     5.875000000000000e+02
            1.197500000000000e+02     6.355000000000000e+02
            1.497500000000000e+02     6.745000000000000e+02
            1.317500000000000e+02     7.105000000000000e+02
            8.974999999999997e+01     7.345000000000000e+02
            4.774999999999997e+01     7.585000000000000e+02
            1.774999999999997e+01     7.825000000000000e+02
            1.474999999999997e+01     8.155000000000000e+02
            1.174999999999997e+01     8.305000000000000e+02
            3.574999999999997e+01     8.665000000000000e+02
            6.574999999999997e+01     8.755000000000000e+02
            9.574999999999997e+01     8.965000000000000e+02
            1.497500000000000e+02     8.875000000000000e+02
            2.007500000000000e+02     8.665000000000000e+02
            2.517500000000000e+02     8.335000000000000e+02
            2.907500000000000e+02     8.005000000000000e+02
            3.267500000000000e+02     7.855000000000000e+02
            3.897499999999999e+02     7.945000000000000e+02
            4.497500000000000e+02     8.125000000000000e+02
            5.157500000000000e+02     8.155000000000000e+02
            5.757500000000000e+02     8.215000000000000e+02
            6.237500000000000e+02     8.275000000000000e+02
            6.807500000000000e+02     8.185000000000000e+02
            7.377500000000000e+02     8.155000000000000e+02
            7.677500000000000e+02     8.305000000000000e+02
            7.677500000000000e+02     8.545000000000000e+02
            7.557500000000000e+02     9.025000000000000e+02
            7.617500000000000e+02     9.445000000000000e+02
            7.767500000000000e+02     9.865000000000000e+02
            7.947500000000000e+02     1.022500000000000e+03
            7.797500000000000e+02     1.076500000000000e+03
            7.647500000000000e+02     1.112500000000000e+03
            7.167500000000000e+02     1.139500000000000e+03
            6.657500000000000e+02     1.157500000000000e+03
            6.147500000000000e+02     1.151500000000000e+03
            5.757500000000000e+02     1.118500000000000e+03
            5.367500000000000e+02     1.058500000000000e+03
            4.857500000000000e+02     1.046500000000000e+03
            4.377500000000000e+02     1.064500000000000e+03
            4.167500000000000e+02     1.127500000000000e+03
            4.317500000000000e+02     1.190500000000000e+03
            4.707500000000001e+02     1.229500000000000e+03
            5.157500000000000e+02     1.253500000000000e+03
            5.757500000000000e+02     1.268500000000000e+03
            6.387500000000000e+02     1.259500000000000e+03
            6.927500000000000e+02     1.256500000000000e+03
            7.527500000000000e+02     1.238500000000000e+03
            7.437500000000000e+02     1.292500000000000e+03
            7.257500000000000e+02     1.346500000000000e+03
            7.167500000000000e+02     1.403500000000000e+03
            6.957500000000000e+02     1.451500000000000e+03
            6.927500000000000e+02     1.466500000000000e+03
            6.357500000000000e+02     1.478500000000000e+03
            5.727500000000000e+02     1.463500000000000e+03
            5.217500000000000e+02     1.466500000000000e+03
            4.527500000000000e+02     1.487500000000000e+03
            4.167500000000000e+02     1.526500000000000e+03
            4.017500000000000e+02     1.583500000000000e+03
            4.347500000000001e+02     1.634500000000000e+03
            4.947500000000000e+02     1.649500000000000e+03
            5.727500000000000e+02     1.652500000000000e+03
            6.597500000000000e+02     1.652500000000000e+03
            7.377500000000000e+02     1.646500000000000e+03
            7.887500000000000e+02     1.622500000000000e+03];

        P=-[X; X(1,:)]/max(abs(X(:,1)));

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 42

        domain_str='S(42): Font N';
        order=3;

        X=[
            -191.0000 -104.0000
            -200.5000 -104.5000
            -209.5000 -105.5000
            -218.5000 -106.5000
            -226.5000 -108.5000
            -235.0000 -110.0000
            -243.5000 -111.5000
            -251.5000 -113.5000
            -258.5000 -116.5000
            -266.5000 -118.5000
            -274.5000 -120.5000
            -281.5000 -123.5000
            -289.0000 -126.0000
            -296.5000 -128.5000
            -303.5000 -131.5000
            -310.5000 -134.5000
            -318.0000 -137.0000
            -325.0000 -140.0000
            -332.0000 -143.0000
            -334.0000 -136.0000
            -334.0000 -126.0000
            -334.0000 -116.0000
            -341.5000 -113.5000
            -351.5000 -113.5000
            -361.5000 -113.5000
            -371.5000 -113.5000
            -381.5000 -113.5000
            -391.5000 -113.5000
            -401.5000 -113.5000
            -411.5000 -113.5000
            -421.5000 -113.5000
            -431.5000 -113.5000
            -441.5000 -113.5000
            -451.5000 -113.5000
            -461.5000 -113.5000
            -471.5000 -113.5000
            -478.0000 -117.0000
            -477.0000 -126.0000
            -468.5000 -127.5000
            -459.5000 -128.5000
            -450.5000 -129.5000
            -441.5000 -130.5000
            -434.0000 -133.0000
            -427.0000 -136.0000
            -421.0000 -140.0000
            -416.0000 -145.0000
            -412.0000 -151.0000
            -409.0000 -158.0000
            -407.0000 -166.0000
            -407.0000 -176.0000
            -406.0000 -185.0000
            -406.0000 -195.0000
            -406.0000 -205.0000
            -406.0000 -215.0000
            -406.0000 -225.0000
            -406.0000 -235.0000
            -406.0000 -245.0000
            -406.0000 -255.0000
            -406.0000 -265.0000
            -406.0000 -275.0000
            -406.0000 -285.0000
            -406.0000 -295.0000
            -406.0000 -305.0000
            -406.0000 -315.0000
            -406.0000 -325.0000
            -406.0000 -335.0000
            -406.0000 -345.0000
            -406.0000 -355.0000
            -406.0000 -365.0000
            -406.0000 -375.0000
            -406.0000 -385.0000
            -406.0000 -395.0000
            -406.0000 -405.0000
            -406.0000 -415.0000
            -406.0000 -425.0000
            -406.0000 -435.0000
            -406.0000 -445.0000
            -406.0000 -455.0000
            -406.0000 -465.0000
            -406.0000 -475.0000
            -406.0000 -485.0000
            -406.0000 -495.0000
            -406.0000 -505.0000
            -406.0000 -515.0000
            -406.0000 -525.0000
            -406.0000 -535.0000
            -406.5000 -544.5000
            -407.0000 -554.0000
            -408.0000 -563.0000
            -410.0000 -571.0000
            -413.0000 -578.0000
            -417.5000 -583.5000
            -423.0000 -588.0000
            -429.5000 -591.5000
            -436.5000 -594.5000
            -444.5000 -596.5000
            -453.0000 -598.0000
            -462.5000 -598.5000
            -471.5000 -599.5000
            -478.0000 -603.0000
            -477.0000 -612.0000
            -468.5000 -613.5000
            -458.5000 -613.5000
            -448.5000 -613.5000
            -438.5000 -613.5000
            -428.5000 -613.5000
            -418.5000 -613.5000
            -408.5000 -613.5000
            -398.5000 -613.5000
            -388.5000 -613.5000
            -378.5000 -613.5000
            -368.5000 -613.5000
            -358.5000 -613.5000
            -348.5000 -613.5000
            -338.5000 -613.5000
            -328.5000 -613.5000
            -318.5000 -613.5000
            -308.5000 -613.5000
            -298.5000 -613.5000
            -288.5000 -613.5000
            -278.5000 -613.5000
            -268.5000 -613.5000
            -262.0000 -610.0000
            -263.0000 -601.0000
            -271.5000 -599.5000
            -280.5000 -598.5000
            -289.5000 -597.5000
            -297.5000 -595.5000
            -305.0000 -593.0000
            -311.5000 -589.5000
            -318.0000 -586.0000
            -323.0000 -581.0000
            -327.0000 -575.0000
            -330.5000 -568.5000
            -333.0000 -561.0000
            -333.0000 -551.0000
            -334.0000 -542.0000
            -334.0000 -532.0000
            -334.0000 -522.0000
            -334.0000 -512.0000
            -334.0000 -502.0000
            -334.0000 -492.0000
            -334.0000 -482.0000
            -334.0000 -472.0000
            -334.0000 -462.0000
            -334.0000 -452.0000
            -334.0000 -442.0000
            -334.0000 -432.0000
            -334.0000 -422.0000
            -334.0000 -412.0000
            -334.0000 -402.0000
            -334.0000 -392.0000
            -334.0000 -382.0000
            -334.0000 -372.0000
            -334.0000 -362.0000
            -334.0000 -352.0000
            -334.0000 -342.0000
            -334.0000 -332.0000
            -334.0000 -322.0000
            -334.0000 -312.0000
            -334.0000 -302.0000
            -334.0000 -292.0000
            -334.0000 -282.0000
            -334.0000 -272.0000
            -334.0000 -262.0000
            -334.0000 -252.0000
            -334.0000 -242.0000
            -334.0000 -232.0000
            -334.0000 -222.0000
            -334.0000 -212.0000
            -334.0000 -202.0000
            -334.0000 -192.0000
            -334.0000 -182.0000
            -332.0000 -174.0000
            -325.0000 -171.0000
            -317.5000 -168.5000
            -310.5000 -165.5000
            -303.5000 -162.5000
            -295.5000 -160.5000
            -288.5000 -157.5000
            -280.5000 -155.5000
            -272.5000 -153.5000
            -264.5000 -151.5000
            -256.5000 -149.5000
            -247.5000 -148.5000
            -239.5000 -146.5000
            -229.5000 -146.5000
            -220.5000 -145.5000
            -210.5000 -145.5000
            -201.5000 -146.5000
            -192.5000 -147.5000
            -185.0000 -150.0000
            -177.5000 -152.5000
            -171.5000 -156.5000
            -166.0000 -161.0000
            -161.0000 -166.0000
            -157.0000 -172.0000
            -153.0000 -178.0000
            -150.0000 -185.0000
            -148.0000 -193.0000
            -146.0000 -201.0000
            -145.0000 -210.0000
            -145.0000 -220.0000
            -144.0000 -229.0000
            -144.0000 -239.0000
            -144.0000 -249.0000
            -144.0000 -259.0000
            -144.0000 -269.0000
            -144.0000 -279.0000
            -144.0000 -289.0000
            -144.0000 -299.0000
            -144.0000 -309.0000
            -144.0000 -319.0000
            -144.0000 -329.0000
            -144.0000 -339.0000
            -144.0000 -349.0000
            -144.0000 -359.0000
            -144.0000 -369.0000
            -144.0000 -379.0000
            -144.0000 -389.0000
            -144.0000 -399.0000
            -144.0000 -409.0000
            -144.0000 -419.0000
            -144.0000 -429.0000
            -144.0000 -439.0000
            -144.0000 -449.0000
            -144.0000 -459.0000
            -144.0000 -469.0000
            -144.0000 -479.0000
            -144.0000 -489.0000
            -144.0000 -499.0000
            -144.0000 -509.0000
            -144.0000 -519.0000
            -144.0000 -529.0000
            -144.0000 -539.0000
            -144.0000 -549.0000
            -144.0000 -559.0000
            -144.0000 -569.0000
            -144.0000 -579.0000
            -144.0000 -589.0000
            -144.0000 -599.0000
            -144.0000 -609.0000
            -144.0000 -619.0000
            -144.0000 -629.0000
            -144.0000 -639.0000
            -144.0000 -649.0000
            -144.0000 -659.0000
            -144.0000 -669.0000
            -144.0000 -679.0000
            -144.0000 -689.0000
            -144.0000 -699.0000
            -145.0000 -708.0000
            -145.0000 -718.0000
            -147.0000 -726.0000
            -149.0000 -734.0000
            -152.5000 -740.5000
            -157.0000 -746.0000
            -163.0000 -750.0000
            -170.0000 -753.0000
            -177.5000 -755.5000
            -185.5000 -757.5000
            -194.5000 -758.5000
            -203.5000 -759.5000
            -213.5000 -759.5000
            -216.0000 -767.0000
            -212.5000 -773.5000
            -202.5000 -773.5000
            -192.5000 -773.5000
            -182.5000 -773.5000
            -172.5000 -773.5000
            -162.5000 -773.5000
            -152.5000 -773.5000
            -142.5000 -773.5000
            -132.5000 -773.5000
            -122.5000 -773.5000
            -112.5000 -773.5000
            -102.5000 -773.5000
            -92.5000 -773.5000
            -82.5000 -773.5000
            -72.5000 -773.5000
            -62.5000 -773.5000
            -52.5000 -773.5000
            -42.5000 -773.5000
            -32.5000 -773.5000
            -22.5000 -773.5000
            -12.5000 -773.5000
            -2.5000 -773.5000
            0 -766.0000
            -3.5000 -759.5000
            -13.0000 -759.0000
            -22.5000 -758.5000
            -30.5000 -756.5000
            -38.5000 -754.5000
            -45.5000 -751.5000
            -52.0000 -748.0000
            -58.0000 -744.0000
            -63.0000 -739.0000
            -67.0000 -733.0000
            -69.5000 -725.5000
            -71.0000 -717.0000
            -72.0000 -708.0000
            -72.0000 -698.0000
            -72.0000 -688.0000
            -72.0000 -678.0000
            -72.0000 -668.0000
            -72.0000 -658.0000
            -72.0000 -648.0000
            -72.0000 -638.0000
            -72.0000 -628.0000
            -72.0000 -618.0000
            -72.0000 -608.0000
            -72.0000 -598.0000
            -72.0000 -588.0000
            -72.0000 -578.0000
            -72.0000 -568.0000
            -72.0000 -558.0000
            -72.0000 -548.0000
            -72.0000 -538.0000
            -72.0000 -528.0000
            -72.0000 -518.0000
            -72.0000 -508.0000
            -72.0000 -498.0000
            -72.0000 -488.0000
            -72.0000 -478.0000
            -72.0000 -468.0000
            -72.0000 -458.0000
            -72.0000 -448.0000
            -72.0000 -438.0000
            -72.0000 -428.0000
            -72.0000 -418.0000
            -72.0000 -408.0000
            -72.0000 -398.0000
            -72.0000 -388.0000
            -72.0000 -378.0000
            -72.0000 -368.0000
            -72.0000 -358.0000
            -72.0000 -348.0000
            -72.0000 -338.0000
            -72.0000 -328.0000
            -72.0000 -318.0000
            -72.0000 -308.0000
            -72.0000 -298.0000
            -72.0000 -288.0000
            -72.0000 -278.0000
            -72.0000 -268.0000
            -72.0000 -258.0000
            -72.0000 -248.0000
            -72.0000 -238.0000
            -72.0000 -228.0000
            -73.0000 -219.0000
            -73.0000 -211.0000
            -73.0000 -201.0000
            -74.0000 -192.0000
            -74.5000 -182.5000
            -75.5000 -173.5000
            -77.0000 -165.0000
            -79.0000 -157.0000
            -82.5000 -150.5000
            -86.0000 -144.0000
            -90.5000 -138.5000
            -95.5000 -133.5000
            -101.0000 -129.0000
            -106.5000 -124.5000
            -113.0000 -121.0000
            -119.5000 -117.5000
            -126.5000 -114.5000
            -134.0000 -112.0000
            -141.5000 -109.5000
            -149.5000 -107.5000
            -158.5000 -106.5000
            -166.5000 -104.5000
            -176.5000 -104.5000
            -185.5000 -103.5000];



        P=[X; X(1,:)]/max(abs(X(:,1)));

        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 43

        domain_str='S(43):';
        order=3;
        example=3;
        switch example
            case 1
                files=dir('topolino.dat');
            case 2
                files=dir('m.dat');
        case 3
                files=dir('n2.dat');
        end
        fName=files.name;
        fFolder=files.folder;
        fullname=fullfile(fFolder,fName);

        % Assemblying data.
        X=load(fullname);
        
        xx=-X(:,1); xx=-(xx-min(xx)); yy=-X(:,2); X=[xx yy];
        X=X(1:20:size(X,1),:);
        P=[X; X(1,:)]/max(abs(X(:,1)));
        
                
        plot(P(:,1),P(:,2),'-')
        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);





    otherwise % circular segment
        domain_str='circular segment';

        C=[0 0]; alpha=pi/4; beta=pi; r=1;

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',C,'angles',[alpha beta],'radius',r);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % "close" the boundary with a segment
        geometry_NURBS(2)=makeNURBSarc('segment','extrema',...
            [Pend; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

end















function [cents,rs]=gallery_uniondisks(example)

if nargin < 1
    example=0;
end

switch example
    case 0

        disks=[
            4.172670690843695e-01 6.443181301936917e-01 9.630885392869130e-01
            4.965443032574213e-02 3.786093826602684e-01 5.468057187389680e-01
            9.027161099152811e-01 8.115804582824772e-01 5.211358308040015e-01];

        cents=disks(:,1:2);
        rs=disks(:,3);

    case 1
        disks=[
            4.172670690843695e-01 6.443181301936917e-01 9.630885392869130e-01
            4.965443032574213e-02 3.786093826602684e-01 5.468057187389680e-01
            9.027161099152811e-01 8.115804582824772e-01 5.211358308040015e-01
            9.447871897216460e-01 5.328255887994549e-01 2.315943867085238e-01
            4.908640924680799e-01 3.507271035768833e-01 4.888977439201669e-01
            4.892526384000189e-01 9.390015619998868e-01 6.240600881736895e-01
            3.377194098213772e-01 8.759428114929838e-01 6.791355408657477e-01
            9.000538464176620e-01 5.501563428984222e-01 3.955152156685930e-01
            3.692467811202150e-01 6.224750860012275e-01 3.674366485444766e-01
            1.112027552937874e-01 5.870447045314168e-01 9.879820031616328e-01
            7.802520683211379e-01 2.077422927330285e-01 3.773886623955214e-02
            3.897388369612534e-01 3.012463302794907e-01 8.851680082024753e-01
            2.416912859138327e-01 4.709233485175907e-01 9.132868276392390e-01
            4.039121455881147e-01 2.304881602115585e-01 7.961838735852120e-01
            9.645452516838859e-02 8.443087926953891e-01 9.871227865557430e-02
            1.319732926063351e-01 1.947642895670493e-01 2.618711838707161e-01
            9.420505907754851e-01 2.259217809723988e-01 3.353568399627965e-01
            9.561345402298023e-01 1.707080471478586e-01 6.797279513773380e-01
            5.752085950784656e-01 2.276642978165535e-01 1.365531373553697e-01
            5.977954294715582e-02 4.356986841038991e-01 7.212274985817402e-01
            2.347799133724063e-01 3.111022866504128e-01 1.067618616072414e-01
            3.531585712220711e-01 9.233796421032439e-01 6.537573486685596e-01
            8.211940401979591e-01 4.302073913295840e-01 4.941739366392701e-01
            1.540343765155505e-02 1.848163201241361e-01 7.790517232312751e-01
            4.302380165780784e-02 9.048809686798929e-01 7.150370784006941e-01
            1.689900294627044e-01 9.797483783560852e-01 9.037205605563163e-01
            6.491154749564521e-01 4.388699731261032e-01 8.909225043307892e-01
            7.317223856586703e-01 1.111192234405988e-01 3.341630527374962e-01
            6.477459631363067e-01 2.580646959120669e-01 6.987458323347945e-01
            4.509237064309449e-01 4.087198461125521e-01 1.978098266859292e-01
            5.470088922863450e-01 5.948960740086143e-01 3.054094630463666e-02
            2.963208056077732e-01 2.622117477808454e-01 7.440742603674624e-01
            7.446928070741562e-01 6.028430893820830e-01 5.000224355902009e-01
            1.889550150325445e-01 7.112157804336829e-01 4.799221411460605e-01
            6.867754333653150e-01 2.217467340172401e-01 9.047222380673627e-01
            1.835111557372697e-01 1.174176508558059e-01 6.098666484225584e-01
            3.684845964903365e-01 2.966758732183269e-01 6.176663895884547e-01
            6.256185607296904e-01 3.187783019258823e-01 8.594423056462123e-01
            7.802274351513768e-01 4.241667597138072e-01 8.054894245296856e-01
            8.112576886578526e-02 5.078582846611182e-01 5.767215156146851e-01
            9.293859709687300e-01 8.551579709004398e-02 1.829224694149140e-01
            7.757126786084023e-01 2.624822346983327e-01 2.399320105687174e-01
            4.867916324031724e-01 8.010146227697388e-01 8.865119330761013e-01
            4.358585885809191e-01 2.922027756214629e-02 2.867415246410610e-02
            4.467837494298063e-01 9.288541394780446e-01 4.899013885122239e-01
            3.063494720165574e-01 7.303308628554529e-01 1.679271456822568e-01
            5.085086553811270e-01 4.886089738035791e-01 9.786806496411588e-01
            5.107715641721097e-01 5.785250610234389e-01 7.126944716789141e-01
            8.176277083222621e-01 2.372835797715215e-01 5.004716241548430e-01
            7.948314168834530e-01 4.588488281799311e-01 4.710883745419393e-01
            ];

        Ndisks=15;
        cents=disks(1:Ndisks,1:2);
        rs=disks(1:Ndisks,3);

    case 2

        M=20;
        angles=linspace(0,2*pi,M);
        angles=angles';

        r1=2;
        cents1=r1*[cos(angles) sin(angles)];
        rs1=(r1/4)*ones(size(cents1,1),1);

        r2=4;
        cents2=r2*[cos(angles) sin(angles)];
        rs2=(r2/4)*ones(size(cents2,1),1);

        cents=[cents1; cents2];
        rs=[rs1; rs2];

    case 3

        M=45;

        t=linspace(0,5,M);
        y=2*t;
        x=2.5*cos(2*t);
        cents=[x' y'];
        x=2.5*sin(2*t);
        cents0=[x' y'];
        cents=[cents; cents0];
        rs=0.3*ones(size(cents,1),1);

    otherwise
        M=16;
        cents=rand(M,2);
        rs=rand(M,1);
end













function [cc,r,a,b,v,conv]=gallery_polygcirc(domain_type)

switch domain_type

    case 1
        % TEST 1: concave arc
        cc=[0 0]; r=0.25; % circle defs; center "cc" and radius "r"
        a=[0.25 0]; % first point of the circle
        b=[0 0.25]; % last point of the circle
        v=[0.5 0; 0.5 0.5; 0 0.5]; % polygon vertices
        conv=0; % 0: concave arc

    case 2
        % TEST 2: convex arc
        cc=[0.25 0.25]; r=0.25; % circle defs; center "cc" and radius "r"
        a=[0.25 0]; % first point of the circle
        b=[0 0.25]; % last point of the circle
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        conv=1; % 1: convex arc

    case 3
        % TEST 3: concave arc
        cc=[0 0];r=0.25; % circle defs; center "cc" and radius "r"
        a=[0.25 0]; % first point of the circle
        b=[0 0.25]; % last point of the circle
        v=[0.25 0.2;0.2 0.25]; % polyg. vert.
        conv=0; % 0: concave arc

    otherwise
        % TEST 4 convex arc
        cc=[0 0]; r=0.25; % circle defs; center "cc" and radius "r"
        a=[0.25 0]; % first point of the circle
        b=[0 0.25]; % last point of the circle
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        conv=0; % 0: concave arc

end














function [P,domain_str]=gallery_polygons(example)

P=[];

switch example

    case 1
        domain_str='UNIT SQUARE [0,1]^2';
        k=1;
        polygon_sides=k*[0 0; 1 0; 1 1; 0 1];

    case 2
        domain_str='CONVEX POLYGON';
        polygon_sides=[0.1 0; 0.7 0.2; 1 0.5; 0.75 0.85; 0.5 1; 0 0.25];

    case 3
        domain_str='NON CONVEX POLYGON';
        polygon_sides=(1/4)*[1 0; 3 2; 3 0; 4 2; 3 3; 3 0.85*4; 2 4; ...
            0 3; 1 2];

    case 4
        domain_str='Polygon';
        polygon_sides=(1/4)*[1 0; 3 2; 3 0; 4 2; 3 3; 3 4; 2 4; 0 3; 1 2];

    case 5
        domain_str='Polygon';
        polygon_sides=(1/4)*[0 0; 1 2; 2 0; 3 2; 4 0; 4 4; 3 2; 2 4; ...
            1 2; 0 4];

    case 6
        domain_str='UNIT SQUARE [-1,1]^2';
        polygon_sides=[-1 -1; 1 -1; 1 1; -1 1];

    case 7
        domain_str='UNIT TRIANGLE: [0 0; 1 0; 1 1]';
        polygon_sides=[0 0; 1 0; 1 1];

    case 8
        domain_str='PSEUDO-CIRCLE';
        N=20; a=0; b=2*pi;
        h=(b-a)/N; theta=(a:h:b-h)';
        x=cos(theta); y=sin(theta);
        x=0.5*x+0.5; y=0.5*y+0.5;
        polygon_sides=[x y];

    case 9 % domain with holes (using polyshape)
        domain_str='DOMAIN WITH HOLES';
        Nsides=10;
        th=linspace(0,2*pi,Nsides); th=(th(1:end-1))';
        % first polygon.
        polygon1=[cos(th) sin(th)]; P1=polyshape(polygon1);
        % second polygon.
        polygon2=2+[cos(th) sin(th)]; P2=polyshape(polygon2);
        % third polygon.
        polygon3=0.5*[cos(th) sin(th)]; P3=polyshape(polygon3);

        P=subtract(P1,P3);
        P=union(P,P2);

    case 10

        X=[
            -191.0000 -104.0000
            -200.5000 -104.5000
            -209.5000 -105.5000
            -218.5000 -106.5000
            -226.5000 -108.5000
            -235.0000 -110.0000
            -243.5000 -111.5000
            -251.5000 -113.5000
            -258.5000 -116.5000
            -266.5000 -118.5000
            -274.5000 -120.5000
            -281.5000 -123.5000
            -289.0000 -126.0000
            -296.5000 -128.5000
            -303.5000 -131.5000
            -310.5000 -134.5000
            -318.0000 -137.0000
            -325.0000 -140.0000
            -332.0000 -143.0000
            -334.0000 -136.0000
            -334.0000 -126.0000
            -334.0000 -116.0000
            -341.5000 -113.5000
            -351.5000 -113.5000
            -361.5000 -113.5000
            -371.5000 -113.5000
            -381.5000 -113.5000
            -391.5000 -113.5000
            -401.5000 -113.5000
            -411.5000 -113.5000
            -421.5000 -113.5000
            -431.5000 -113.5000
            -441.5000 -113.5000
            -451.5000 -113.5000
            -461.5000 -113.5000
            -471.5000 -113.5000
            -478.0000 -117.0000
            -477.0000 -126.0000
            -468.5000 -127.5000
            -459.5000 -128.5000
            -450.5000 -129.5000
            -441.5000 -130.5000
            -434.0000 -133.0000
            -427.0000 -136.0000
            -421.0000 -140.0000
            -416.0000 -145.0000
            -412.0000 -151.0000
            -409.0000 -158.0000
            -407.0000 -166.0000
            -407.0000 -176.0000
            -406.0000 -185.0000
            -406.0000 -195.0000
            -406.0000 -205.0000
            -406.0000 -215.0000
            -406.0000 -225.0000
            -406.0000 -235.0000
            -406.0000 -245.0000
            -406.0000 -255.0000
            -406.0000 -265.0000
            -406.0000 -275.0000
            -406.0000 -285.0000
            -406.0000 -295.0000
            -406.0000 -305.0000
            -406.0000 -315.0000
            -406.0000 -325.0000
            -406.0000 -335.0000
            -406.0000 -345.0000
            -406.0000 -355.0000
            -406.0000 -365.0000
            -406.0000 -375.0000
            -406.0000 -385.0000
            -406.0000 -395.0000
            -406.0000 -405.0000
            -406.0000 -415.0000
            -406.0000 -425.0000
            -406.0000 -435.0000
            -406.0000 -445.0000
            -406.0000 -455.0000
            -406.0000 -465.0000
            -406.0000 -475.0000
            -406.0000 -485.0000
            -406.0000 -495.0000
            -406.0000 -505.0000
            -406.0000 -515.0000
            -406.0000 -525.0000
            -406.0000 -535.0000
            -406.5000 -544.5000
            -407.0000 -554.0000
            -408.0000 -563.0000
            -410.0000 -571.0000
            -413.0000 -578.0000
            -417.5000 -583.5000
            -423.0000 -588.0000
            -429.5000 -591.5000
            -436.5000 -594.5000
            -444.5000 -596.5000
            -453.0000 -598.0000
            -462.5000 -598.5000
            -471.5000 -599.5000
            -478.0000 -603.0000
            -477.0000 -612.0000
            -468.5000 -613.5000
            -458.5000 -613.5000
            -448.5000 -613.5000
            -438.5000 -613.5000
            -428.5000 -613.5000
            -418.5000 -613.5000
            -408.5000 -613.5000
            -398.5000 -613.5000
            -388.5000 -613.5000
            -378.5000 -613.5000
            -368.5000 -613.5000
            -358.5000 -613.5000
            -348.5000 -613.5000
            -338.5000 -613.5000
            -328.5000 -613.5000
            -318.5000 -613.5000
            -308.5000 -613.5000
            -298.5000 -613.5000
            -288.5000 -613.5000
            -278.5000 -613.5000
            -268.5000 -613.5000
            -262.0000 -610.0000
            -263.0000 -601.0000
            -271.5000 -599.5000
            -280.5000 -598.5000
            -289.5000 -597.5000
            -297.5000 -595.5000
            -305.0000 -593.0000
            -311.5000 -589.5000
            -318.0000 -586.0000
            -323.0000 -581.0000
            -327.0000 -575.0000
            -330.5000 -568.5000
            -333.0000 -561.0000
            -333.0000 -551.0000
            -334.0000 -542.0000
            -334.0000 -532.0000
            -334.0000 -522.0000
            -334.0000 -512.0000
            -334.0000 -502.0000
            -334.0000 -492.0000
            -334.0000 -482.0000
            -334.0000 -472.0000
            -334.0000 -462.0000
            -334.0000 -452.0000
            -334.0000 -442.0000
            -334.0000 -432.0000
            -334.0000 -422.0000
            -334.0000 -412.0000
            -334.0000 -402.0000
            -334.0000 -392.0000
            -334.0000 -382.0000
            -334.0000 -372.0000
            -334.0000 -362.0000
            -334.0000 -352.0000
            -334.0000 -342.0000
            -334.0000 -332.0000
            -334.0000 -322.0000
            -334.0000 -312.0000
            -334.0000 -302.0000
            -334.0000 -292.0000
            -334.0000 -282.0000
            -334.0000 -272.0000
            -334.0000 -262.0000
            -334.0000 -252.0000
            -334.0000 -242.0000
            -334.0000 -232.0000
            -334.0000 -222.0000
            -334.0000 -212.0000
            -334.0000 -202.0000
            -334.0000 -192.0000
            -334.0000 -182.0000
            -332.0000 -174.0000
            -325.0000 -171.0000
            -317.5000 -168.5000
            -310.5000 -165.5000
            -303.5000 -162.5000
            -295.5000 -160.5000
            -288.5000 -157.5000
            -280.5000 -155.5000
            -272.5000 -153.5000
            -264.5000 -151.5000
            -256.5000 -149.5000
            -247.5000 -148.5000
            -239.5000 -146.5000
            -229.5000 -146.5000
            -220.5000 -145.5000
            -210.5000 -145.5000
            -201.5000 -146.5000
            -192.5000 -147.5000
            -185.0000 -150.0000
            -177.5000 -152.5000
            -171.5000 -156.5000
            -166.0000 -161.0000
            -161.0000 -166.0000
            -157.0000 -172.0000
            -153.0000 -178.0000
            -150.0000 -185.0000
            -148.0000 -193.0000
            -146.0000 -201.0000
            -145.0000 -210.0000
            -145.0000 -220.0000
            -144.0000 -229.0000
            -144.0000 -239.0000
            -144.0000 -249.0000
            -144.0000 -259.0000
            -144.0000 -269.0000
            -144.0000 -279.0000
            -144.0000 -289.0000
            -144.0000 -299.0000
            -144.0000 -309.0000
            -144.0000 -319.0000
            -144.0000 -329.0000
            -144.0000 -339.0000
            -144.0000 -349.0000
            -144.0000 -359.0000
            -144.0000 -369.0000
            -144.0000 -379.0000
            -144.0000 -389.0000
            -144.0000 -399.0000
            -144.0000 -409.0000
            -144.0000 -419.0000
            -144.0000 -429.0000
            -144.0000 -439.0000
            -144.0000 -449.0000
            -144.0000 -459.0000
            -144.0000 -469.0000
            -144.0000 -479.0000
            -144.0000 -489.0000
            -144.0000 -499.0000
            -144.0000 -509.0000
            -144.0000 -519.0000
            -144.0000 -529.0000
            -144.0000 -539.0000
            -144.0000 -549.0000
            -144.0000 -559.0000
            -144.0000 -569.0000
            -144.0000 -579.0000
            -144.0000 -589.0000
            -144.0000 -599.0000
            -144.0000 -609.0000
            -144.0000 -619.0000
            -144.0000 -629.0000
            -144.0000 -639.0000
            -144.0000 -649.0000
            -144.0000 -659.0000
            -144.0000 -669.0000
            -144.0000 -679.0000
            -144.0000 -689.0000
            -144.0000 -699.0000
            -145.0000 -708.0000
            -145.0000 -718.0000
            -147.0000 -726.0000
            -149.0000 -734.0000
            -152.5000 -740.5000
            -157.0000 -746.0000
            -163.0000 -750.0000
            -170.0000 -753.0000
            -177.5000 -755.5000
            -185.5000 -757.5000
            -194.5000 -758.5000
            -203.5000 -759.5000
            -213.5000 -759.5000
            -216.0000 -767.0000
            -212.5000 -773.5000
            -202.5000 -773.5000
            -192.5000 -773.5000
            -182.5000 -773.5000
            -172.5000 -773.5000
            -162.5000 -773.5000
            -152.5000 -773.5000
            -142.5000 -773.5000
            -132.5000 -773.5000
            -122.5000 -773.5000
            -112.5000 -773.5000
            -102.5000 -773.5000
            -92.5000 -773.5000
            -82.5000 -773.5000
            -72.5000 -773.5000
            -62.5000 -773.5000
            -52.5000 -773.5000
            -42.5000 -773.5000
            -32.5000 -773.5000
            -22.5000 -773.5000
            -12.5000 -773.5000
            -2.5000 -773.5000
            0 -766.0000
            -3.5000 -759.5000
            -13.0000 -759.0000
            -22.5000 -758.5000
            -30.5000 -756.5000
            -38.5000 -754.5000
            -45.5000 -751.5000
            -52.0000 -748.0000
            -58.0000 -744.0000
            -63.0000 -739.0000
            -67.0000 -733.0000
            -69.5000 -725.5000
            -71.0000 -717.0000
            -72.0000 -708.0000
            -72.0000 -698.0000
            -72.0000 -688.0000
            -72.0000 -678.0000
            -72.0000 -668.0000
            -72.0000 -658.0000
            -72.0000 -648.0000
            -72.0000 -638.0000
            -72.0000 -628.0000
            -72.0000 -618.0000
            -72.0000 -608.0000
            -72.0000 -598.0000
            -72.0000 -588.0000
            -72.0000 -578.0000
            -72.0000 -568.0000
            -72.0000 -558.0000
            -72.0000 -548.0000
            -72.0000 -538.0000
            -72.0000 -528.0000
            -72.0000 -518.0000
            -72.0000 -508.0000
            -72.0000 -498.0000
            -72.0000 -488.0000
            -72.0000 -478.0000
            -72.0000 -468.0000
            -72.0000 -458.0000
            -72.0000 -448.0000
            -72.0000 -438.0000
            -72.0000 -428.0000
            -72.0000 -418.0000
            -72.0000 -408.0000
            -72.0000 -398.0000
            -72.0000 -388.0000
            -72.0000 -378.0000
            -72.0000 -368.0000
            -72.0000 -358.0000
            -72.0000 -348.0000
            -72.0000 -338.0000
            -72.0000 -328.0000
            -72.0000 -318.0000
            -72.0000 -308.0000
            -72.0000 -298.0000
            -72.0000 -288.0000
            -72.0000 -278.0000
            -72.0000 -268.0000
            -72.0000 -258.0000
            -72.0000 -248.0000
            -72.0000 -238.0000
            -72.0000 -228.0000
            -73.0000 -219.0000
            -73.0000 -211.0000
            -73.0000 -201.0000
            -74.0000 -192.0000
            -74.5000 -182.5000
            -75.5000 -173.5000
            -77.0000 -165.0000
            -79.0000 -157.0000
            -82.5000 -150.5000
            -86.0000 -144.0000
            -90.5000 -138.5000
            -95.5000 -133.5000
            -101.0000 -129.0000
            -106.5000 -124.5000
            -113.0000 -121.0000
            -119.5000 -117.5000
            -126.5000 -114.5000
            -134.0000 -112.0000
            -141.5000 -109.5000
            -149.5000 -107.5000
            -158.5000 -106.5000
            -166.5000 -104.5000
            -176.5000 -104.5000
            -185.5000 -103.5000];

        polygon_sides=[X; X(1,:)]/max(abs(X(:,1)));



    otherwise
        domain_str='NON CONVEX POLYGON';
        polygon_sides=(1/4)*[1 0; 3 2; 3 0; 4 2; 3 3; 3 0.85*4; 2 4; ...
            0 3; 1 2];
end

if isempty(P)
P=polyshape(polygon_sides);
end



