
function plot_rotation_domain(basis_structure,arc_intv,dir_axis,x0,...
    pts1,pts2)

%--------------------------------------------------------------------------
% Object:
% Plot the "frames" of a rotation domain defined by "basis_structure",
% around the axis with direction "dir_axis" and containing "x0".
% Furthermore it plots the points stored in "pts".
%--------------------------------------------------------------------------
% Input:
% basis_structure: planar domain, basis of the pyramid;
% arcs_intv: rotation interval (subinterval of [0,2*pi]);
% dir_axis: axis direction;
% x0: point of the axis;
% pts1: points belonging to the domain (first set);
% pts2: points belonging to the domain (second set).
%--------------------------------------------------------------------------

if nargin < 2, arc_intv=[0 2*pi]; end
if nargin < 3, dir_axis=[0 1 0]; end
if nargin < 4, x0=[0 0 0]; end
if nargin < 5, pts1=[]; end
if nargin < 6, pts2=[]; end



% ................ plot rotation domain frame .............................

domain_basis_str=basis_structure.domain;
domain_contour_str=domain_contour_string(domain_basis_str);
domain_contour.domain=domain_contour_str;
domain_contour.parms=basis_structure.parms;

hold on;

if length(domain_contour_str) > 0
    domain_contour_ref=define_wam_pointset(domain_contour,100);
    domain_contour_ref=[domain_contour_ref; domain_contour_ref(1,:)];
    domain_contour_ref=[domain_contour_ref ...
        zeros(size(domain_contour_ref,1),1)];
    degV=180*linspace(arc_intv(1),arc_intv(2),40)/pi;
    for j=1:length(degV)
        degL=degV(j);
        [XL, ~, ~] = AxelRot(domain_contour_ref', degL, dir_axis', x0');
        XL=XL';
        plot3(XL(:,1),XL(:,2),XL(:,3),'.','Color',[0.5 0.5 0.5],...
            'MarkerSize',1)
    end
end




% .......................... plot pointsets ...............................

if isempty(pts1) == 0
    plot3(pts1(:,1),pts1(:,2),pts1(:,3),'*');
end

if isempty(pts2) == 0
    plot3(pts2(:,1),pts2(:,2),pts2(:,3),'o');
end


hold off;






function domain_contour_str=domain_contour_string(domain_basis_str)

S(1)=strcmp(domain_basis_str,'polygon');
S(2)=strcmp(domain_basis_str,'lune');
S(3)=strcmp(domain_basis_str,'circular-annular-sector');
S(4)=strcmp(domain_basis_str,'disk');
S(5)=strcmp(domain_basis_str,'asymmetric-circular-sector');
S(6)=strcmp(domain_basis_str,'asymmetric-annulus');
S(7)=strcmp(domain_basis_str,'vertical-circular-zone');
S(8)=strcmp(domain_basis_str,'horizontal-circular-zone');
S(9)=strcmp(domain_basis_str,'circular-segment');
S(10)=strcmp(domain_basis_str,'symmetric-lens');
S(11)=strcmp(domain_basis_str,'butterfly');
S(12)=strcmp(domain_basis_str,'candy');
S(13)=strcmp(domain_basis_str,'convex-level-curve');
S(14)=strcmp(domain_basis_str,'circle-arc');
S(15)=strcmp(domain_basis_str,'sphere');
S(16)=strcmp(domain_basis_str,'spherical-rectangle');
S(17)=strcmp(domain_basis_str,'pyramid');
S(18)=strcmp(domain_basis_str,'3D_rect');
S(19)=strcmp(domain_basis_str,'rotation-domain');
S(20)=strcmp(domain_basis_str,'polygonal-boundary');
S(21)=strcmp(domain_basis_str,'pluriinterval');
S(22)=strcmp(domain_basis_str,'sector');
S(23)=strcmp(domain_basis_str,'pyramid-boundary');
S(24)=strcmp(domain_basis_str,'asymmetric-circular-sector-boundary');
S(25)=strcmp(domain_basis_str,'asymmetric-annulus-boundary');
S(26)=strcmp(domain_basis_str,'vertical-circular-zone-boundary');
S(27)=strcmp(domain_basis_str,'horizontal-circular-zone-boundary');
S(28)=strcmp(domain_basis_str,'circular-segment-boundary');
S(29)=strcmp(domain_basis_str,'symmetric-lens-boundary');
S(30)=strcmp(domain_basis_str,'butterfly-boundary');
S(31)=strcmp(domain_basis_str,'candy-boundary');
S(32)=strcmp(domain_basis_str,'sector-boundary');
S(33)=strcmp(domain_basis_str,'rotation-surface');

domain_contour_str='';

if S(1) == 1, domain_contour_str='polygonal-boundary'; end
if S(2) == 1, domain_contour_str=''; end
if S(3) == 1, domain_contour_str='circular-annular-sector'; end
if S(4) == 1, domain_contour_str='circle-arc'; end
if S(5) == 1, domain_contour_str='asymmetric-circular-sector-boundary'; end
if S(6) == 1, domain_contour_str='asymmetric-annulus-boundary'; end
if S(7) == 1, domain_contour_str='vertical-circular-zone-boundary'; end
if S(8) == 1, domain_contour_str='horizontal-circular-zone-boundary'; end
if S(9) == 1, domain_contour_str='circular-segment-boundary'; end
if S(10) == 1, domain_contour_str='symmetric-lens-boundary'; end
if S(11) == 1, domain_contour_str='butterfly-boundary'; end
if S(12) == 1, domain_contour_str='candy-boundary'; end
if S(13) == 1, domain_contour_str=''; end
if S(14) == 1, domain_contour_str='circle-arc'; end
if S(15) == 1, domain_contour_str=''; end
if S(16) == 1, domain_contour_str=''; end
if S(17) == 1, domain_contour_str=''; end
if S(18) == 1, domain_contour_str=''; end
if S(19) == 1, domain_contour_str=''; end
if S(20) == 1, domain_contour_str='polygonal-boundary'; end
if S(21) == 1, domain_contour_str=''; end
if S(22) == 1, domain_contour_str=''; end
if S(23) == 1, domain_contour_str=''; end
if S(24) == 1, domain_contour_str='asymmetric-circular-sector-boundary'; end
if S(25) == 1, domain_contour_str='asymmetric-annulus-boundary'; end
if S(26) == 1, domain_contour_str='vertical-circular-zone-boundary'; end
if S(27) == 1, domain_contour_str='horizontal-circular-zone-boundary'; end
if S(28) == 1, domain_contour_str='circular-segment-boundary'; end
if S(29) == 1, domain_contour_str='symmetric-lens-boundary'; end
if S(30) == 1, domain_contour_str='butterfly-boundary'; end
if S(31) == 1, domain_contour_str='candy-boundary'; end
if S(32) == 1, domain_contour_str='sector-boundary'; end
if S(33) == 1, domain_contour_str=''; end











