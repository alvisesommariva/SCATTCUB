

function [f,fs]=gallery_2D(example,gallery_type,parms)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Battery of bivariate test functions.
%--------------------------------------------------------------------------
% INPUT
%--------------------------------------------------------------------------
% example: parameter that chooses the function
% gallery_type: string that chooses the function and can be
%         'easy' some rather well behaved functions
%                (set as "example" a value in 1,...,23);
%         'renka-brown' that are taken from the paper 1., mentioned below;
%                (set as "example" a value in 1,...,10);
%         'polynomials' polynomials of degree "parms";
%                (set as "example" a value in 1,...,2);
% parms: additional parameters, as the degree of a polynomial.
%--------------------------------------------------------------------------
% OUTPUT
%--------------------------------------------------------------------------
% f : function to be tested
%--------------------------------------------------------------------------
% PAPERS
%--------------------------------------------------------------------------
% 1. Algorithm 792: Accuracy Tests of ACM Algorithms for Interpolation of
%    Scattered Data in the Plane
%    ROBERT J. RENKA and RON BROWN
%    ACM Transactions on Mathematical Software, Volume 25, Issue 1,pp.78–94
%    https://doi.org/10.1145/305658.305745
%--------------------------------------------------------------------------

if nargin < 1, example=1; end
if isempty(example), example=1; end

if nargin < 2, gallery_type='easy'; end
if isempty(gallery_type), gallery_type='easy'; end

if nargin < 3, parms=10; end
if isempty(parms), parms=10; end

switch gallery_type
    case {'renka-brown','renka'}
        % fprintf('\n \t renka-brown, example: %3.0f',example);
        [f,fs]=renka_brown(example);
    case 'easy'
        % fprintf('\n \t easy, example: %3.0f',example);
        [f,fs]=easy_gallery(example);
    case 'polynomials'
        % fprintf('\n \t polynomials, example: %3.0f',example);
        [f,fs]=polynomials(example,parms);
end









function [f,fs]=renka_brown(example)

switch example
    case 1 % Renka, Brown, F1
        f=@(x,y) franke(x,y);
        fs='Renka, Brown, F1: franke(x,y)';
    case 2 % Renka, Brown, F2
        f=@(x,y) (tanh(9*y-9*x)+1)/9;
        fs='Renka, Brown, F2: (tanh(9*y-9*x)+1)/9';
    case 3 % Renka, Brown, F3
        f=@(x,y) (1.25+cos(5.4*y))./(6+6*(3*x-1).^2);
        fs='Renka, Brown, F3: (1.25+cos(5.4*y))./(6+6*(3*x-1).^2)';
    case 4 % Renka, Brown, F4
        f=@(x,y) (1/3)*exp(-5.0625*((x-0.5).^2+(y-0.5).^2));
        fs='Renka, Brown, F4: (1/3)*exp(-5.0625*((x-0.5).^2+(y-0.5).^2))';
    case 5 % Renka, Brown, F5
        f=@(x,y) (1/3)*exp(-20.25*((x-0.5).^2+(y-0.5).^2));
        fs='Renka, Brown, F5: (1/3)*exp(-20.25*((x-0.5).^2+(y-0.5).^2))';
    case 6 % Renka, Brown, F6
        f=@(x,y) (1/9)*sqrt(64-81*((x-0.5).^2+(y-0.5).^2))-0.5;
        fs='Renka, Brown, F6';
    case 7 % Renka, Brown, F7
        f=@(x,y) 2*cos(10*x).*sin(10*y)+sin(10*x.*y);
        fs='Renka, Brown, F7: 2*cos(10*x).*sin(10*y)+sin(10*x.*y);';
    case 8 % Renka, Brown, F8
        g=@(x) exp(-(5-10*x).^2/2);
        f=@(x,y) g(x)+0.75*g(y)+ 0.75*g(x).*g(y);
        fs='Renka, Brown, F8: g(x)+0.75*g(y)+ 0.75*g(x).*g(y), g=@(x) exp(-(5-10*x).^2/2)';
    case 9 % Renka, Brown, F9
        g=@(x) exp((10-20*x)/3);
        f=@(x,y) ((20/3)^3*g(x).*g(y)).^2.*...
            ((1./(1+g(x))).*(1./(1+g(y)))).^5.*...
            (g(x)-2./(1+g(x))).*(g(x)-2./(1+g(y)));
        fs='Renka, Brown, F9';
    case 10 % Renka, Brown, F10
        g=@(x,y) sqrt((80*x-40).^2+(90*y-45).^2);
        f=@(x,y) exp(-0.04*g(x,y)).*cos(0.15*g(x,y));
        fs='Renka, Brown, F10: exp(-0.04*g(x,y)).*cos(0.15*g(x,y)), g=@(x,y) sqrt((80*x-40).^2+(90*y-45).^2)';
end









function [g,gstring]=easy_gallery(example)

% function to test

switch example

    case 1
        g=@(x,y) (1-x.^2-y.^2).*exp(x.*cos(y));
        gstring='(1-x.^2-y.^2).*exp(x.*cos(y))';
    case 2
        g=@(x,y) exp(-(x.^2+y.^2));
        gstring='exp(-(x.^2+y.^2))';
    case 3
        g=@(x,y) sin(-(x.^2+y.^2));
        gstring='sin(-(x.^2+y.^2))';
    case 4
        g=@(x,y) 1+0*x+0*y;
        gstring='1+0*x+0*y';
    case 5
        g=@(x,y) sqrt((x-0.5).^2+(y-0.5).^2);
        gstring='sqrt((x-0.5).^2+(y-0.5).^2)';
    case 6
        g=@(x,y) (0.2*x+0.5*y).^19;
        gstring='(0.2*x+0.5*y).^19';
    case 7
        g=@(x,y) exp((x-0.5).^2+(y-0.5).^2);
        gstring='exp((x-0.5).^2+(y-0.5).^2)';
    case 8
        g=@(x,y) exp(-100*((x-0.5).^2+(y-0.5).^2));
        gstring='exp(-100*((x-0.5).^2+(y-0.5).^2))';
    case 9
        g=@(x,y) cos(30*(x+y));
        gstring='cos(30*(x+y))';
    case 10
        g=@(x,y) cos(5*(x+y));
        gstring='cos(5*(x+y))';
    case 11
        g=@(x,y) exp((x-0.5).^1+(y-0.5).^1);
        gstring='exp((x-0.5).^1+(y-0.5).^1)';
    case 12
        g=@(x,y) exp((x-0.5).^3+(y-0.5).^3);
        gstring='exp((x-0.5).^3+(y-0.5).^3)';
    case 13
        g=@(x,y) (0.2*x+0.5*y).^15;
        gstring='(0.2*x+0.5*y).^15';
    case 14
        g=@(x,y) 1./(x.^2+y.^2);
        gstring='1./(x.^2+y.^2)';
    case 15
        % g=@(x,y) (x+y).^10;
        g=@(x,y) (1+x+0.5*y).^10;
        gstring='(1+x+0.5*y).^10';
    case 16
        x0=0.5; y0=0.5;
        g=@(x,y) exp(-((x-x0).^2+(y-y0).^2));
        gstring='exp(-((x-x0).^2+(y-y0).^2))';
    case 17
        x0=0.5; y0=0.5;
        g=@(x,y) ((x-x0).^2 + (y-y0).^2).^(3/2);
        gstring='((x-x0).^2 + (y-y0).^2).^(3/2)';
    case 18 % franke
        g=@(x,y) franke(x,y);
        gstring='franke(x,y)';
    case 19 % Glaubitz: Stable High-Order Cubature Formulas for 
            %           Experimental Data
        g=@(x,y) 1./((1+x.^2).*(1+y.^2));
        gstring='1./((1+x.^2).*(1+y.^2))';
    case 20 % Glaubitz: PROVABLE POSITIVE AND EXACT CUBATURE FORMULAS
        g=@(x,y) sqrt(1-x.^2).*sqrt(1-y.^2);
        gstring='sqrt(1-x.^2).*sqrt(1-y.^2)';
    case 21 % Glaubitz: PROVABLE POSITIVE AND EXACT CUBATURE FORMULAS
        g=@(x,y) acos(x).*acos(y);
        gstring='acos(x).*acos(y)';
    case 22 % Glaubitz: PROVABLE POSITIVE AND EXACT CUBATURE FORMULAS
        g=@(x,y) 1./(1+x.^2+y.^2)+sin(x);
        gstring='1./(1+x.^2+y.^2)+sin(x)';
    case 23 % Glaubitz: PROVABLE POSITIVE AND EXACT CUBATURE FORMULAS
        g=@(x,y) (x.^2+y.^2).^(1/4);
        gstring='(x.^2+y.^2).^(1/4)';
end










function [g,gstring]=polynomials(example,deg)

if nargin < 2, deg=10; end

% function to test

switch example

    case 1
        a=pi/16; b=exp(-3.2); c=sin(pi/9);
        g=@(x,y) (a+b*x+c*y).^deg;
        gstring='fixed degree polynomial (assigned coefficients)';

    case 2
        a=rand(1); b=rand(1); c=rand(1);
        g=@(x,y) (a+b*x+c*y).^deg;
        gstring='fixed degree polynomial (random coefficients)';


end







function [g,gstring]=genz(example)

if nargin < 1, example=1; end

% function to test

switch example

    case 1
        a(1)=5; a(2)=5;
        u(1)=0.5; u(2)=0.5;
        g=@(x,y) exp(-a(1)*abs(x-u(1))-a(2)*abs(y-u(2)));
        gstring='exp(-a(1)*abs(x-u(1))-a(2)*abs(y-u(2)))';

    case 2
        a(1)=5; a(2)=5;
        g=@(x,y) (1+a(1)*x+a(2)*y).^(-3);
        gstring='(1+a(1)*x+a(2)*y).^(-3)';

    case 3
        a(1)=5; a(2)=5;
        u(1)=0.5; u(2)=0.5;
        g=@(x,y) exp(-a(1).^2*(x-u(1)).^2-a(2).^2*(y-u(2)).^2);
        gstring='exp(-a(1).^2*(x-u(1)).^2-a(2).^2*(y-u(2)).^2)';

    case 4
        a(1)=5; a(2)=5;
        u(1)=0.5;
        g=@(x,y) cos(2*pi*u(1)+a(1)*x+a(2)*y);
        gstring='cos(2*pi*u(1)+a(1)*x+a(2)*y)';

    case 5
        a(1)=5; a(2)=5;
        u(1)=0.5; u(2)=0.5;
        g=@(x,y) 1./( ( (a(1)).^(-2)+(x-u(1)).^2 ).* ( (a(2)).^(-2)+(y-u(2)).^2 ) );
        gstring='1./(((a(1)).^(-2)+(x-u(1)).^2).*((a(2)).^(-2)+(y-u(2)).^2))';


end