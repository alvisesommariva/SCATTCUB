

function domain_example=domstr2dom(dom_number)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Given a number "dom_number", it provides the name of the corresponding 
% domain in the gallery of domains.
%--------------------------------------------------------------------------

switch dom_number
    
    case 1, domain_example='polygon';
    case 2, domain_example='disk';
    case 3, domain_example='lune';
    case 4, domain_example='circular-annular-sector';
    case 5, domain_example='sector';
    case 6, domain_example='asymmetric-circular-sector';
    case 7, domain_example='asymmetric-annulus';
    case 8, domain_example='vertical-circular-zone';
    case 9, domain_example='horizontal-circular-zone';
    case 10, domain_example='circular-segment';
    case 11, domain_example='symmetric-lens';
    case 12, domain_example='butterfly';
    case 13, domain_example='candy';
    case 14, domain_example='NURBS';
    case 15, domain_example='union-disks';
    case 16, domain_example='asymmetric-circular-sector';
    case 17, domain_example='square';
    case 18, domain_example='rectangle';
    case 19, domain_example='triangle';
    case 20, domain_example='polygcirc';
    case 21, domain_example='unit-simplex';
    case 22, domain_example='unit-square[0,1]x[0,1]';
        
end