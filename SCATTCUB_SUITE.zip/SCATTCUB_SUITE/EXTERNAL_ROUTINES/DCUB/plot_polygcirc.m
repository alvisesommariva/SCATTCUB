
function plot_polygcirc(domain_structure)

dbox=domain_structure.dbox;
xmin=dbox(1,1); xmax=dbox(1,2);
ymin=dbox(2,1); ymax=dbox(2,2);
N=100000;
P=haltonset(2);
pts = net(P,N);
xpts=xmin+(xmax-xmin)*pts(:,1); ypts=ymin+(ymax-ymin)*pts(:,2);
in=indomain_routine(domain_structure,[xpts ypts]);
lightgray_RGB=[211,211,211]/256;


plot(xpts(in),ypts(in),'o','color',lightgray_RGB,...
    'MarkerEdgeColor',lightgray_RGB,'MarkerFaceColor',lightgray_RGB,...
                       'MarkerSize',4)