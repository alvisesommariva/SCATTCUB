
function area_sphtri=sph_triangle_area(vertices)

%--------------------------------------------------------------------------
% Object:
% Area of a spherical triangle whose vertices are defined by "vertices".
%--------------------------------------------------------------------------
% Input:
% vertices: it is a 3 x 3 matrix, where the k-th row describes the k-th
%      vertex in cartesian coordinates.
%--------------------------------------------------------------------------
% Output:
% area_sphtri: area of the spherical triangle defined by "vertices".
%--------------------------------------------------------------------------
% Dates:
% Written on 28/11/2020: A. Sommariva.
%--------------------------------------------------------------------------

if nargin < 1,
    error('Undefined vertices in "sph_triangle_area" routine');
end

P1=vertices(1,:); P2=vertices(2,:); P3=vertices(3,:);
aa=acos(P1*P2');
bb=acos(P1*P3');
cc= acos(P3*P2');

AA=acos( ( cos(aa)-cos(bb)*cos(cc) ) / (sin(bb)*sin(cc)) );
BB=asin( sin(bb) * sin(AA) / sin(aa) );
CC=asin( sin(cc) * sin(AA) / sin(aa) );

area_sphtri=AA+BB+CC-pi;