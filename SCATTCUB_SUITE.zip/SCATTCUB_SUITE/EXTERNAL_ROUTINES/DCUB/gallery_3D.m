
function [f,f_str]=gallery_3D(gallery_str,example)

if nargin < 1, gallery_str='easy'; end
if nargin < 2, example=1; end

switch gallery_str
    case 'easy'
        [f,f_str]=gallery_3D_easy(example);
    otherwise
        [f,f_str]=gallery_3D_hard(example);
end




function [f,fs]=gallery_3D_easy(example)

switch example
    case 1
        f=@(x,y,z) 1./(1+25*(x+2*y+z).^2);
        fs='1./(1+25*(x+2*y+z).^2)';
    case 2
        f=@(x,y,z) sin(x+2*y+1.5*z);
        fs='sin(x+2*y+1.5*z)';
    case 3
        f=@(x,y,z) exp(x+2*y+1.5*z).*cos(10*(x+2*y+1.5*z)).*...
            tanh(4*(x+2*y+1.5*z));
        fs='exp(x+2*y+1.5*z)*cos(10*(x+2*y+1.5*z))*tanh(4*(x+2*y+1.5*z));';
    case 4
        f=@(x,y,z) exp(x+2*y+1.5*z);
        fs='exp(x+2*y+1.5*z)';
    case 5
        f=@(x,y,z) exp(-(x+2*y+1.5*z));
        fs='exp(-(x+2*y+1.5*z))';
    case 6
        f=@(x,y,z) (1.2*(x+2*y+1.5*z).^5+3*(x+2*y+1.5*z)+0.02*(x+2*y+1.5*z).^4-2).^4;
        fs='(1.2*(x+2*y+1.5*z).^5+3*(x+2*y+1.5*z)+0.02*(x+2*y+1.5*z).^4-2).^4';
    case 7
        f=@(x,y,z) (x+2*y+1.5*z).^20+1;
        fs='(x+2*y+1.5*z).^20+1';
    otherwise
        f=@(x,y,z) (1.2*(x+2*y+1.5*z).^3+0.02*(x+2*y+1.5*z).^4+3*(x+2*y+1.5*z)-2).^2;
        fs='(1.2*(x+2*y+1.5*z).^3+0.02*(x+2*y+1.5*z).^4+3*(x+2*y+1.5*z)-2).^2';
end





function [f,fstr]=gallery_3D_hard(example)

switch example

    case 1 % Fornberg
        f=@(x,y,z) 1+x+y.^2+x.^2.*y+x.^4+y.^5+x.^2.*y.^2.*z.^2;
        fstr='1+x+y.^2+x.^2.*y+x.^4+y.^5+x.^2.*y.^2.*z.^2';
    case 2 % Fornberg
        f=@(x,y,z) 0.75*exp(-( (9*x-2).^2 + (9*y-2).^2 + (9*z-2).^2 )/4)+...
            0.75*exp( -(1/49)*((9*x+1).^2) - ((9*y+1)/10) - ((9*z+1)/10) )+...
            0.5*exp(-( (9*x-7).^2 + (9*y-3).^2 + (9*z-5).^2 )/4)+...
            -0.2*exp(-( (9*x-4).^2 + (9*y-7).^2 + (9*z-5).^2 ));
        fstr='franke type';
    case 3 % Fornberg variant
        f=@(x,y,z) (1/9)*(1+tanh(9*x-9*y+9*z));
        fstr='(1/9)*(1+tanh(9*x-9*y+9*z))';
    case 4 % Fornberg variant
        f=@(x,y,z) (1/9)*(1+sign(9*x-9*y+9*z));
        fstr='(1/9)*(1+sign(9*x-9*y+9*z))';
    case 5
        f=@(x,y,z) cos(x+y+z);
        fstr='cos(x+y+z)';
    case 6
        f=@(x,y,z) cos(10*(x+y+z));
        fstr='cos(10*(x+y+z))';
    case 7
        f=@(x,y,z) x+y+z;
        fstr='x+y+z';
    case 8
        f=@(x,y,z) exp(x);
        fstr='exp(x)';
    case 9
        f=@(x,y,z) exp(x+y+z);
        fstr='exp(x+y+z)';
    case 10
        f=@(x,y,z) -5*sin(1+10*z)+0*x+0*y;
        fstr='-5*sin(1+10*z)';
    case 11
        f=@(x,y,z) 1./(101-100*z);
        fstr='1./(101-100*z)';
    case 12
        f=@(x,y,z) (abs(x)+abs(y)+abs(z))/10;
        fstr='(abs(x)+abs(y)+abs(z))/10';
    case 13
        f=@(x,y,z) 1./(abs(x)+abs(y)+abs(z)+eps);
        fstr='1./(abs(x)+abs(y)+abs(z)+eps)';
    case 14
        f=@(x,y,z) sin(1+abs(x)+abs(y)+abs(z)).^2/10;
        fstr='sin(1+abs(x)+abs(y)+abs(z)).^2/10';
    case 15
        f=@(x,y,z) ones(size(x));
        fstr='ones(size(x))';
    case 16
        f=@(x,y,z) 0.0001*abs(6-x.^2-y.^2-z.^2).^2;
        fstr='0.0001*abs(6-x.^2-y.^2-z.^2).^2';
    case 17
        f=@(x,y,z) peaks(x,y+z);
        fstr='peaks(x,y+z)';
    case 18
        f=@(x,y,z)(1.25+cos(5.4*y)).*cos(6*z)./( 6+6*((3*x-1).^2) );
        fstr='(1.25+cos(5.4*y)).*cos(6*z)./( 6+6*((3*x-1).^2) )';
    case 19
        f=@(x,y,z) exp( -(81/16)*((x-0.5).^2 + (y-0.5).^2 + (z-0.5).^2) )/3;
        fstr='exp( -(81/16)*((x-0.5).^2 + (y-0.5).^2 + (z-0.5).^2) )/3';
    case 20
        f=@(x,y,z) exp( -(81/4)*((x-0.5).^2 + (y-0.5).^2 + (z-0.5).^2))/3;
        fstr='exp( -(81/4)*((x-0.5).^2 + (y-0.5).^2 + (z-0.5).^2))/3';
    case 21
        f=@(x,y,z) x.^2+y.^2+z.^2;
        fstr='x.^2+y.^2+z.^2';
    case 22
        f=@(x,y,z) exp(-x.^2-y.^2-z.^2);
        fstr='exp(-x.^2-y.^2-z.^2)';
    case 24 % Fornberg
        f=@(x,y,z) (1/9)*(1+tanh(9*z-9*x-9*y));
        fstr='(1/9)*(1+tanh(9*z-9*x-9*y))';
    case 25 % Fornberg
        f=@(x,y,z) (1/9)*(1+sign(9*z-9*x-9*y));
        fstr='(1/9)*(1+sign(9*z-9*x-9*y))';
    case 26
        f=@(x,y,z) exp(-x.^2-5*y.^2+0.2*z.^2);
        fstr='exp(-x.^2-5*y.^2+0.2*z.^2)';
    otherwise
        f=@(x,y,z) franke(x,y+z);
        fstr='franke(x,y+z)';
end
