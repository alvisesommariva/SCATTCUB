
function plot_S2(domain_type,pts1,pts2,title_str)

%--------------------------------------------------------------------------
% Object:
% Plotting pointsets on regions of the sphere.
%--------------------------------------------------------------------------
% Input:
% domain_type: 'sphere','spherical-rectangle','spherical-triangle'.
%
% x     : * spherical rectangle representation / spherical representation:
%         It is a 2 x 2 matrix, containing all (theta_1,theta2) such that
%         theta_1 in (x(1,1),x(1,2)) and theta_2 in (x(2,1),x(2,2)), and
%         the points in cartesian coordinates are
%                    x_1=sin(theta_1)*cos(theta_2),
%                    x_2=sin(theta_1)*sin(theta_2),
%                    x_3=cos(theta_1)
%         * spherical triangle representation:
%         It is a 3 x 3 matrix, where the k-th row contains the cartesian 
%         coordinates of the k-th vertex of the domain.
%         
% pts1: spherical/cartesian coordinates of first set of points on the unit 
%      sphere possibly belonging to the spherical rectangle/triangle 
%      defined by "x".
%      The k-th row of this matrix determines the k-th point.
%         The points in cartesian coordinates are
%                    x_1=sin(theta_1)*cos(theta_2),
%                    x_2=sin(theta_1)*sin(theta_2),
%                    x_3=cos(theta_1)
%
% pts2: spherical/cartesian coordinates of first set of points on the unit 
%      sphere possibly belonging to the spherical rectangle/triangle 
%      defined by "x".
%      The k-th row of this matrix determines the k-th point.
%      The points in cartesian coordinates are
%                    x_1=sin(theta_1)*cos(theta_2),
%                    x_2=sin(theta_1)*sin(theta_2),
%                    x_3=cos(theta_1)
%
% title_str: string with the title of the domain
%--------------------------------------------------------------------------
% Dates:
% Written on 20/11/2020: A. Sommariva and M. Vianello;
%
% Modified on:
% 28/11/2020: A. Sommariva.
%--------------------------------------------------------------------------


% ......................... troubleshooting ...............................

if nargin < 2, pts1=[]; end
if nargin < 3, pts2=[]; end
if nargin < 4, title_str=''; end

if isempty(pts1), pts1=[]; end
if isempty(pts2), pts2=[]; end
if isempty(title_str), title_str=''; end





% ......................... plot sphere ...................................

[X,Y,Z] = sphere(30); axis equal; grid off; axis off; hold on;
surf(X,Y,Z);

% ......................... plot subdomain ................................
% XWR=define_cub_rule(domain_type,100); 
lightgrey=[150 150 150]/256;

% plot3(XWR(:,1),XWR(:,2),XWR(:,3),'o','Color',lightgrey,'MarkerSize',6);

hold on;


% ......................... plot pointset 1 ...............................
if isempty(pts1) == 0, plot_set(pts1,[0.2 0.2 0.2],'.',1); end

% ......................... plot pointset 2 ...............................
if isempty(pts2) == 0, plot_set(pts2,'magenta','o',6); end

% ......................... adding title ..................................
title(title_str); hold off;









function plot_set(pts,color_str,marker_type,marker_size)

%--------------------------------------------------------------------------
% Object:
% Plotting pointsets on regions of the sphere.
%--------------------------------------------------------------------------
% Input:         
% pts: spherical or cartesian coordinates of a pointset on the 
%       unit sphere.
%      The k-th row of this matrix determines the k-th point.
%      The points in cartesian coordinates are
%                    x_1=sin(theta_1)*cos(theta_2),
%                    x_2=sin(theta_1)*sin(theta_2),
%                    x_3=cos(theta_1)
%
% color_str: color of the pointset, e.g. color_str='magenta';
% marker_type: marker type of the pointset, e.g. marker_type='.';
% marker_size: marker size of the pointset, e.g. marker_size=10.
%--------------------------------------------------------------------------
% Dates:
% Written on 20/11/2020: A. Sommariva and M. Vianello;
%
% Modified on:
% 28/11/2020: A. Sommariva.
%--------------------------------------------------------------------------

% ......................... troubleshooting ...............................

if nargin < 1, pts=[]; end
if nargin < 2, color_str='magenta'; end
if nargin < 3, marker_type='.'; end
if nargin < 4, marker_size=6; end

if isempty(marker_type), marker_type='.'; end
if isempty(marker_size), marker_size=6; end


% ......................... plotting points ...............................

if size(pts,2) == 2 % speherical coordinates
    theta_1=pts(:,1); theta_2=pts(:,2);
    s1=sin(theta_1); c1=cos(theta_1); s2=sin(theta_2); c2=cos(theta_2);
    xx=s1.*c2; yy=s1.*s2; zz=c1;
else % cartesian coordinates
    xx=pts(:,1); yy=pts(:,2); zz=pts(:,3);
end

plot3(xx,yy,zz,marker_type,'Color',color_str,'MarkerEdgeColor','k',...
                       'MarkerFaceColor','g',...
                       'MarkerSize',marker_size);



