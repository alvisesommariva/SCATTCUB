function plot_figure_arcs(centers,rs,active_arcs,...
    disk_sequence,arcs_sizes,centers0,rs0,xyw,xywc)

if nargin < 6, centers0=[]; rs0=[]; end
if nargin < 8, xyw=[]; end
if nargin < 9, xywc=[]; end

add_text=0; % ADD ARCS TEXT
text_color='m';

gray_dark=[150,150,150]/256;
gray_mid=[220,220,220]/256;

plot_start=0; % PLOT STARTING POINT IN RED
disk_color=gray_mid; % grey
circle_color=gray_dark; % grey
circles_size=0.35;

% PLOT DISKS
for k=1:length(rs)
    center=centers(k,:);
    r=rs(k);
    theta=linspace(0,2*pi,1000);
    rr=linspace(0,r,200);
    [TH,R]=meshgrid(theta,rr);
    TH=TH(:); R=R(:);
    X=center(1)+R.*cos(TH); Y=center(2)+R.*sin(TH);
    plot(X,Y,'o','MarkerEdgeColor',disk_color,...
                       'MarkerFaceColor',disk_color,...
                       'MarkerSize',2)
    hold on;
end

% PLOT CIRCLES
for k=1:length(rs)
    center=centers(k,:);
    r=rs(k);
    theta=linspace(0,2*pi,1000);
    TH=TH(:); R=R(:);
    X=center(1)+r*cos(TH); Y=center(2)+r*sin(TH);
    plot(X,Y,'-','MarkerEdgeColor',circle_color,...
                       'MarkerFaceColor',circle_color,...
                       'MarkerSize',circles_size)
    hold on;
end


axis off;
axis equal;

M=size(rs,1);

% plotting sequences.
T=active_arcs;

% arc_sequence,disk_sequence,arcs_sizes
% hold on;
for ii=1:length(arcs_sizes)

    init_ii=sum(arcs_sizes(1:ii-1))+1;
    end_ii=sum(arcs_sizes(1:ii));

    for jj=init_ii:end_ii
        th=linspace(0,2*pi,100);
        center=centers(disk_sequence(jj),:);
        r=rs(disk_sequence(jj));
        angs=T(jj,:);
        angsv=angs(1):(angs(2)-angs(1))/100:angs(2);
        angsv=angsv';
        pts=[center(1)+r*cos(angsv) center(2)+r*sin(angsv)];
         plot(pts(:,1),pts(:,2),'k-','LineWidth',2,...
            'MarkerEdgeColor','w',...
            'MarkerFaceColor','g',...
            'MarkerSize',1);

        if plot_start & ii == 1 & jj == init_ii
                    plot(pts(1,1),pts(1,2),'k.','LineWidth',2,...
            'MarkerEdgeColor','r',...
            'MarkerFaceColor','r',...
            'MarkerSize',40);
        end

        if add_text
            pos=max([1 floor(size(pts,1)/2)]);
            strL=strcat('\Gamma_{',num2str(ii),',',num2str(jj),'}');
            text(pts(pos,1)*1.05,pts(pos,2)*1.05,strL,'FontSize', 18,...
                'Color',text_color);
        end

    end
end




% PLOT POINTSET 1
if isempty(xyw) == 0
    plot(xyw(:,1),xyw(:,2),'bo',...
        'MarkerEdgeColor','b','MarkerFaceColor','b',...
        'MarkerSize',1);
end

% PLOT POINTSET 2
if isempty(xywc) == 0
    plot(xywc(:,1),xywc(:,2),'ro',...
        'MarkerEdgeColor','r','MarkerFaceColor','r',...
        'MarkerSize',4);
end

hold off




