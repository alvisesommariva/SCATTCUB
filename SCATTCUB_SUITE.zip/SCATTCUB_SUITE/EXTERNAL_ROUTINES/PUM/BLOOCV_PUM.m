
function [Pf,dsites,rhs,epoints] = BLOOCV_PUM(epoints,dsites,rhs,RBF_type)

%-------------------------------------------------------------------------%
%         This software is licensed by Creative Commons BY-NC-SA:         %
%      http://creativecommons.org/licenses/by-nc-sa/3.0/it/legalcode      %
%-------------------------------------------------------------------------%
%
% File: BLOOCV_PUM(M,dsites,neval,npu,rbf,wf,f,rhs,r_min,h,P1,ep);
%
% Goal: script that performs partition of unity with variable patches
%       and shape parameters
%
% Inputs:  
%          epoints:      the evaluation points
%          dsites:       NXM matrix representing a set of N data sites
%          rhs:          the function values
%
% Outputs: dsites:       NXM matrix representing a set of N data sites
%          rhs:          the function values
%          epoints:      the evaluation points
%          Pf:           the interpolant computed at the evaluation points
%
% Calls on: IntegerBased_MD_Structure, IntegerBased_MD_Neighbourhood,
%           IntegerBased_MD_RangeSearch, IntegerBased_MD_ContainingQuery, 
%           DistanceMatrix, MakeSDGrid.
%
% Remark:   DistanceMatrix, MakeSDGrid come from the book:
%           [G. E. Fasshauer, Meshfree approximation methods with Matlab, 
%           World Scientific, Singapore, 2007]. 
%
%--------------------------------------------------------------------------
% NOTE:
% This version works with general target points "epoints", over general 
% domains. 
%--------------------------------------------------------------------------
% LAST UPDATE: June 10, 2023.
%--------------------------------------------------------------------------

% .......................... troubleshooting ..............................

% If "epoints" is not declaired we create neval^M equally spaced evaluation
% points.

if nargin < 3, epoints = MakeSDGrid(M,neval); end





% ...................... special PUM settings .............................

N=size(dsites,1); M=size(dsites,2);

% neval = 40;                             % parameter for evaluation points
npu = floor(((N)./(4))^(1/2));            % parameter for PU centres

%rbf = @(ep, r) exp(-(ep*r).^2);           % local kernel type

% 1: phi=@(r) (1+r.*r).^(1/2);             % Multiquadric
% 2: phi=@(r) exp(-r.*r);                  % Gaussian
% 3: phi=@(r) (1+r.*r).^(-1/2);            % Inverse Multiquadric
% 4: phi=@(r) (1+4*r).*(max(0,(1-r))).^4;  % Wendland 2
% 5: phi=@(r) r.*r.*log(r+eps*(1-sign(r))); % TPS
% 6: phi=@(r) r.^3;                        % polyharmonic spline
% 7: phi=@(r) r.^5;                        % polyharmonic spline
% 8: phi=@(r) r.^7;                        % polyharmonic spline
% 9: phi=@(r) (max(0,(1-r))).^2;             % Wendland W0
% 10: phi=@(r) (35*r.^2+18*r+3).*(max(0,(1-r))).^6;         % Wendland W4
% 11: phi=@(r) (32*r.^3+25*r.^2+8*r+1).*(max(0,(1-r))).^8;  % Wendland W6
% 12: phi=@(r) (sqrt(2)/(3*sqrt(pi))*(3*r^2*log(r/(1+sqrt(1-r.^2)))+...
%            (2*r^2+1).*sqrt(1-r^2)))*max(0,(1-r));  % Missing Wendland
% 13 phi=@(r) exp(-r);                     % Matern beta_1=3/2.
% 14 phi=@(r) (1+r).*exp(-r);              % Matern beta_2=5/2.
% 15: phi=@(r) (max(0,(1-r)))^10*(429*r^4 + 450*r^3 + 210*r^2 + 50*r + 5)
%

if nargin < 4, phi =  RBF (10); else, phi=RBF(RBF_type); end
rbf=@(ep,r) phi(ep*r);
wf = @(ep,r) (max(1-(ep*r),0).^4).*(4*(ep*r)+1); % define weight function

% choose "r_min" 
% 1. small for gaussian
% 2. medium (say double of the gaussian) for W4

r_min = 20;                               % minimum cardinality of patches
h = 2;                                    % upper bound for the radius
P1 = 4;                                   % number of testing radii
ep = linspace(0.5,10,15);                 % vector of shape parameters





% ........................... main code below .............................

% Create npu^M equally spaced PU centres
puctrs = MakeSDGrid(M,npu);
puradius = 1./npu;  % Define the initial PU radius
wep = 1./puradius;  % Parameter for weight function
npu_M = size(puctrs,1); neval_M = size(epoints,1); % Initialize;
rbfctrs = dsites; % Define the RBF centres
Pf = zeros(neval_M,1);  % Initialize
% Compute Shepard evaluation matrix
DM_eval = DistanceMatrix(epoints,puctrs);
SEM = wf(wep,DM_eval);
SEM = spdiags(1./(SEM*ones(npu_M,1)),0,neval_M,neval_M)*SEM;
% KDTreeSearcher object for data sites and evaluation points
T = KDTreeSearcher(dsites);
V = KDTreeSearcher(epoints);
for j = 1:npu_M
    puradius = 1/npu; old_puradius = puradius; % Initialize
    % Find data sites located in the j-th subdomain
    idx = rangesearch(T,puctrs(j,:),puradius);
    % Find a range for the PU radius
    if (length(idx{1}) < r_min)
        while (length(idx{1}) < r_min)
            puradius = puradius + 1/8*old_puradius;
            % Find data sites located in the j-th subdomain
            idx = rangesearch(T,puctrs(j,:),puradius);
        end
    end
    % The BLOOCV scheme
    E = []; % Initialize
    for P = 1:length(ep)
        puradius1 = linspace(puradius,h*puradius,P1);
        for Q = 1:length(puradius1)
            % Find data sites located in the j-th subdomain
            idx = rangesearch(T,puctrs(j,:),puradius1(Q));
            % Build local interpolation matrix for the j-th subdomain
            DM_data = DistanceMatrix(dsites(idx{1},:),rbfctrs(idx{1},:));
            % Perform BLOOCV scheme
            Aj = rbf(ep(P),DM_data);
            invAj = inv(Aj);
            % Estimate the error
            e = (invAj*rhs(idx{1}))./diag(invAj);
            E(P,Q) = norm(e(:),inf);
        end
    end
    % Select the radius and the shape parameter
    [e1 idx_e1] = min(E); [e2 idx_e2] = min(e1); 
    ep1 = ep(idx_e1(idx_e2)); puradius2 = puradius1(idx_e2);
    % Find the points located in the j-th subdomain
    idx = rangesearch(T,puctrs(j,:),puradius2);
    % Compute the distance matrix
    DM_data = DistanceMatrix(dsites(idx{1},:),rbfctrs(idx{1},:));
    % Compute the interpolation matrix
    IM = rbf(ep1,DM_data);
    % Find the evaluation points located in the j-th subdomain
    eidx = rangesearch(V,puctrs(j,:),puradius2);
    if  (~isempty(eidx{1}))
        % Compute local evaluation matrix and the local RBF interpolant
        DM_eval = DistanceMatrix(epoints(eidx{1},:),rbfctrs(idx{1},:));
        EM = rbf(ep1,DM_eval); localfit = EM * (IM\rhs(idx{1}));
        % Accumulate global fit
        Pf(eidx{1}) = Pf(eidx{1}) + localfit.*SEM(eidx{1},j);
    end
end

%-------------------------------------------------------------------------%
% DM = DistanceMatrix(dsites,ctrs)
% Forms the distance matrix of two sets of points in R^s,
% i.e., DM(i,j) = || datasite_i - center_j ||_2.
% Input
%   dsites: Mxs matrix representing a set of M data sites in R^s
%              (i.e., each row contains one s-dimensional point)
%   ctrs:   Nxs matrix representing a set of N centers in R^s
%              (one center per row)
% Output
%   DM:     MxN matrix whose i,j position contains the Euclidean
%              distance between the i-th data site and j-th center
%-------------------------------------------------------------------------%
function DM = DistanceMatrix(dsites,ctrs)
  [M,s] = size(dsites); [N,s] = size(ctrs);
  DM = zeros(M,N);
  % Accumulate sum of squares of coordinate differences
  % The ndgrid command produces two MxN matrices:
  %   dr, consisting of N identical columns (each containing
  %       the d-th coordinate of the M data sites)
  %   cc, consisting of M identical rows (each containing
  %       the d-th coordinate of the N centers)
  for d=1:s
     [dr,cc] = ndgrid(dsites(:,d),ctrs(:,d));
     DM = DM + (dr-cc).^2;
  end
  DM = sqrt(DM);







  
%-------------------------------------------------------------------------%
% gridpoints = MakeSDGrid(s,neval)
% Produces matrix of equally spaced points in s-dimensional unit cube
% (one point per row)
% Input
%   s:     space dimension
%   neval: number of points in each coordinate direction
% Output
%   gridpoints: neval^s-by-s matrix (one point per row,
%               d-th column contains d-th coordinate of point)
%-------------------------------------------------------------------------%
function gridpoints = MakeSDGrid(s,neval)
if (s==1)
    gridpoints = linspace(0,1,neval)';
    return;
end
% Mimic this statement for general s:
% [x1, x2] = ndgrid(linspace(0,1,neval));
outputarg = 'x1';
for d = 2:s
    outputarg = strcat(outputarg,',x',int2str(d));
end
makegrid = strcat('[',outputarg,'] = ndgrid(linspace(0,1,neval));');
eval(makegrid);
% Mimic this statement for general s:
% gridpoints = [x1(:) x2(:)];
gridpoints = zeros(neval^s,s);
for d = 1:s
    matrices = strcat('gridpoints(:,d) = x',int2str(d),'(:);');
    eval(matrices);
end
