%-------------------------------------------------------------------------%
%         This software is licensed by Creative Commons BY-NC-SA:         %
%      http://creativecommons.org/licenses/by-nc-sa/3.0/it/legalcode      %
%-------------------------------------------------------------------------%
%
% File: BLOOCV_PUM(M,dsites,epoints,neval,npu,rbf,wf,f,rhs,r_min,h,P1,ep);
%
% Goal: script that performs partition of unity with variable patches
%       and shape parameters
%
% Inputs:  M:            space dimension
%          dsites:       NXM matrix representing a set of N data sites
%          epoints:      the evaluation points
%          neval:        number of evaluation points in one direction
%          npu:          number of PU subdomains in one direction
%          rbf:          radial basis function
%          wf:           weight function
%          f:            the test function
%          rhs:          the function values
%          r_min:        minimum number of points in each PU subdomain
%          h:            upper bound for the radius
%          P1:           parameter for the partition of the PU radius
%          ep:           the partition for the shape parameter
%
% Outputs: dsites:       NXM matrix representing a set of N data sites
%          rhs:          the function values
%          epoints:      the evaluation points
%          Pf:           the interpolant computed at the evaluation points
%
% Calls on: IntegerBased_MD_Structure, IntegerBased_MD_Neighbourhood,
%           IntegerBased_MD_RangeSearch, IntegerBased_MD_ContainingQuery,
%           DistanceMatrix, MakeSDGrid.
%
% Remark:   DistanceMatrix, MakeSDGrid come from the book:
%           [G. E. Fasshauer, Meshfree approximation methods with Matlab,
%           World Scientific, Singapore, 2007].
%
%-------------------------------------------------------------------------%

function [dsites,rhs,epoints,Pf] = BLOOCV_PUM(M,dsites,epoints,neval,...
    npu,rbf,wf,f,rhs,r_min,h,P1,ep)

% points in which PUM will evaluate
if nargin < 3, epoints = []; end

% parameter for evaluation points
if nargin < 4, neval = 40; end
if isempty(neval), neval = 40; end

% parameter for PU centres
N=size(dsites,1);
if nargin < 5, npu = floor(((N)./(4))^(1/2)); end
if isempty(npu), npu = floor(((N)./(4))^(1/2)); end

% local kernel type
if nargin < 6, rbf = @(ep, r) exp(-(ep*r).^2); end
if isempty(rbf), rbf = @(ep, r) exp(-(ep*r).^2); end

% define weight function
if nargin < 7, wf = @(ep,r) (max(1-(ep*r),0).^4).*(4*(ep*r)+1); end
if isempty(wf), wf = @(ep,r) (max(1-(ep*r),0).^4).*(4*(ep*r)+1); end

% define the test function
if nargin < 8, f = @(x) zeros(size(x,1),1); end
if isempty(f), f = @(x) zeros(size(x,1),1); end

% the function values

if nargin < 9, rhs = f(dsites); end
if isempty(rhs), rhs = f(dsites); end

% minimum cardinality of patches
if nargin < 10, r_min = 12; end
if isempty(r_min), r_min = 12; end

% upper bound for the radius
if nargin < 11, h = 2; end
if isempty(h), h = 2; end

% number of testing radii
if nargin < 12, P1 = 4; end
if isempty(P1), P1 = 4; end

% vector of shape parameters
if nargin < 13, ep = linspace(0.5,10,15); end
if isempty(ep), ep = linspace(0.5,10,15); end



% Create npu^M equally spaced PU centres
puctrs = MakeSDGrid(M,npu);
% Create neval^M equally spaced evaluation points
if isempty(epoints)
    epoints = MakeSDGrid(M,neval);
end
puradius = 1./npu;  % Define the initial PU radius
wep = 1./puradius;  % Parameter for weight function
npu_M = size(puctrs,1); neval_M = size(epoints,1); % Initialize;
rbfctrs = dsites; % Define the RBF centres
Pf = zeros(neval_M,1);  % Initialize
% Compute Shepard evaluation matrix
DM_eval = DistanceMatrix(epoints,puctrs);
SEM = wf(wep,DM_eval);
SEM = spdiags(1./(SEM*ones(npu_M,1)),0,neval_M,neval_M)*SEM;
% Parameter for integer-based partitioning structure
q = 1./puradius;
% Build the partitioning structure for data sites and evaluation points
idx_ds = IntegerBased_MD_Structure(dsites,q,puradius,M);
idx_ep = IntegerBased_MD_Structure(epoints,q,puradius,M);
for j = 1:npu_M
    puradius = 1/npu; old_puradius = puradius; % Initialize
    % Find the block containing the j-th subdomain centre
    index1 = IntegerBased_MD_ContainingQuery(puctrs(j,:),q,puradius,M);
    % Find data sites located in the j-th subdomain
    [dxx dx] = IntegerBased_MD_Neighbourhood(dsites,idx_ds,index1,q,M,1);
    idx = IntegerBased_MD_RangeSearch(puctrs(j,:),puradius,dxx,dx);
    % Find a range for the PU radius
    if (length(idx) < r_min)
        t = 1; % Initialize
        while (length(idx) < r_min)
            puradius = puradius + 1/8*old_puradius;
            if puradius > t*old_puradius
                t = t + 1;
                [dxx dx] = IntegerBased_MD_Neighbourhood(dsites,idx_ds,...
                    index1,q,M,t);
            end
            % Find data sites located in the j-th subdomain
            idx = IntegerBased_MD_RangeSearch(puctrs(j,:),puradius,dxx,dx);
        end
    end
    % The BLOOCV scheme
    E = []; % Initialize
    for P = 1:length(ep)
        puradius1 = linspace(puradius,h*puradius,P1);
        for Q = 1:length(puradius1)
            n = 1;
            while n < 99999
                if puradius1(Q) > n*old_puradius
                    n = n + 1;
                else
                    t = n;
                    [dxx dx] = IntegerBased_MD_Neighbourhood(dsites,...
                        idx_ds,index1,q,M,t);
                    break
                end
            end
            % Find data sites located in the j-th subdomain
            idx = IntegerBased_MD_RangeSearch(puctrs(j,:),puradius1(Q),...
                dxx,dx);
            % Build local interpolation matrix for the j-th subdomain
            DM_data = DistanceMatrix(dsites(idx,:),rbfctrs(idx,:));
            % Perform BLOOCV scheme
            Aj = rbf(ep(P),DM_data);
            invAj = inv(Aj);
            % Estimate the error
            e = (invAj*rhs(idx))./diag(invAj);
            E(P,Q) = norm(e(:),inf);
        end
    end
    % Select the radius and the shape parameter
    [e1 idx_e1] = min(E); [e2 idx_e2] = min(e1);
    ep1 = ep(idx_e1(idx_e2)); puradius2 = puradius1(idx_e2);
    % Find the points lying in the j-th patch of radius puradius2
    n = 1;
    while n < 99999
        if puradius2 > n*old_puradius
            n = n + 1;
        else
            t = n;
            [dxx dx] = IntegerBased_MD_Neighbourhood(dsites,idx_ds,...
                index1,q,M,t);
            break
        end
    end
    [edxx edx] = IntegerBased_MD_Neighbourhood(epoints,idx_ep,index1,q,...
        M,t);
    % Find the points located in the j-th subdomain
    idx = IntegerBased_MD_RangeSearch(puctrs(j,:),puradius2,dxx,dx);
    % Compute the distance matrix
    DM_data = DistanceMatrix(dsites(idx,:),rbfctrs(idx,:));
    % Compute the interpolation matrix
    IM = rbf(ep1,DM_data);
    % Find the evaluation points located in the j-th subdomain
    eidx = IntegerBased_MD_RangeSearch(puctrs(j,:),puradius2,edxx,edx);
    if  (~isempty(eidx))
        % Compute local evaluation matrix and the local RBF interpolant
        DM_eval = DistanceMatrix(epoints(eidx,:),rbfctrs(idx,:));
        EM = rbf(ep1,DM_eval); localfit = EM * (IM\rhs(idx));
        % Accumulate global fit
        Pf(eidx) = Pf(eidx) + localfit.*SEM(eidx,j);
    end
end
% Compute exact solution
exact = f(epoints(:,1),epoints(:,2));
% Compute errors on evaluation grid
maxerr = norm(Pf - exact,inf);
rms_err = norm(Pf - exact)/sqrt(neval_M);
fprintf('RMS error:       %e\n', rms_err);
fprintf('Maximum error:   %e\n', maxerr);

%-------------------------------------------------------------------------%
%         This software is licensed by Creative Commons BY-NC-SA:         %
%      http://creativecommons.org/licenses/by-nc-sa/3.0/it/legalcode      %
%-------------------------------------------------------------------------%
%
% File: IntegerBased_MD_Structure(dsites,q,puradius,M)
%
% Goal: find the data sites located in each of the q^M blocks
%
% Inputs: dsites:     NXM matrix representing a set of N data sites
%         q:          number of blocks in one direction
%         puradius:   radius of PU subdomains
%         M:          space dimension
%
% Outputs: idx_dsites_k: multiarray containing the indices of the data
%                        points located in k-th block
%
%-------------------------------------------------------------------------%
function [idx_dsites_k] = IntegerBased_MD_Structure(dsites,q,puradius,M)
N = size(dsites,1); idx_dsites_k = cell(q^M,1); k = 1:M-1;
for i = 1:N
    idx = ceil(dsites(i,:)./puradius);
    idx(idx == 0) = 1;
    index = sum((idx(k)-1).*q.^(M-k)) + idx(end);
    idx_dsites_k{index} = [idx_dsites_k{index}; i];
end

%-------------------------------------------------------------------------%
%         This software is licensed by Creative Commons BY-NC-SA:         %
%      http://creativecommons.org/licenses/by-nc-sa/3.0/it/legalcode      %
%-------------------------------------------------------------------------%
%
% File: IntegerBased_MD_RangeSearch(puctr,puradius,dsites,index)
%
% Goal: find the data sites located in a given subdomain and the distances
%       between the subdomain centre and data sites
%
% Inputs: puctr:     subdomain centre
%         puradius:  radius of PU subdomains
%         dsites:    NXM matrix representing a set of N data sites
%         index:     vector containing the indices of the data points
%                    located in the k-th block (the block containing the
%                    subdomain centre) and in the neighbouring blocks
%
% Outputs: idx:  vector containing the indices of the data points located
%                in a given PU subdomain
%          dist: vector containing the distances between the data sites
%                and the subdomain centre
%
%-------------------------------------------------------------------------%
function [idx, dist] = IntegerBased_MD_RangeSearch(puctr,puradius,...
    dsites,index)
N = size(dsites,1); dist = []; idx = []; % Initialize
% Compute distances between the data sites and the centre
for i = 1:N
    dist1(i) = norm(puctr - dsites(i,:));
end
% Use a sort procedure to order distances
if N > 0
    [sort_dist,IX] = sort(dist1);
    N1 = size(sort_dist,2); j1 = 1; j2 = 1; %Initialize
    % Find the data sites located in the given subdomain
    if nargin == 3
        idx = IX; dist = dist1;
    else
        while (j2 <= N1) && (sort_dist(j2) <= puradius)
            idx(j1) = index(IX(j2)); dist(j1) = dist1(IX(j2));
            j1 = j1 + 1; j2 = j2 + 1;
        end
    end
end

%-------------------------------------------------------------------------%
%         This software is licensed by Creative Commons BY-NC-SA:         %
%      http://creativecommons.org/licenses/by-nc-sa/3.0/it/legalcode      %
%-------------------------------------------------------------------------%
%
% File: IntegerBased_MD_ContainingQuery(puctr,q,puradius,M)
%
% Goal: script that given a subdomain centre returns the index of
%       the square block containing the subdomain centre
%
% Inputs: puctr:       subdomain centre
%         q:           number of blocks in one direction
%         puradius:    radius of the PU subdomains
%         M:           space dimension
%
% Outputs: index: the index of the block containing the subdomain
%                 centre
%
%-------------------------------------------------------------------------%
function [index] = IntegerBased_MD_ContainingQuery(puctr,q,puradius,M)
idx = ceil(puctr./puradius); k = 1:M-1;
idx(idx == 0) = 1;
index = sum((idx(k)-1).*q.^(M-k)) + idx(end);

%-------------------------------------------------------------------------%
%         This software is licensed by Creative Commons BY-NC-SA:         %
%      http://creativecommons.org/licenses/by-nc-sa/3.0/it/legalcode      %
%-------------------------------------------------------------------------%
%
% File: IntegerBased_MD_Neighbourhood(dsites,idx_ds,index1,q,M,t)
%
% Goal: script that founds the neighbouring blocks
%
% Inputs:  dsites:       NXM matrix representing a set of N data sites
%          idx_ds:       the integer-based data structure
%          index1:       indices of points lying in the k-th block
%          q:            number of blocks in one direction
%          M:            space dimension
%          t:            it is related to the number of neighbouring
%                        blocks, the procedure searches in the k-th block
%                        and in its (3 + 2^t)^M - 1 neighboring blocks
%
% Outputs:  dxx:         points lying in the k-th neighbourhood
%           dx:          indices of points lying in the k-th neighbourhood
%
%-------------------------------------------------------------------------%
function [dxx dx] = IntegerBased_MD_Neighbourhood(dsites,idx_ds,index1,...
    q,M,t)
neigh = []; k = M-1; index = index1; k1 = 1:t; % Initialize
% Find neighbouring blocks
while k  > 0
    neigh = [index1+k1.*q.^k,index1-k1.*q.^k];
    if k - 1 > 0
        neigh = [neigh,neigh+q.^(k-1),neigh-q.^(k-1)];
    end
    k = k - 1;
end
k2 = 1:t; k3 = k2;
for i = 1:length(neigh)
    neighplus(k2) = neigh(i) + k3;
    neighminus(k2) = neigh(i) - k3;
    k2 = k2 + t;
end
neigh = [neigh,index1+k1,index1-k1,neighplus,neighminus];
% Reduce the number of neighbouring blocks for border blocks
j = find(neigh > 0 & neigh <= q^M);
index = [index; neigh(j)'];
dxx = []; dx = [];
for p = 1:length(index)
    dxx = [dxx;dsites(idx_ds{index(p)},:)];
    dx = [dx;idx_ds{index(p)}];
end

%-------------------------------------------------------------------------%
% DM = DistanceMatrix(dsites,ctrs)
% Forms the distance matrix of two sets of points in R^s,
% i.e., DM(i,j) = || datasite_i - center_j ||_2.
% Input
%   dsites: Mxs matrix representing a set of M data sites in R^s
%              (i.e., each row contains one s-dimensional point)
%   ctrs:   Nxs matrix representing a set of N centers in R^s
%              (one center per row)
% Output
%   DM:     MxN matrix whose i,j position contains the Euclidean
%              distance between the i-th data site and j-th center
%-------------------------------------------------------------------------%
function DM = DistanceMatrix(dsites,ctrs)
[M,s] = size(dsites); [N,s] = size(ctrs);
DM = zeros(M,N);
% Accumulate sum of squares of coordinate differences
% The ndgrid command produces two MxN matrices:
%   dr, consisting of N identical columns (each containing
%       the d-th coordinate of the M data sites)
%   cc, consisting of M identical rows (each containing
%       the d-th coordinate of the N centers)
for d=1:s
    [dr,cc] = ndgrid(dsites(:,d),ctrs(:,d));
    DM = DM + (dr-cc).^2;
end
DM = sqrt(DM);

%-------------------------------------------------------------------------%
% gridpoints = MakeSDGrid(s,neval)
% Produces matrix of equally spaced points in s-dimensional unit cube
% (one point per row)
% Input
%   s:     space dimension
%   neval: number of points in each coordinate direction
% Output
%   gridpoints: neval^s-by-s matrix (one point per row,
%               d-th column contains d-th coordinate of point)
%-------------------------------------------------------------------------%
function gridpoints = MakeSDGrid(s,neval)
if (s==1)
    gridpoints = linspace(0,1,neval)';
    return;
end
% Mimic this statement for general s:
% [x1, x2] = ndgrid(linspace(0,1,neval));
outputarg = 'x1';
for d = 2:s
    outputarg = strcat(outputarg,',x',int2str(d));
end
makegrid = strcat('[',outputarg,'] = ndgrid(linspace(0,1,neval));');
eval(makegrid);
% Mimic this statement for general s:
% gridpoints = [x1(:) x2(:)];
gridpoints = zeros(neval^s,s);
for d = 1:s
    matrices = strcat('gridpoints(:,d) = x',int2str(d),'(:);');
    eval(matrices);
end