%-------------------------------------------------------------------------%
%         This software is licensed by Creative Commons BY-NC-SA:         %
%      http://creativecommons.org/licenses/by-nc-sa/3.0/it/legalcode      %
%-------------------------------------------------------------------------%
close all
clear all
warning off
disp('-------------------------------------------------------')

N = 289;                                % number of scattered data
p = haltonset(2,'Skip',1);
dsites = net(p,N);                      % the type of data
% epoints=[];                             % points in which PUM will evaluate

P=sobolset(2,'Skip',1);
epoints = net(P,N);

neval = 40;                             % parameter for evaluation points
npu = floor(((N)./(4))^(1/2));          % parameter for PU centres
rbf = @(ep, r) exp(-(ep*r).^2);         % local kernel type
wf = @(ep,r) (max(1-(ep*r),0).^4).* ...
    (4*(ep*r)+1);                       % define weight function
f = @(x) (x(:,1)+x(:,2)-1).^9;          % define the test function
rhs = f(dsites);                        % the function values
r_min = 12;                             % minimum cardinality of patches
h = 2;                                  % upper bound for the radius
P1 = 4;                                 % number of testing radii
ep = linspace(0.5,10,15);               % vector of shape parameters

M=2;

[dsites,rhs,epoints,Pf] =BLOOCV_PUM(M,dsites,epoints,neval,...
    npu,rbf,wf,f,rhs,r_min,h,P1,ep);

xS = dsites; 
fxS= rhs;
xT = epoints;
y = Pf;
