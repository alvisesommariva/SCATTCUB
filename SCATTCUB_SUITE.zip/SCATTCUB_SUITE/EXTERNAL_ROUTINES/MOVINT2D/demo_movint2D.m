
function demo_movint2D

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Demo on using "MovInt2D" for the pointwise evaluation by adaptive moving 
% polynomial interpolation on bivariate scattered data.
%--------------------------------------------------------------------------

clear all; 

% ............................. settings  ................................. 

% The data.txt file contains a Nx3 matrix (x_i,y_i,f_i), i=1,...,N for the
% Franke function sampled at 1000 Halton points.
Data=dlmread('data.txt');
xS=Data(:,1:2); fxS=Data(:,3); N=size(xS,1);

% The evaluation point
xT=[0.5,0.5]; 



% ............................. main code below  ..........................

% Compute the approximation of the function value
[val,error]=movint2D(xT,xS,fxS);

% Approximate function value
approx_value=val(end); 

% Error estimate
est_min=error(end); 

% Statistics
fprintf('\n \t Approximate value: %1.15e',approx_value);
fprintf('\n \t Error estimate   : %1.3e \n \n',est_min);

