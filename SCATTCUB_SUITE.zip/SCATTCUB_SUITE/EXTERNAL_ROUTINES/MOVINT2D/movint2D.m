
function [fval,e]=movint2D(xT,xS,fxS,d0,dmax,delta,hmax,sigma)

%% Computing the approximation of the function values by using scattered
%% data at the point "xT" as much accurate as possible.

% INPUT:
% xT: evaluation point
% xS: scattered sample points (matrix N x 2)
% fxS: function values at X
% d0: initial degree
% dmax: maximum degree
% delta: error control degree step
% hmax: maximum allowed radius <1
% sigma: deg step

% OUTPUT:
% fval: approximation of the function values at "xT"
% e: error estimate




% Setting defaults

if nargin < 4, d0=5; end
if isempty(d0), d0=5; end

if nargin < 5, dmax=floor((-3+sqrt(1+8*length(fxS)))/2); end
if isempty(dmax), dmax=floor((-3+sqrt(1+8*length(fxS)))/2); end

if nargin < 6, delta=2; end
if isempty(delta), delta=2; end

if nargin < 7, hmax=0.8; end
if isempty(hmax), hmax=0.8; end

if nargin < 8, sigma=2; end
if isempty(sigma), sigma=2; end


[fval,e]=movint2D_core(xT,xS,fxS,d0,dmax,delta,hmax,sigma);

% for k=d0-1:-1:1
%     if isempty(fval)
%          warning('movint2D: lower quality')
%         delta=1; sigma=1; hmax=5*hmax;
%         [fval,e]=movint2D_core(xT,xS,fxS,k,dmax,delta,hmax,sigma);
%     end
% end





function [fval,e]=movint2D_core(xT,xS,fxS,d0,dmax,delta,hmax,sigma)

%% Computing the approximation of the function values by using scattered
%% data at the point "xT" as much accurate as possible.

% INPUT:
% xT: evaluation point
% xS: scattered sample points (matrix N x 2)
% fxS: function values at X
% d0: initial degree
% dmax: maximum degree
% delta: error control degree step
% hmax: maximum allowed radius <1
% sigma: deg step

% OUTPUT:
% fval: approximation of the function values at "xT"
% e: error estimate




% Setting defaults

if nargin < 4, d0=5; end
if isempty(d0), d0=5; end

if nargin < 5, dmax=floor((-3+sqrt(1+8*length(fxS)))/2); end
if isempty(dmax), dmax=floor((-3+sqrt(1+8*length(fxS)))/2); end

if nargin < 6, delta=2; end
if isempty(delta), delta=2; end

if nargin < 7, hmax=0.8; end
if isempty(hmax), hmax=0.8; end

if nargin < 8, sigma=2; end
if isempty(sigma), sigma=2; end


% ......................... Main code below ...............................

errmin=realmax;

d=d0;
%%%% Ordered distances of the nodes in X from xT
dist2x=xS(:,1)-xT(1);
dist2y=xS(:,2)-xT(2);

dist2=dist2x.^2+dist2y.^2;

OD=sort(dist2);

e=[];
deg=[];
fval=[];

h=0;

powV=pow(d);

while  d<=dmax && h<=hmax
    m_d=(d+1)*(d+2)/2;
    h_d=sqrt(OD(min(m_d+1,end),1)); %% min{h: card(X_h)>=m_d}
    h=max(h,h_d);

    %%% find the minimum radius h_d such that ball $B_h(xT)$ contains at
    %%% least m_d points
    if h<=hmax
        r=0;
        while r<m_d && h<=hmax
            in_B=dist2<=h^2;

            dist2hx=dist2x(in_B==1);
            dist2hy=dist2y(in_B==1);

            V=BivVand([dist2hx./h,dist2hy./h],d,powV);
            r=rank(V);

            if r<m_d
                h=(1+h)/2;
            end
        end
    end

    if h<=hmax
        fh=fxS(in_B==1);
        %% extract m_d approximate Leja pts in X_h
        Ih=leja(V);
        fh_Leja=fh(Ih);
        %% compute the Vandermonde matrix of degree d
        Vh=V(Ih,:);

        %% compute the approximate coefficients for degree d
        eval_approx=Vh\fh_Leja;
        evalu_d=eval_approx(1);


        %% compute the approximate coefficients for degree d-delta
        m_d_minus_delta=(d-delta+1)*(d-delta+2)/2;
        eval_approx=Vh(1:m_d_minus_delta,1:m_d_minus_delta)\fh_Leja(1:m_d_minus_delta);
        evalu_d_delta=eval_approx(1);

        %% compute the error estimate
        err=abs(evalu_d-evalu_d_delta);

        if err<errmin
            errmin=err;
            e=[e;errmin];
            deg=[deg;d];
            fval=[fval;evalu_d_delta];
            hmin=h_d;
            dmin=d-delta;
        end

        d=d+sigma;
        powV=pow(d);

    end
end









%% Computing the Bivariate Vandermonde Matrix

% INPUT:
% X: 2-column array of "m" sample points (matrix m x 2).
% d: degree of the Vandermonde matrix
% pow: powers of the bivariate monomial basis (matrix (d+1)*(d+2)/2 x 2)


% OUTPUT:
% A: Bivariate Vandermonde matrix of total degree "deg"

function A=BivVand(X,d,pow)

V1=ShortVander(d+1,X(:,1));
V2=ShortVander(d+1,X(:,2));

V1=V1(:,end:-1:1);
V2=V2(:,end:-1:1);
A=V1(:,pow(:,1)+1).*V2(:,pow(:,2)+1);









% Computing the powers of the bivariate monomial basis of total degree "d"
% by using the routine mono_next_grlex.m

% INPUT:
% d: total degree of the desired monomial powers


% OUTPUT:
% powV: matrix of the bivariate monomial basis of total degree "d"

%%%% EXAMPLE %%%%
% >> powV=pow(3)
% powV=[  0     0
%      0     1
%      1     0
%      0     2
%      1     1
%      2     0
%      0     3
%      1     2
%      2     1
%      3     0]


function powV=pow(d)
N=(d+1)*(d+2)/2;
powV=zeros(N,2);
powV(1,:)=[0,0];
for i=2:N
    powV(i,:) = mono_next_grlex(2,powV(i-1,:));
end










function [index] = leja(V)

% computes approximate Leja interpolation points for degree

% input
% V: Vandermonde matrix at points X for degree n.

% output
% I: 2- or 3-column array of interpolation points coordinates

N=length(V(1,:));
[Q,~]=qr(V,0);

[~,~,perm]=lu(Q,'vector');

index=perm(1:N);









%% Computing the first n columns of the Vandermonde Matrix in reverse order.

% INPUT:
% n: maximum power
% v: column vector

%OUTPUT:
% A: first n columns of the Vandermonde matrix

%%%%% EXAMPLE %%%%%
% >> A=ShortVander(3,[1;2;3;4])
%
% >> A =[1     1     1
%      4     2     1
%      9     3     1
%     16     4     1]

function A = ShortVander(n,v)

v = v(:);

if n == 0
    A = reshape(v, n, n);
else
    A = repmat(v, 1, n);
    A(:, n) = 1;
    A = cumprod(A, 2, 'reverse');
end









function x = mono_next_grlex ( m, x )

%*****************************************************************************80
%
%% MONO_NEXT_GRLEX: grlex next monomial.
%
%  Discussion:
%
%    Example:
%
%    M = 3
%
%    #  X(1)  X(2)  X(3)  Degree
%      +------------------------
%    1 |  0     0     0        0
%      |
%    2 |  0     0     1        1
%    3 |  0     1     0        1
%    4 |  1     0     0        1
%      |
%    5 |  0     0     2        2
%    6 |  0     1     1        2
%    7 |  0     2     0        2
%    8 |  1     0     1        2
%    9 |  1     1     0        2
%   10 |  2     0     0        2
%      |
%   11 |  0     0     3        3
%   12 |  0     1     2        3
%   13 |  0     2     1        3
%   14 |  0     3     0        3
%   15 |  1     0     2        3
%   16 |  1     1     1        3
%   17 |  1     2     0        3
%   18 |  2     0     1        3
%   19 |  2     1     0        3
%   20 |  3     0     0        3
%
%    Thanks to Stefan Klus for pointing out a discrepancy in a previous
%    version of this code, 05 February 2015.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    05 February 2015
%
%  Author:
%
%    John Burkardt
%
%  Input:
%
%    integer M, the spatial dimension.
%
%    integer X(M), the current monomial.
%    The first item is X = [ 0, 0, ..., 0, 0 ].
%
%  Output:
%
%    integer X(M), the next monomial.
%

%
%  Ensure that 1 <= M.
%
if ( m < 1 )
    fprintf ( 1, '\n' );
    fprintf ( 1, 'MONO_NEXT_GRLEX - Fatal error!' );
    fprintf ( 1, '  M < 1\n' );
    error ( 'MONO_NEXT_GRLEX - Fatal error!' );
end
%
%  Ensure that 0 <= XC(I).
%
for i = 1 : m
    if ( x(i) < 0 )
        fprintf ( 1, '\n' );
        fprintf ( 1, 'MONO_NEXT_GRLEX - Fatal error!' );
        fprintf ( 1, '  X(I) < 0\n' );
        error ( 'MONO_NEXT_GRLEX - Fatal error!' );
    end
end
%
%  Find I, the index of the rightmost nonzero entry of X.
%
i = 0;
for j = m : -1 : 1
    if ( 0 < x(j) )
        i = j;
        break
    end
end
%
%  set T = X(I)
%  set X(I) to zero,
%  increase X(I-1) by 1,
%  increment X(M) by T-1.
%
if ( i == 0 )
    x(m) = 1;
    return
elseif ( i == 1 )
    t = x(1) + 1;
    im1 = m;
elseif ( 1 < i )
    t = x(i);
    im1 = i - 1;
end

x(i) = 0;
x(im1) = x(im1) + 1;
x(m) = x(m) + t - 1;

return


