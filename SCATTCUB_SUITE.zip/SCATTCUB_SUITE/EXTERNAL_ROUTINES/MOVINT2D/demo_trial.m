%% Demo on using "MovInt2D" for the pointwise evaluator
%% by adaptive moving polynomial Interpolation on bivariate SCattered data 
%% This demo considers 100 sobol points and computes the errors in approximating 
%% the function values through the algorithm MovInt2D at [200,400,600,800,1000,1200,1400,1600] 
%% ordered by distance from the boundary



clear all
clc
close all

format long

%%%% Sobol nodes in the square
L=100;
p=sobolset(2);
Xb=net(p,L);
N=[200,400,600,800,1000,1200,1400,1600];
%%%% Fekete function
f = @(x,y) 0.75*exp(-((9*x-2).^2+(9*y-2).^2)/4) ...
    +0.75*exp(-((9*x+1).^2/49+(9*y+1)/10)) ...
    +0.5*exp(-((9*x-7).^2+(9*y-3).^2)/4) ...
    -0.2*exp(-((9*x-4).^2+(9*y-7).^2));

HS=haltonset(2);

hmax=0.8;

for k=1:8   
    X=net(HS,N(k));
    
    d0=5;
    s=3;
    delta=2; %% The error control degree step
    sigma=2; %% The degree step
    fX=f(X(:,1),X(:,2));
    dmax=floor((-3+sqrt(1+8*N(k)))/2); %% The maximum degree
    
    for i=1:L
        
        %%%% ALGORITHM
        [fval,error]=movint2D(X,fX,Xb(i,:),d0,dmax,delta,hmax,sigma);
        
        error(error==0)=eps;
        %%%%%
        
        %%%% EXACT VALUES
        exact_value=f(Xb(i,1),Xb(i,2));
        
        
        abs_err(i)=abs(fval(end)-exact_value);
        est_err(i)=error(end);
     end
    
    avt=sum(abs_err)/length(abs_err);
    ave=sum(est_err)/length(est_err);
    m=min(min(Xb(:,1),1-Xb(:,1)),min(Xb(:,2),1-Xb(:,2)));
    [u,ind]=sort(m);
    t=abs_err(ind);
    e=est_err(ind);
    figure(k)
    semilogy(u,t,'o',u,ones(1,L)*avt,'-','LineWidth',0.9,'color',[0.4660 0.6740 0.1880]);
    hold on;
    semilogy(u,e,'r*',u,ones(1,L)*ave,'--r','LineWidth',0.9);
    errorbar(u,(t+e)/2,abs(t-e)/2,abs(t-e)/2,'.','MarkerSize',0.9,'LineWidth',0.7,'color',[0, 0.4470, 0.7410]);
     
    
    
end

