
function demo_multinode_operator

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% This demo:
% 1. we compute source points xS and their function evaluation fxS=f(xS);
% 2. we compute target points xT;
% 3. we approximate fxS via Shepard multinode operator;
% 4. we test the errors, providing statistics.
%--------------------------------------------------------------------------
% INPUT
%--------------------------------------------------------------------------
% xS: matrix M x 2 (cart. coordinates source points)
% xT: matrix M x 2 (cart. coordinates target points)
% fxS: matrix M x 1 (function evaluation at source points)
% deg: degree (not mandatory)
% mu : power parameter (not mandatory)
%--------------------------------------------------------------------------
% OUTPUT
%--------------------------------------------------------------------------
% fxT: matrix M x 1 (function approximation at target points)
%--------------------------------------------------------------------------

clear all; close all; warning off;

% ............................ Settings  .................................. 

% The polynomial total degree
deg=4; 

% The number of Interpolation points
N = 1000; 

% The number of evaluation points
n=100; 




% ............................ Main code below  ...........................

% The required number of points
NP=(deg+1)*(deg+2)/2; 

% Powers of the bivariate monomial basis of total degree "deg".
pow_deg=pow(deg); 

% Pointsets
xS = Points('halton',N); % source points
xT = Points('sobol',n);  % target points

% Evaluate test function at source points
f = TestFunc('franke'); 
fxS = f(xS(:,1),xS(:,2));

% Approximation "mo_xT" of "f(xT)", via multinode Shepard operator.
mo_xT=multinode_operator(xT,xS,fxS);

% Exact evaluation of test function at target points
fxT = f(xT(:,1),xT(:,2));

% The maximum error
maxerr=max(max(abs(mo_xT-fxT)));  

% The mean error
meanerr=mean(mean(abs(mo_xT-fxT)));        

% The mean squared error
MSerr=sqrt(mean(mean(abs(mo_xT-fxT).^2))); 

% Statistics
fprintf('\n \t Maximum error  : %1.3e',maxerr);
fprintf('\n \t Mean error     : %1.3e',meanerr);
fprintf('\n \t Mean sq. error : %1.3e \n \n',MSerr);








function powV=pow(d)

% Computing the powers of the bivariate monomial basis of total degree "d"
% by using the routine mono_next_grlex.m

% INPUT:
% d: total degree of the desired monomial powers


% OUTPUT:
% powV: matrix of the bivariate monomial basis of total degree "d" 

%%%% EXAMPLE %%%%
% >> powV=pow(3)
% powV=[  0     0
%      0     1
%      1     0
%      0     2
%      1     1
%      2     0
%      0     3
%      1     2
%      2     1
%      3     0]

N=(d+1)*(d+2)/2;
powV=zeros(N,2);
powV(1,:)=[0,0];
for i=2:N
    powV(i,:) = mono_next_grlex(2,powV(i-1,:));
end









%-------------------------------------------------------------------------%
%
% File:  Points(pointType,n)
%
% Goal:  returns a set of points
%
% Inputs:  pointType:  the type of points
%                  n:  number of points 
%
% Outputs: xn,yn:   x,y components of 2D points
%
% Calls on: haltonseq: by D. Dougherty, from MATLAB Central File Exchange
%
%-------------------------------------------------------------------------%
function x = Points(pointType,n)

switch pointType
    case 'halton'
        p=haltonset(2,'Skip',1); x = net(p,n);
    case 'sobol'
        p=sobolset(2); x=net(p,n);
    case 'rand'
        rand('seed',3); x = rand(n,2); 
    otherwise
        error(['Point type "' pointType '" not available'])
end 









%-------------------------------------------------------------------------%
%
% File:  TestFunc(type)
%
% Goal:  returns function values
%
% Inputs:  type:  type of test function
%
% Outputs:    f:  function values
%
%-------------------------------------------------------------------------%
function f = TestFunc(type)
switch type
    case 'franke'
       f = @(x,y) 0.75*exp(-((9*x-2).^2+(9*y-2).^2)/4) ...
            +0.75*exp(-((9*x+1).^2/49+(9*y+1)/10)) ...
            +0.5*exp(-((9*x-7).^2+(9*y-3).^2)/4) ...
            -0.2*exp(-((9*x-4).^2+(9*y-7).^2));
     % f=@(x,y) 1+x+y+x.^2+x.*y+y.^2;%+x.^3+x.^2.*y+x.*y.^2+y.^3+x.^4+x.^3.*y+x.^2.*y.^2+x.*y.^3+y.^4;
    case 'cliff'
        f = @(x,y) (tanh(9*y-9*x)+1)/9;
    case 'saddle'
        f = @(x,y) (1.25+cos(5.4*y))./(6+6*(3*x-1).^2);
    case 'gentle'
        f = @(x,y) exp((-81/16)*((x-0.5).^2+(y-0.5).^2))/3;
    case 'steep'
        f = @(x,y) exp((-81/4)*((x-0.5).^2+(y-0.5).^2))/3;
    case 'sphere'
        f = @(x,y) sqrt(64-81*((x-0.5).^2+(y-0.5).^2))/9-0.5;
    case 'trigonometric'
        f = @(x,y) 2*cos(10*x).*sin(10*y)+sin(10*y.*x);
    case 'F8'
        f = @(x,y) exp(-(5-10*x).^2/2)+0.75*exp(-(5-10*y).^2/2)...
            +0.75*exp(-(5-10*x).^2/2).*exp(-(5-10*y).^2/2);
    case 'F9'
        f = @(x,y) ((20/3)^3*exp((10-20*x)/3).*exp((10-20*y)/3)).^2.*...
            ((1./(1+exp((10-20*x)/3))).*(1./(1+exp((10-20*y)/3)))).^5.*...
            (exp((10-20*x)/3)-2./(1+exp((10-20*x)/3))).*...
            (exp((10-20*x)/3)-2./(1+exp((10-20*y)/3)));
    case 'F10'
        f = @(x,y) exp(-0.04*sqrt((80*x-40).^2+(90*y-45).^2)).*...
            cos(0.15*sqrt((80*x-40).^2+(90*y-45).^2));
    case 'xy'
        %f = @(x,y) ((2*x-1).*(1-2*y)+1)/2;
        f=@(x,y) x.*y;
    case 'sinxcosy'
        f = @(x,y) sin(2*pi*x).*cos(2*pi*y)/2;
    case '1'
        f=@(x,y) 1+(x+y)+x.^2+y.^2+x.*y+x.^3+x.^2.*y+x.*y.^2+y.^3;
  
end









function [M,MMDO,MMD]=SortPointsMatrix(xn,yn)
%M=Matrix of indices sorted in order of increasing distances
%MMDO=matrix of mutual ordered distances
%MMD=mutual distance matrix
N=length(xn);
MMD=zeros(N,N);%Memory allocation for execution speed
index=1:N;
M=zeros(N,N);%Memory allocation for execution speed
MMDO=M;
for i=1:N
    MMD(i,i+1:N)=sqrt((xn(i)-xn(i+1:N)).^2+(yn(i)-yn(i+1:N)).^2); % Distance matrix
    MMD(:,i)=MMD(i,:);
    Aus=[MMD(i,:);index];
    Aus=sortrows(Aus',1);
    M(i,:)=Aus(:,2)';  %%Matrix of ordered distances
    MMDO(i,:)=Aus(:,1)';
end










%% This function computes the set of tuples using approximate Leja interpolation points
function tps=Tuple_Set_Leja(M,nps,xn,yn,NP,pow)
mx=length(xn);
deg=max(pow(:,1));
aus=1:length(xn);

i=1;
r=1;
tps=zeros(mx,NP);

while i>0 && i<mx
    
    nearest=M(i,1:nps);
    xt=xn(nearest);
    yt=yn(nearest);
    X=[xt,yt];
    
    [~,ind]=fekete(deg,X,2);
    
    index=nearest(ind);
    tps(r,:)=index;
    
      
    aus([i,index(1)])=0;
    v=aus(aus>0);
    i=min(v);
    r=r+1;
end
tps=tps(prod(tps,2)>0,:);









function [I,perms] = fekete(n,X,ptype)

% computes approximate Fekete or Leja interpolation points for degree n
% from the 2d or 3d cloud X

% input
% n: interpolation degree
% X: 2- or 3-column array of cloud points coordinates
% ptype: interpolation points type, 1=Fekete, 2=Leja

% output
% I: 2- or 3-column array of interpolation points coordinates

V=chebvand(n,X);
N=length(V(1,:));
[Q,R]=qr(V,0);

if ptype==1
    w=Q'\ones(N,1);
    ind=find(abs(w)>0);
    I=X(ind,:);
    perms=[];
else
    [L,U,perm]=lu(V,'vector');
    I=X(perm(1:N),:);
    perms=perm(1:N);
end







%% This function computes the Euclidean distances between the points (xn,yn) and (x,y)
function D = DD(xn,yn,x,y)
N = length(xn);
%D = zeros(size(x,1),size(x,2),N);
D=cell(1,N);

for i = 1:N
    D{i} = sqrt((xn(i)-x).^2+(yn(i)-y).^2);  
end






%%  Computes the multinode basis functions
function Wmu=QQtMulti(D,tps,mu)
N1=size(tps,1);
N2=size(tps,2);
Qt=cell(N1);
Den=0;
for i=1:N1
      Qtaus=D{tps(i,1)};
    for j=2:N2
        Qtaus=Qtaus.*D{tps(i,j)};
    end
    Qt{i}=(1./Qtaus).^mu;
    Den=Den+Qt{i}; %% The denominator of the multinode basis functions
end


for i=1:N1
    Wmu{i}=Qt{i}./Den;
end









function V = chebvand(n,X);

% computes by recurrence the Chebyshev-Vandermonde matrix on a 2d or 3d 
% cloud X, in the total-degree product Chebyshev basis of the minimal  
% including cartesian box with the graded lexicographical order 

% input
% n: polynomial degree
% X: 2- or 3-column array of mesh point coordinates

% output
% V: Chebyshev-Vandermonde matrix 


if length(X(1,:)) == 2 

% rectangle containing the cloud
rect=[min(X(:,1)) max(X(:,1)) min(X(:,2)) max(X(:,2))];

    
% couples with length less or equal to deg
% graded lexicographical order
j=(0:1:n);
[j1,j2]=meshgrid(j);
dim=(n+1)*(n+2)/2;
couples=zeros(dim,2);
for s=0:n
good=find(j1(:)+j2(:)==s);
couples(1+s*(s+1)/2:(s+1)*(s+2)/2,:)=[j1(good) j2(good)];
end;

% mapping the cloud in the square [-1,1]^2
a=rect(1);b=rect(2);c=rect(3);d=rect(4);
map=[(2*X(:,1)-b-a)/(b-a) (2*X(:,2)-d-c)/(d-c)];

% Chebyshev-Vandermonde matrix on the cloud
T1=chebpolys(n,map(:,1));
T2=chebpolys(n,map(:,2));
V=T1(:,couples(:,1)+1).*T2(:,couples(:,2)+1);

end;


if length(X(1,:)) == 3 
        
% parallelepiped containing the cloud 
rect=[min(X(:,1)) max(X(:,1)) min(X(:,2)) max(X(:,2)) ... 
 min(X(:,3)) max(X(:,3))];
    
% triples with length less or equal to deg
% graded lexicographical order
j=(0:1:n);
[j1,j2,j3]=meshgrid(j,j,j);
dim=(n+1)*(n+2)*(n+3)/6;
triples=zeros(dim,3);
for s=0:n
good=find(j1(:)+j2(:)+j3(:)==s);
triples(1+s*(s+1)*(s+2)/6:(s+1)*(s+2)*(s+3)/6,:)=[j1(good) j2(good) ...
j3(good)];
end;

%mapping the cloud in the cube [-1,1]^3
a=rect(1);b=rect(2);
c=rect(3);d=rect(4);
e=rect(5);f=rect(6);
map=[(2*X(:,1)-b-a)/(b-a) (2*X(:,2)-d-c)/(d-c) ... 
(2*X(:,3)-f-e)/(f-e)];

%Chebyshev-Vandermonde matrix on the cloud
T1=chebpolys(n,map(:,1));
T2=chebpolys(n,map(:,2));
T3=chebpolys(n,map(:,3));
V=T1(:,triples(:,1)+1).*T2(:,triples(:,2)+1).*T3(:,triples(:,3)+1);

end









function T=chebpolys(n,x)

% computes the Chebyshev-Vandermonde matrix on the real line by recurrence

% input
% n = maximum polynomial degree
% x = 1-column array of abscissas

% output
% T: Chebyshev-Vandermonde matrix at x, T(i,j+1)=T_j(x_i), j=0,...,deg

T=zeros(length(x),n+1);
t0=ones(length(x),1);
T(:,1)=t0;
t1=x;
T(:,2)=t1;

for j=2:n
t2=2*x.*t1-t0;
T(:,j+1)=t2;
t0=t1;
t1=t2;
end









function x = mono_next_grlex ( m, x )

%*****************************************************************************80
%
%% MONO_NEXT_GRLEX: grlex next monomial.
%
%  Discussion:
%
%    Example:
%
%    M = 3
%
%    #  X(1)  X(2)  X(3)  Degree
%      +------------------------
%    1 |  0     0     0        0
%      |
%    2 |  0     0     1        1
%    3 |  0     1     0        1
%    4 |  1     0     0        1
%      |
%    5 |  0     0     2        2
%    6 |  0     1     1        2
%    7 |  0     2     0        2
%    8 |  1     0     1        2
%    9 |  1     1     0        2
%   10 |  2     0     0        2
%      |
%   11 |  0     0     3        3
%   12 |  0     1     2        3
%   13 |  0     2     1        3
%   14 |  0     3     0        3
%   15 |  1     0     2        3
%   16 |  1     1     1        3
%   17 |  1     2     0        3
%   18 |  2     0     1        3
%   19 |  2     1     0        3
%   20 |  3     0     0        3
%
%    Thanks to Stefan Klus for pointing out a discrepancy in a previous
%    version of this code, 05 February 2015.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    05 February 2015
%
%  Author:
%
%    John Burkardt
%
%  Input:
%
%    integer M, the spatial dimension.
%
%    integer X(M), the current monomial.
%    The first item is X = [ 0, 0, ..., 0, 0 ].
%
%  Output:
%
%    integer X(M), the next monomial.
%

%
%  Ensure that 1 <= M.
%
if ( m < 1 )
    fprintf ( 1, '\n' );
    fprintf ( 1, 'MONO_NEXT_GRLEX - Fatal error!' );
    fprintf ( 1, '  M < 1\n' );
    error ( 'MONO_NEXT_GRLEX - Fatal error!' );
end
%
%  Ensure that 0 <= XC(I).
%
for i = 1 : m
    if ( x(i) < 0 )
        fprintf ( 1, '\n' );
        fprintf ( 1, 'MONO_NEXT_GRLEX - Fatal error!' );
        fprintf ( 1, '  X(I) < 0\n' );
        error ( 'MONO_NEXT_GRLEX - Fatal error!' );
    end
end
%
%  Find I, the index of the rightmost nonzero entry of X.
%
i = 0;
for j = m : -1 : 1
    if ( 0 < x(j) )
        i = j;
        break
    end
end
%
%  set T = X(I)
%  set X(I) to zero,
%  increase X(I-1) by 1,
%  increment X(M) by T-1.
%
if ( i == 0 )
    x(m) = 1;
    return
elseif ( i == 1 )
    t = x(1) + 1;
    im1 = m;
elseif ( 1 < i )
    t = x(i);
    im1 = i - 1;
end

x(i) = 0;
x(im1) = x(im1) + 1;
x(m) = x(m) + t - 1;

return













