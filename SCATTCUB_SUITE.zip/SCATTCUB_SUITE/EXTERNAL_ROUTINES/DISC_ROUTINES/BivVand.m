%% Computing the Bivariate Vandermonde Matrix 

% INPUT:
% X: 2-column array of "m" sample points (matrix m x 2).
% d: degree of the Vandermonde matrix
% pow: powers of the bivariate monomial basis (matrix (d+1)*(d+2)/2 x 2)


% OUTPUT:
% A: Bivariate Vandermonde matrix of total degree "deg"

function A=BivVand(X,d,pow)

V1=ShortVander(d+1,X(:,1));
V2=ShortVander(d+1,X(:,2));

V1=V1(:,end:-1:1);
V2=V2(:,end:-1:1);

A=V1(:,pow(:,1)+1).*V2(:,pow(:,2)+1);


