%% Demo on using "derivative_nu_f_xb" for the adaptive Differentiation
%% by local polynomial Interpolation on SCattered data

clear all
clc

format long

%% The data.txt file contains a Nx3 matrix (x_i,y_i,f_i), i=1,...,N for the Franke function sampled at 1000 Halton points
Data=dlmread('data.txt');
X=Data(:,1:2);
fX=Data(:,3);
N=size(X,1);

%% The evaluation point
Xb=[0.5,0.5]; 

index_of_derivative

d0=5; %% The initial degree

delta=2; %% The degree step

dmax=floor((-3+sqrt(1+8*N))/2); %% The maximum degree

hmax=0.8; %% The maximum allowed radius <1

%%% Compute the approximation of the derivative
[dnu,error]=derivative_nu_f_xb(X,fX,Xb,d0,dmax,delta,hmax,nu);

approx_value=dnu(end) %% approximate derivative value

est_min=error(end) %% error estimate


