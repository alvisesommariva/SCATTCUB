% Computing the powers of the bivariate monomial basis of total degree "d"
% by using the routine mono_next_grlex.m

% INPUT:
% d: total degree of the desired monomial powers
% varargin: the degree of current monomial if given

% OUTPUT:
% powV: matrix of the bivariate monomial basis of total degree "d" or
% matrix of powers successive to the one given in varargin


%%%% EXAMPLE %%%%
% >> powV=pow(3)
% powV=[  0     0
%      0     1
%      1     0
%      0     2
%      1     1
%      2     0
%      0     3
%      1     2
%      2     1
%      3     0]


% >> powV=pow(2,3)
% powV=[0     3
%      1     2
%      2     1
%      3     0]

function powV=pow(d,varargin)
 N=(d+1)*(d+2)/2;
switch nargin
    case 1       
        powV=zeros(N,2);
        powV(1,:)=[0,0];
        for i=2:N
            powV(i,:) = mono_next_grlex(2,powV(i-1,:));
        end
    case 2
        dn=varargin{1};
        NN=(dn+1)*(dn+2)/2;
        powV(1,:)=[0,d+1];
        for i=2:NN-N
            powV(i,:) = mono_next_grlex(2,powV(i-1,:));
        end
        
end
