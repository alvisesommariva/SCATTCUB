%%% Menu containing the order of derivatives from 0 to 2


UIControl_FontSize_bak = get(0, 'DefaultUIControlFontSize');
set(0, 'DefaultUIControlFontSize', 12);
scelta=menu('Choose the derivative  to be approximated','(0,0)','(1,0)','(0,1)','(2,0)',...
    '(1,1)','(0,2)');
switch scelta
    case 1
       nu=1;
       Inu=[0,0];
    case 2
        nu=3;
        Inu=[1,0];
    case 3
       nu=2;
       Inu=[0,1];
    case 4
       nu=6;
       Inu=[2,0];
    case 5
       nu=5;
       Inu=[1,1];
    case 6
       nu=4;
       Inu=[0,2];
end
