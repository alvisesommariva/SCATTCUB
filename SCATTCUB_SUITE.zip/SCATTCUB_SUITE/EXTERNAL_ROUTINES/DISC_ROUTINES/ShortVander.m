%% Computing the first n columns of the Vandermonde Matrix in reverse order.

% INPUT:
% n: maximum power 
% v: column vector 

%OUTPUT:
% A: first n columns of the Vandermonde matrix

%%%%% EXAMPLE %%%%%
% >> A=ShortVander(3,[1;2;3;4])
% 
% >> A =[1     1     1
%      4     2     1
%      9     3     1
%     16     4     1]

function A = ShortVander(n,v)

v = v(:);

if n == 0
    A = reshape(v, n, n);
else
    A = repmat(v, 1, n);
    A(:, n) = 1;
    A = cumprod(A, 2, 'reverse');
end
