%% Computing the derivative of order nu the function f

% INPUT:
% f: handle function of the variables x,y
% nu: differentiation bi-index


function Df=derivative(f,nu)
syms x y
switch nu
    case 1
        Df=f;
    case 3
        Df=eval(['@(x,y)' char(vectorize(diff(f(x,y),x)))]); %Dx
    case 2
        Df=eval(['@(x,y)' char(vectorize(diff(f(x,y),y)))]); %Dy
    case 6
        Df=eval(['@(x,y)' char(vectorize(diff(f(x,y),x,x)))]); %Dxx
    case 5
        Df=eval(['@(x,y)' char(vectorize(diff(f(x,y),x,y)))]); %Dxy
    case 4
        Df=eval(['@(x,y)' char(vectorize(diff(f(x,y),y,y)))]); %Dx
end



