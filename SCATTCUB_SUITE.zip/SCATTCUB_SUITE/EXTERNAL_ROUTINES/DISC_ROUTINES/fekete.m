function [index] = fekete(V)

% computes approximate Fekete or Leja interpolation points for degree n
% from the 2d or 3d cloud X

% input
% n: interpolation degree
% X: 2- or 3-column array of cloud points coordinates
% ptype: interpolation points type, 1=Fekete, 2=Leja

% output
% I: 2- or 3-column array of interpolation points coordinates

N=length(V(1,:));
[Q,~]=qr(V,0);

[~,~,perm]=lu(Q,'vector');

index=perm(1:N);

