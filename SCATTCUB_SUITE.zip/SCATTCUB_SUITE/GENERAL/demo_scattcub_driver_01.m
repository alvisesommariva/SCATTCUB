
function demo_scattcub_driver_01

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Demo used to compare evaluators in order to compute integrals from
% samples involving scattered data.
%
% 1. Determines domain and functions to study from respective galleries.

% 2. Makes experiments, changing the number of scattered data:
%
% (a) For methods based on evaluating in scattered data, using the values
%    to evaluate at points of an algebraic rule:
%    Makes experiments, evaluating the integrand at cubature nodes of an
%    algebraic rule, when only samples at scattered data are available.
%
%    Important: algebraic degree of exactness of the cubature rule is fixed.
%
% (b) For other methods, as Glaubitz algorithm of direct-RBF cubature 
%    (when applicable) computes the value of the integral, with a formula 
%    based on scattered data.
%
% 3. Makes plot of the domain, scattered samples.
%--------------------------------------------------------------------------
% Modified: July 8, 2023.
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023-
%
% Authors:
% Roberto Cavoretto, Francesco Dell'Accio, Alessandra De Rossi,
% Filomena Di Tommaso, Najoua Siar, Alvise Sommariva, Marco Vianello.
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------


%--------------------------------------------------------------------------
% 1, 'polygon';
% 2, 'disk';
% 3, 'lune';
% 4, 'circular-annular-sector';
% 5, 'sector';
% 6, 'asymmetric-circular-sector';
% 7, 'asymmetric-annulus';
% 8, 'vertical-circular-zone';
% 9, 'horizontal-circular-zone';
% 10, 'circular-segment';
% 11, 'symmetric-lens';
% 12, 'butterfly';
% 13, 'candy';
% 14, 'NURBS';
% 15, 'union-disks';
% 16, 'asymmetric-circular-sector';
% 17, 'square';
% 18, 'unit-square[0,1]x[0,1]';
% 19, 'triangle';
% 20, 'polygcirc';
% 21, 'unit-simplex';
%--------------------------------------------------------------------------

domain_type=3; 

degV=4:4:40; % degree of precision of the rule; choose deg=10 for NURBS.
card=800;    % scattered data cardinality
scat_type='halton'; % scattered data type.

% 1. first test function (franke)
f_type.gallery_type='easy';
f_type.example=18;
demo_scattcub_01(domain_type,f_type,degV,card,scat_type);

% 2. second test function ('1./((1+x.^2).*(1+y.^2))')
f_type.gallery_type='easy';
f_type.example=19;
demo_scattcub_01(domain_type,f_type,degV,card,scat_type);

% 3. third test function x0=0.5; y0=0.5;'((x-x0).^2 + (y-y0).^2).^(3/2)';
f_type.gallery_type='easy';
f_type.example=17;
demo_scattcub_01(domain_type,f_type,degV,card,scat_type);






function demo_scattcub_01(domain_type,f_type,degV,card,scat_type)

%--------------------------------------------------------------------------
% INPUT
%--------------------------------------------------------------------------
% Domain type choose the domain to be considered.
%
% The variable "domain_type" can be:
%
% 1: 'polygon';
% 2: 'disk';
% 3: 'lune';
% 4: 'circular-annular-sector';
% 5: 'sector';
% 6: 'asymmetric-circular-sector';
% 7: 'asymmetric-annulus';
% 8: 'vertical-circular-zone';
% 9: 'horizontal-circular-zone';
% 10: 'circular-segment';
% 11: 'symmetric-lens';
% 12: 'butterfly';            
% 13: 'candy';                
% 14: 'NURBS';
% 15: 'union-disks';         
% 16: 'asymmetric-circular-sector';
% 17: 'square'                % [-1,1] x [-1,1]
% 18: 'rectangle'
% 19: 'triangle'
%
% For the definition of these examples in this demo, see the routine
% "domain_str" at the bottom of this file and the external gallery of
% domains "define_domain".
%
% This function is fundamental to understand how to use our codes in
% specific domains.
%
%
% The variable "f_type"  is a struct, defining the function
%
% f_type.gallery_type: string that chooses the function and can be
%
%         'easy' some rather well behaved functions
%                (set as "example" a value in 1,...,23);
%
%         'renka-brown' that are taken from the paper 1., mentioned below;
%                (set as "example" a value in 1,...,10);
%
%         'polynomials' polynomials of degree "deg";
%                (set as "example" a value in 1,...,2);
%            f_example=1: fixed polynomial of degree "deg";
%            f_example=2: random polynomial of degree "deg";
%
% f_type.example chooses the example in the gallery
%
%          1. Franke function has the setting:
%            f_type.gallery_type='easy'; f_type.example=18;
%
%          2. 'exp(-((x-x0).^2+(y-y0).^2))' has the setting:
%            f_type.gallery_type='easy'; f_type.example=16;
%
%          3 '(pi/16+exp(-3.2)*x+sin(pi/9)*y).^deg' has the setting:
%             f_type.gallery_type='polynomials'; f_type.example=1;
%
%          4. '1./((1+x.^2)+(1+y.^2))' has the setting:
%            f_type.gallery_type='easy'; f_type.example=19;
%
% For details, see the file gallery_2D.m in "../EXTERNAL_ROUTINES/DCUB".
% 
% degV,card,scat_type: algebraic degrees of exactness of the rules to be 
%           tested, cardinality and type of the scattered data.
%--------------------------------------------------------------------------
% Modified: July 8, 2023.
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023-
%
% Authors:
% Roberto Cavoretto, Francesco Dell'Accio, Alessandra De Rossi,
% Filomena Di Tommaso, Najoua Siar, Alvise Sommariva, Marco Vianello.
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------


% ...................... 0. Default settings ..............................

if nargin < 1, domain_type=17; end

if nargin >= 2
    gallery_type=f_type.gallery_type;
    f_example=f_type.example;
else
    gallery_type='easy'; f_example=19;
end

if nargin < 3
degV=4:4:40; % degree of precision of the rule; choose deg=10 for NURBS.
end

if nargin < 4
card=800; % scattered data cardinality
end

if nargin < 5
scat_type='halton'; % scattered data type.
end




% ......................  1. settings experiments .........................

% .......................... RBF_type  ....................................
% * parameter that determines the possible RBF to use:
% 1: phi=@(r) (1+r.*r).^(1/2);             % Multiquadric
% 2: phi=@(r) exp(-r.*r);                  % Gaussian
% 3: phi=@(r) (1+r.*r).^(-1/2);            % Inverse Multiquadric
% 4: phi=@(r) (1+4*r).*(max(0,(1-r))).^4;  % Wendland 2
% 5: phi=@(r) r.*r.*log(r+eps*(1-sign(r))); % TPS
% 6: phi=@(r) r.^3;                        % polyharmonic spline
% 7: phi=@(r) r.^5;                        % polyharmonic spline
% 8: phi=@(r) r.^7;                        % polyharmonic spline
% 9: phi=@(r) (max(0,(1-r))).^2;           % Wendland W0
% 10: phi=@(r) (35*r.^2+18*r+3).*(max(0,(1-r))).^6;         % Wendland W4
% 11: phi=@(r) (32*r.^3+25*r.^2+8*r+1).*(max(0,(1-r))).^8;  % Wendland W6
%--------------------------------------------------------------------------

RBF_type=1;



% .............................. special settings ...........................

% ADE of the reference rule (to compute almost exactly the integral)
deg_ref=60; % alternative choice: "deg_ref=deg+10"







%--------------------------------------------------------------------------
%                   Main code below.
%--------------------------------------------------------------------------



% ....................... Preliminary settings  ...........................

% some additional routines are required
addpath(genpath('../EXTERNAL_ROUTINES/'));

% .............................. special settings ...........................
%
% ** IMPORTANT **
% do not modify these settings in case of doubts.
%
% Default choice: "eval_flag=0" and "ref_err=1".
%
% Reference integral for errors:
% 1. "eval_flag=1" and "ref_err=0" if interested in the evaluation error;
% 2. "eval_flag=0" and "ref_err=1" if interested in the evaluation error;
%--------------------------------------------------------------------------

% "ref_err": 0: formula with ADE equal to "deg", 1: ADE equal to "deg_ref".
ref_err=1;

methodV=choose_methods(domain_type);

% flag_compression: if "1" compression will be attempted, if necessary,
% otherwise the code will propose an alternative rule.
flag_compression=1;

% make_diary: if "1" it saves statistics also on a file.
make_diary=0;




% ...................... Making numerical tests  ..........................


% 0. Preparing diary file (if required)
if make_diary
    diary_file_str=['demo_scattcub_driver_',num2str(yyyymmdd(datetime)),'_',...
        num2str(hour(datetime)),num2str(minute(datetime)),'.txt'];
    diary(diary_file_str);
end

% 1. Define function to test and domain
%    Note: the gallery routine is in "../EXTERNAL_ROUTINES/DCUB" folder

fprintf('\n \t * defining integrand');
[f,fstr]=gallery_2D(f_example,gallery_type,max(degV));
fprintf('\n \n \t \t The integrand is: '); disp(fstr);

fprintf('\n \t * defining integration domain');
domain_example=domain_str(domain_type);
domain_struct=define_domain(domain_example);
fprintf('\n \n \t \t The domain is: '); disp(domain_example);

% 2. Compute integral reference value "Iref".

fprintf('\n \t * defining reference integration rule');
xywH=define_cub_rule(domain_struct,deg_ref,0);
fxH=feval(f,xywH(:,1),xywH(:,2)); Iref=xywH(:,3)'*fxH;

fprintf('\n \t * defining scattered data');
[t,dbox,area_domain]=define_scattered_pointset(card,domain_struct,...
    scat_type);
ft=feval(f,t(:,1),t(:,2));

% Reference integral for errors: choose
% 1. "Ideg" if interested in the evaluation error;
% 2. "Iref" if interested in the quadrature error.

if ref_err,
    Iden=Iref;
    ADE_ee=deg_ref;
else,
    Iden=Ideg;
    ADE_ee=deg;
end

% 3. making experiments

fprintf('\n \t * making experiments');

AEV=[]; REV=[]; AEevalV=[]; REevalV=[]; RE_deg=[];

for deg=degV

    % 2A. Compute integral reference value at degree deg "Ideg".
    tic;
    xyw_deg=define_cub_rule(domain_struct,deg,flag_compression);
    cputime_algrule=toc;
    fx_deg=feval(f,xyw_deg(:,1),xyw_deg(:,2)); Ideg=xyw_deg(:,3)'*fx_deg;

    RE_deg(end+1)=abs(Iref-Ideg)/(abs(Iref)+(Iref == 0));

    AEL=[]; REL=[]; AEevL=[]; REevL=[]; xyw=[];
    for method_index=1:length(methodV)
        method=methodV{method_index};

        switch method
            case {'DISC';'ScatteredInterpolant';'RBF'; 'mn9'; ...
                    'movint2D'; 'PUM'}
                tic;
                y=evaluate_scattered(xyw_deg(:,1:2),t,ft,method,...
                    RBF_type,f,domain_struct);

                I(method_index)=(xyw_deg(:,3))'*y;
                cputime_eval=toc;
                cpueval=cputime_algrule+cputime_eval;

                fxy=feval(f,xyw_deg(:,1),xyw_deg(:,2));

                aeevL=max(abs(fxy-y));
                reevL=max( abs(fxy-y)./abs(fxy));

                card_rule=size(xyw_deg,1);
                deg_rule=deg;

            case 'Glaubitz-algorithm'

                tic;

                area_dbox=diff(dbox(1,:))*diff(dbox(2,:));
                wQMC=(area_domain/area_dbox)/size(t,1);
                [w,deg_rule]=glaubitz_algorithm(t,domain_struct,wQMC,'LS');
                I(method_index)=w'*ft;
                cpueval=toc;

                aeevL=NaN;
                reevL=NaN;

                card_rule=length(w);
                xyw=[];


            case 'direct-RBFcubature'

                tic;
                RBF_scale=RBF_optimal_scale(t,ft,RBF_type);
                P=domain_struct.polyshape;
                [w , ~ , ~ , ~ , ~ ,phi_str]=RBF_cub_polygon_OPT(P,t,...
                    RBF_type,RBF_scale);
                I(method_index)=w'*ft;
                cpueval=toc;

                xyw=[t w];
                card_rule=length(w);
                deg_rule=NaN;
                aeevL=NaN;
                reevL=NaN;

        end



        %--------------------------------------------------------------------------
        % 7. Display statistics.
        %--------------------------------------------------------------------------
        fprintf('\n \t -------------------------------------------------------');
        fprintf('\n \t Domain (integration)        : '); disp(domain_struct.domain);
        fprintf('\n \t Scattered data type         : '); disp(scat_type);
        fprintf(   '\t Evaluation method           : '); disp(method);
        fprintf('\n \t Scatt. points card. required: %5.0f',card);
        fprintf('\n \t Scatt. points card. provided: %5.0f \n',size(t,1));

        fprintf('\n \t Degree of precision         : %5.0f',deg_rule);

        fprintf('\n \t Cardinality of the formula  : %5.0f',card_rule);
        fprintf('\n \t Approximated integral       : %1.9e',Iref);
        fprintf('\n \n \t Cputime for integral eval.  : %1.2e',cpueval);

        % cubature error
        aeL=abs(Iden-I(method_index));
        fprintf('\n \n \t Absolute error (cub)        : %1.2e',aeL);
        reL=aeL/(abs(Iden)+(Iden == 0));
        fprintf('\n \t Relative error (cub)        : %1.2e',reL);

        % evaluation error
        fprintf('\n \n \t Absolute error (eval)       : %1.2e',aeevL);
        fprintf('\n \t Relative error (eval)       : %1.2e',reevL);

        fprintf('\n \t -------------------------------------------------------');
        fprintf('\n \n')

        % update cubature error list
        AEL=[AEL aeL]; REL=[REL reL];

        % update approximation error list
        AEevL=[AEevL aeevL]; REevL=[REevL reevL];
    end
    AEV=[AEV; AEL]; REV=[REV; REL];
    AEevalV=[AEevalV; AEevL]; REevalV=[REevalV; REevL];
end


% 3. making tables

EvalType=categorical(methodV);
RE_cub=REV'; RE_eval=REevalV';
T = table(EvalType, RE_cub); disp(T);
T = table(EvalType, RE_eval); disp(T);

fprintf('\n \n');

fprintf('\n \t ........................................................ ');
fprintf('\n \n \t The integrand is: '); disp(fstr);
fprintf('\n \t The domain is   : '); disp(domain_struct.domain);
fprintf('\n \n \t ........................................................ ');
fprintf('\n \n');



% 4. plot domain and nodes

fig_name=strcat(domain_example,gallery_type,num2str(f_example));

figure(1)

% if isempty(xyw), pts=[]; else, pts=xyw(:,1:2); end
% plot_2D(domain_struct,t,pts);

plot_2D(domain_struct,t);

saveas(gcf,domain_example,'epsc');

% 5. plot errors
figure(2)
plot_type={'-.o',':*','--x','-.+',':s','--d',':h','-.p','--v','-.>', ...
    ':<',':o','--*','-.+'};

P = haltonset(3); color_type = net(P,length(methodV));

for k=1:length(methodV)
    plot_str=plot_type{k};
    color_RGB=color_type(k,:);
    semilogy(degV,REV(:,k),plot_str,'Color',color_RGB,'LineWidth',1.5);
    hold on
end

plot_str=':';
color_RGB=[180,180,180]/256;
semilogy(degV,RE_deg,plot_str,'Color',color_RGB,...
    'LineWidth',2);


% Making good legend
for k=1:length(methodV)
    method=methodV{k};
    method_init=extractBefore(method,4);
    if strcmp(extractBefore(method,4),'RBF')
        RBF_type_str=extractAfter(method,3);
        if length(RBF_type_str) > 0
            RBF_type=round(str2num(RBF_type_str));
        end
        [ ~,phi_str] =  RBF (RBF_type);

        method_legend{k}=extractBefore(phi_str,min(length(phi_str)+1,4));
    else
        method_legend{k}=method_legend_string(method);
    end
end
method_legend{end+1}='EXRULE';

grid on;


lgd = legend(method_legend(1:length(method_legend)),'Location','southwest');
fontsize(lgd,8,'points');
lgd.FontSize = 8;

hold off

saveas(gcf,fig_name,'epsc');

if make_diary, diary off; end







function domain_example=domain_str(example)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Given a number "example", it provides the name of the corrsponding domain
% in the gallery,
%--------------------------------------------------------------------------

switch example

    case 1, domain_example='polygon';
    case 2, domain_example='disk';
    case 3, domain_example='lune';
    case 4, domain_example='circular-annular-sector';
    case 5, domain_example='sector';
    case 6, domain_example='asymmetric-circular-sector';
    case 7, domain_example='asymmetric-annulus';
    case 8, domain_example='vertical-circular-zone';
    case 9, domain_example='horizontal-circular-zone';
    case 10, domain_example='circular-segment';
    case 11, domain_example='symmetric-lens';
    case 12, domain_example='butterfly';
    case 13, domain_example='candy';
    case 14, domain_example='NURBS';
    case 15, domain_example='union-disks';
    case 16, domain_example='asymmetric-circular-sector';
    case 17, domain_example='square';
    case 18, domain_example='unit-square[0,1]x[0,1]';
    case 19, domain_example='triangle';
    case 20, domain_example='polygcirc';
    case 21, domain_example='unit-simplex';
end




function methodV=choose_methods(domain_type)

% domain_type: structure defining the domain;

switch domain_type
    case {1,17,18,29,21}
        methodV={'PUM';'ScatteredInterpolant';'RBF'; ...
            'mn9'; 'movint2D'; 'Glaubitz-algorithm'; ...
            'direct-RBFcubature'};

    otherwise
        methodV={'PUM';'ScatteredInterpolant';'RBF'; ...
            'mn9'; 'movint2D'; 'Glaubitz-algorithm'};
end






function method_str_legend=method_legend_string(method_str)

switch method_str
    case 'PUM'
        method_str_legend='PUM';
    case 'ScatteredInterpolant'
        method_str_legend='SCATTINT';
    case 'RBF'
        method_str_legend='RBF';
    case 'mn9'
        method_str_legend='MSHEP9';
    case 'movint2D'
        method_str_legend='DISC';
    case 'Glaubitz-algorithm'
        method_str_legend='LS-CF';
    case 'direct-RBFcubature'
        method_str_legend='RBFCUB';
    otherwise
        method_str_legend=...
            extractBefore(method_str,min(length(method_str)+1,4));

end












